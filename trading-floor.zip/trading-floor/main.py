"""Start the trading floor.

    python main.py            # real market data (crypto works with no keys), paper money
    python main.py --demo     # everything simulated, works offline
"""
import argparse
import logging
import os
from pathlib import Path

import uvicorn
import yaml
from dotenv import load_dotenv

from trading_floor.engine import Engine
from trading_floor.server import create_app


def main():
    ap = argparse.ArgumentParser(description="12 AI traders watching the market every second")
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--demo", action="store_true", help="use simulated prices for every market")
    ap.add_argument("--host", default=None)
    ap.add_argument("--port", type=int, default=None)
    args = ap.parse_args()

    load_dotenv()
    logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"),
                        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s", datefmt="%H:%M:%S")
    cfg = yaml.safe_load(Path(args.config).read_text())
    engine = Engine(cfg, demo=args.demo)
    srv = cfg.get("server", {})
    host = args.host or srv.get("host", "127.0.0.1")
    port = args.port or srv.get("port", 8000)
    if host not in ("127.0.0.1", "localhost") and not os.getenv("DASHBOARD_TOKEN"):
        logging.warning("Dashboard is reachable from the network without DASHBOARD_TOKEN — set one in .env!")
    print(f"\n  Trading floor dashboard → http://{host}:{port}\n")
    uvicorn.run(create_app(engine), host=host, port=port, log_level="warning")


if __name__ == "__main__":
    main()
