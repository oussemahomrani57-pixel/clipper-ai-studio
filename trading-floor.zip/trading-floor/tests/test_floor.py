"""Fast offline tests: run `pytest -q`."""
import asyncio
import math
import time

import pytest

from trading_floor.agents.analysts import ALL_ANALYSTS
from trading_floor.agents.desk import HeadTrader, RiskManager
from trading_floor.brokers import PaperBroker
from trading_floor.engine import Engine
from trading_floor.market.candles import MarketState
from trading_floor.models import Order, Signal, Tick
from trading_floor.portfolio import Portfolio


def make_state(prices, start=1_700_000_000):
    ms = MarketState("TEST", "sim")
    for i, p in enumerate(prices):
        ms.on_tick(Tick("TEST", start + i, price=p, size=1, side=1 if i % 2 else -1,
                        bid=p * 0.9999, ask=p * 1.0001, bid_size=5, ask_size=5))
    ms.roll(start + len(prices))
    return ms


def test_candles_fill_gaps():
    ms = MarketState("X", "sim")
    ms.on_tick(Tick("X", 100.2, price=10))
    ms.on_tick(Tick("X", 104.1, price=11))
    ms.roll(105.0)
    assert [c.ts for c in ms.candles] == [100, 101, 102, 103, 104]
    assert ms.candles[-1].close == 11


def test_all_analysts_return_valid_signals():
    ms = make_state([100 + math.sin(i / 20) * 2 + i * 0.01 for i in range(400)])
    for A in ALL_ANALYSTS:
        s = A().analyze(ms)
        assert -1 <= s.score <= 1 and 0 <= s.confidence <= 1, (A.name, s)
        assert s.reason


def test_uptrend_is_bullish():
    ms = make_state([100 * (1.0004 ** i) for i in range(400)])
    trend = next(A for A in ALL_ANALYSTS if A.name == "Trend")().analyze(ms)
    assert trend.action == "BUY"


def test_head_trader_learns_who_is_right():
    h = HeadTrader(["Good", "Bad"], {"score_horizon_seconds": 1})
    p = 100.0
    for t in range(300):
        h.learn("X", p, t, [Signal("Good", 0.8, 1, ""), Signal("Bad", -0.8, 1, "")])
        p *= 1.001
    assert h.weight("Good") > 1.5 > h.weight("Bad")


def test_risk_stop_loss_and_veto():
    r = RiskManager({"stop_loss_pct": 1, "cooldown_seconds": 0})
    pf = Portfolio(1000)
    ms = make_state([100] * 100)
    now = ms.last_tick_ts + 1
    assert not r.check_entry(ms, pf, {"TEST": 100}, now).veto
    pf.apply(__import__("trading_floor.models", fromlist=["Fill"]).Fill("TEST", "BUY", 1, 100, 0, now, "paper"), "sim")
    assert r.check_entry(ms, pf, {"TEST": 100}, now).veto  # already in position
    ms.on_tick(Tick("TEST", now, price=98.5, bid=98.5, ask=98.6))
    assert "STOP-LOSS" in r.check_exit(ms, pf, now)


def test_paper_round_trip_pnl():
    async def go():
        b, pf = PaperBroker(fee_bps=0, slippage_bps=0), Portfolio(1000)
        ms = make_state([100] * 10)
        f = await b.place(Order("TEST", "BUY", 100), ms)
        pf.apply(f, "sim")
        ms.on_tick(Tick("TEST", time.time(), price=110, bid=110, ask=110))
        f2 = await b.place(Order("TEST", "SELL", 0, qty=pf.positions["TEST"].qty), ms)
        rec = pf.apply(f2, "sim")
        return rec["pnl"]
    pnl = asyncio.run(go())
    assert pnl == pytest.approx(100 * (110 / 100.01) - 100, rel=1e-3)


def test_live_mode_requires_confirmation(monkeypatch):
    monkeypatch.delenv("CONFIRM_LIVE_TRADING", raising=False)
    with pytest.raises(SystemExit):
        Engine({"mode": "live", "markets": {}})


def test_engine_demo_runs():
    cfg = {"mode": "paper", "budget_usd": 1000,
           "markets": {"crypto": {"symbols": ["BTCUSDT"]}, "forex": {"symbols": ["EUR_USD"]}}}

    async def go():
        e = Engine(cfg, demo=True)
        task = asyncio.create_task(e.feeds[0].run(e._on_tick))
        task2 = asyncio.create_task(e.feeds[1].run(e._on_tick))
        await asyncio.sleep(1.2)
        e.step(time.time())
        task.cancel(); task2.cancel()
        return e.snapshot()
    snap = asyncio.run(go())
    assert len(snap["traders"]) == 12
    assert {s["symbol"] for s in snap["symbols"]} == {"BTCUSDT", "EUR_USD"}
    assert len(snap["symbols"][0]["signals"]) == 10
