# 🏛️ Trading Floor: 12 AI traders watching the market every second

A team of 12 trading agents. Each one has a single job. They read **crypto, US stocks and forex** live, every second, and vote on every symbol. A Head Trader weighs the votes by each trader's recent track record. A Risk Manager protects the money. You watch it all on a live web dashboard.

![Dashboard](docs/dashboard.png)

> ⚠️ **Educational project, not financial advice.** Automated trading can lose money quickly. Use paper trading first, then the exchange testnets and practice accounts. Only then, and only with money you can afford to lose, consider live trading.

---

## The 12 traders

| # | Trader | Job |
|---|--------|-----|
| 1 | **Trend** | Follows the trend with EMA20 / EMA100 crossover |
| 2 | **Momentum** | Buys strength, sells weakness (15s and 60s rate of change) |
| 3 | **MeanRevert** | Fades over-stretched moves (Bollinger z-score) |
| 4 | **RSI** | Reads overbought / oversold with RSI(14) |
| 5 | **MACD** | Trades MACD histogram turns |
| 6 | **Breakout** | Catches breaks of the 3-minute high / low range |
| 7 | **Volume** | Watches volume spikes and price vs VWAP |
| 8 | **OrderFlow** | Reads buyer vs seller aggression and order-book imbalance |
| 9 | **Pattern** | Spots candlestick patterns (engulfing, hammer, shooting star) |
| 10 | **Regime** | Decides if the market is trending or choppy (efficiency ratio) |
| 11 | **Risk Manager** | Position size, stop-loss, take-profit, trailing stop, daily loss limit. **Can veto any trade** |
| 12 | **Head Trader** | Combines all votes. Grades every analyst 30s after each call and gives more weight to the ones that are right |

How a decision is made, every second, for every symbol:

```
live ticks ──► 1-second candles ──► 10 analysts vote (score −1…+1, confidence)
                                           │
                       Head Trader: weighted by each analyst's accuracy
                                           │
                 BUY if score ≥ 0.35 AND ≥ 5 analysts say BUY
                 SELL if score ≤ −0.15 OR ≥ 5 analysts say SELL
                                           │
                 Risk Manager: veto / force exit (stop-loss, etc.)
                                           │
                         Broker: paper  or  Binance / Alpaca / OANDA
```

## Markets and data

| Market | Live data | Keys needed for prices | Live orders via |
|--------|-----------|------------------------|-----------------|
| Crypto | Binance websocket (trades + order book) | **None** | Binance (testnet by default) |
| US stocks | Alpaca websocket (IEX feed is free) | Free Alpaca account | Alpaca (paper account by default) |
| Forex | OANDA price stream | Free OANDA practice account | OANDA (practice by default) |

If a market has no keys, it runs on **simulated prices** automatically, and the dashboard shows it in amber. Simulated markets always use paper money.

---

## Quick start

```bash
git clone https://github.com/YOUR_NAME/trading-floor.git
cd trading-floor
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env

python main.py --demo      # 100% simulated, works offline
python main.py             # real Binance prices + paper money (no keys needed)
```

Open **http://127.0.0.1:8000**. The analysts need about 3 minutes of data before all of them are warmed up.

**To open it from your phone** on the same Wi-Fi: set `server.host: 0.0.0.0` in `config.yaml` and put a `DASHBOARD_TOKEN` in `.env`. Then open `http://YOUR_PC_IP:8000/?token=YOUR_TOKEN`.

## Going live (step by step)

1. Run in `paper` mode for days and check the win rate and P&L on the dashboard.
2. Create **test** accounts: [Binance testnet](https://testnet.binance.vision), Alpaca paper, OANDA practice. Put the keys in `.env`.
3. In `config.yaml`, set `mode: live`. Keep `testnet: true`, `paper_account: true` and `practice: true`.
4. In `.env`, add `CONFIRM_LIVE_TRADING=YES_I_UNDERSTAND_THE_RISK`. Without this line the bot refuses to start in live mode.
5. Only after that works should you switch an account flag to `false`. That trades **real money**. Keep `budget_usd` and `max_position_usd` small.

Safety built in:
- **Kill switch** button on the dashboard: closes all positions and stops new trades.
- Daily loss limit (default −3%) halts trading for the day.
- Max positions, max trades per hour, cooldown, spread filter, stale-data filter, volatility filter.
- The bot is long-only (buy, then sell). It never shorts and never uses leverage.
- Use API keys **without withdrawal permission**, and restrict them to your IP.

## Configuration

All settings are in [`config.yaml`](config.yaml): symbols per market, budget, risk limits and Head Trader thresholds. Secrets go in `.env`, which is git-ignored.

## Project layout

```
main.py                         start here
config.yaml                     all settings
trading_floor/
  market/feeds.py               Binance, Alpaca, OANDA, simulator feeds
  market/candles.py             ticks → 1-second candles
  agents/analysts.py            traders #1–#10
  agents/desk.py                #11 Risk Manager, #12 Head Trader
  brokers.py                    paper + real brokers
  portfolio.py                  positions, P&L
  engine.py                     the per-second loop
  server.py                     web API + live stream
  web/index.html                dashboard
tests/                          pytest -q
```

## API

| Endpoint | Description |
|---|---|
| `GET /api/state` | full snapshot (JSON) |
| `GET /api/stream` | live snapshot every second (Server-Sent Events) |
| `GET /api/chart/{symbol}` | last 15 minutes of 1-second prices + trade markers |
| `POST /api/kill` | kill switch |
| `POST /api/resume` | resume trading |

## Ideas to extend

- A **News trader** (headlines and sentiment) or an **AI trader** that asks an LLM to comment on the other votes
- A backtest mode that replays saved ticks
- Short selling for forex
- Telegram / Discord alerts on each trade

## License

MIT. Use at your own risk.
