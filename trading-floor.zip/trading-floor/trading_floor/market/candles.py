"""Turns a stream of ticks into 1-second candles and keeps a rolling history."""
from __future__ import annotations

from collections import deque
from typing import Deque, Optional
import numpy as np

from ..models import Tick, Candle


class MarketState:
    """Live state for one symbol: rolling 1s candles + latest quote."""

    def __init__(self, symbol: str, market: str, history: int = 1800):
        self.symbol = symbol
        self.market = market
        self.candles: Deque[Candle] = deque(maxlen=history)
        self._cur: Optional[Candle] = None
        self.last_price: Optional[float] = None
        self.bid: Optional[float] = None
        self.ask: Optional[float] = None
        self.bid_size: Optional[float] = None
        self.ask_size: Optional[float] = None
        self.last_tick_ts: float = 0.0
        self.tick_count = 0

    # ---- ingest -------------------------------------------------------
    def on_tick(self, t: Tick) -> None:
        self.last_tick_ts = t.ts
        self.tick_count += 1
        if t.bid is not None:
            self.bid, self.bid_size = t.bid, t.bid_size
        if t.ask is not None:
            self.ask, self.ask_size = t.ask, t.ask_size

        price = t.price
        if price is None and self.bid and self.ask:
            price = (self.bid + self.ask) / 2  # quote-only markets (forex)
        if price is None:
            return
        self.last_price = price

        sec = int(t.ts)
        c = self._cur
        if c is None or sec > c.ts:
            if c is not None:
                self._close_until(sec)
            self._cur = c = Candle(ts=sec, open=price, high=price, low=price, close=price)
        c.high = max(c.high, price)
        c.low = min(c.low, price)
        c.close = price
        if t.size:
            c.volume += t.size
            c.trades += 1
            if t.side > 0:
                c.buy_volume += t.size
            elif t.side < 0:
                c.sell_volume += t.size

    def _close_until(self, sec: int) -> None:
        """Push the current candle and fill any silent seconds with flat bars."""
        c = self._cur
        self.candles.append(c)
        gap = min(sec - c.ts - 1, 60)
        for i in range(gap):
            self.candles.append(Candle(ts=c.ts + i + 1, open=c.close, high=c.close,
                                       low=c.close, close=c.close))

    def roll(self, now: float) -> None:
        """Called every second by the engine so candles close even without ticks."""
        sec = int(now)
        if self._cur is not None and sec > self._cur.ts:
            self._close_until(sec)
            p = self._cur.close
            self._cur = Candle(ts=sec, open=p, high=p, low=p, close=p)

    # ---- views for agents ----------------------------------------------
    def arrays(self):
        cs = list(self.candles)
        if not cs:
            e = np.array([])
            return e, e, e, e, e, e
        o = np.fromiter((c.open for c in cs), float, len(cs))
        h = np.fromiter((c.high for c in cs), float, len(cs))
        l = np.fromiter((c.low for c in cs), float, len(cs))
        cl = np.fromiter((c.close for c in cs), float, len(cs))
        bv = np.fromiter((c.buy_volume for c in cs), float, len(cs))
        sv = np.fromiter((c.sell_volume for c in cs), float, len(cs))
        return o, h, l, cl, bv, sv

    @property
    def spread_pct(self) -> Optional[float]:
        if self.bid and self.ask and self.ask > 0:
            return (self.ask - self.bid) / ((self.ask + self.bid) / 2) * 100
        return None
