"""Live market data feeds. Each feed pushes Tick objects to `emit` in real time.

- BinanceFeed   : crypto, public websocket, no API key needed
- AlpacaFeed    : US stocks, websocket, needs free Alpaca keys
- OandaFeed     : forex, HTTP price stream, needs OANDA practice/live token
- SimulatedFeed : fake but realistic prices for testing offline / demo
"""
from __future__ import annotations

import asyncio
import json
import logging
import math
import random
import threading
import time
from typing import Callable, List

from ..models import Tick

log = logging.getLogger("feeds")
Emit = Callable[[Tick], None]


class Feed:
    market = "generic"

    def __init__(self, symbols: List[str]):
        self.symbols = symbols
        self.connected = False
        self.last_error = ""

    async def run(self, emit: Emit) -> None:
        """Run forever, reconnecting with exponential backoff."""
        delay = 1
        while True:
            try:
                await self._run(emit)
                delay = 1
            except asyncio.CancelledError:
                raise
            except Exception as e:  # noqa: BLE001
                self.connected = False
                self.last_error = f"{type(e).__name__}: {e}"
                log.warning("%s feed error: %s (reconnect in %ss)", self.market, self.last_error, delay)
                await asyncio.sleep(delay)
                delay = min(delay * 2, 60)

    async def _run(self, emit: Emit) -> None:
        raise NotImplementedError


# --------------------------------------------------------------------------- crypto
class BinanceFeed(Feed):
    """Trades (aggTrade) + best bid/ask (bookTicker) for each symbol, e.g. BTCUSDT."""
    market = "crypto"

    def __init__(self, symbols, base_url="wss://stream.binance.com:9443"):
        super().__init__([s.upper() for s in symbols])
        self.base_url = base_url

    async def _run(self, emit):
        import websockets  # pip install websockets

        streams = "/".join(f"{s.lower()}@aggTrade/{s.lower()}@bookTicker" for s in self.symbols)
        url = f"{self.base_url}/stream?streams={streams}"
        async with websockets.connect(url, ping_interval=20, max_size=2**22) as ws:
            self.connected, self.last_error = True, ""
            log.info("Binance connected: %s", self.symbols)
            async for raw in ws:
                d = json.loads(raw).get("data", {})
                ev = d.get("e")
                if ev == "aggTrade":
                    emit(Tick(symbol=d["s"], ts=d["T"] / 1000, price=float(d["p"]),
                              size=float(d["q"]), side=-1 if d["m"] else 1))
                elif "b" in d and "a" in d:  # bookTicker has no "e" field
                    emit(Tick(symbol=d["s"], ts=time.time(), bid=float(d["b"]),
                              bid_size=float(d["B"]), ask=float(d["a"]), ask_size=float(d["A"])))


# --------------------------------------------------------------------------- stocks
class AlpacaFeed(Feed):
    """US stock trades + quotes. feed='iex' is free; 'sip' needs a paid plan."""
    market = "stocks"

    def __init__(self, symbols, key, secret, feed="iex"):
        super().__init__([s.upper() for s in symbols])
        self.key, self.secret, self.feed = key, secret, feed

    async def _run(self, emit):
        import websockets
        from datetime import datetime

        if not self.key or not self.secret:
            raise RuntimeError("ALPACA_KEY / ALPACA_SECRET missing in .env")
        url = f"wss://stream.data.alpaca.markets/v2/{self.feed}"
        async with websockets.connect(url, ping_interval=20) as ws:
            await ws.send(json.dumps({"action": "auth", "key": self.key, "secret": self.secret}))
            await ws.send(json.dumps({"action": "subscribe", "trades": self.symbols, "quotes": self.symbols}))
            last_bid = {}
            async for raw in ws:
                for m in json.loads(raw):
                    t = m.get("T")
                    if t == "success" and m.get("msg") == "authenticated":
                        self.connected, self.last_error = True, ""
                        log.info("Alpaca connected: %s", self.symbols)
                    elif t == "error":
                        raise RuntimeError(f"Alpaca: {m.get('msg')}")
                    elif t in ("t", "q"):
                        ts = _iso_ts(m.get("t")) or time.time()
                        if t == "t":
                            # infer aggressor side from last quote (tick rule)
                            q = last_bid.get(m["S"])
                            side = 0
                            if q:
                                side = 1 if m["p"] >= q[1] else -1 if m["p"] <= q[0] else 0
                            emit(Tick(symbol=m["S"], ts=ts, price=float(m["p"]),
                                      size=float(m.get("s", 0)), side=side))
                        else:
                            last_bid[m["S"]] = (m["bp"], m["ap"])
                            emit(Tick(symbol=m["S"], ts=ts, bid=float(m["bp"]), bid_size=float(m["bs"]),
                                      ask=float(m["ap"]), ask_size=float(m["as"])))


def _iso_ts(s):
    if not s:
        return None
    try:
        from datetime import datetime
        s = s.replace("Z", "+00:00")
        if "." in s:  # trim nanoseconds to microseconds
            head, rest = s.split(".", 1)
            frac, tz = rest[:-6], rest[-6:]
            s = f"{head}.{frac[:6]}{tz}"
        return datetime.fromisoformat(s).timestamp()
    except Exception:  # noqa: BLE001
        return None


# --------------------------------------------------------------------------- forex
class OandaFeed(Feed):
    """Forex bid/ask stream, instruments like EUR_USD. Uses a background thread."""
    market = "forex"

    def __init__(self, symbols, token, account_id, practice=True):
        super().__init__([s.upper() for s in symbols])
        self.token, self.account_id = token, account_id
        host = "stream-fxpractice.oanda.com" if practice else "stream-fxtrade.oanda.com"
        self.url = f"https://{host}/v3/accounts/{account_id}/pricing/stream"

    async def _run(self, emit):
        if not self.token or not self.account_id:
            raise RuntimeError("OANDA_TOKEN / OANDA_ACCOUNT_ID missing in .env")
        loop = asyncio.get_running_loop()
        done = loop.create_future()

        def worker():
            import requests
            try:
                with requests.get(self.url, headers={"Authorization": f"Bearer {self.token}"},
                                  params={"instruments": ",".join(self.symbols)},
                                  stream=True, timeout=(10, 30)) as r:
                    r.raise_for_status()
                    self.connected, self.last_error = True, ""
                    for line in r.iter_lines():
                        if not line:
                            continue
                        m = json.loads(line)
                        if m.get("type") != "PRICE" or not m.get("bids") or not m.get("asks"):
                            continue
                        b, a = m["bids"][0], m["asks"][0]
                        tick = Tick(symbol=m["instrument"], ts=_iso_ts(m.get("time")) or time.time(),
                                    bid=float(b["price"]), bid_size=float(b.get("liquidity", 0)),
                                    ask=float(a["price"]), ask_size=float(a.get("liquidity", 0)))
                        loop.call_soon_threadsafe(emit, tick)
                loop.call_soon_threadsafe(done.set_result, None)
            except Exception as e:  # noqa: BLE001
                loop.call_soon_threadsafe(lambda: done.done() or done.set_exception(e))

        threading.Thread(target=worker, daemon=True).start()
        await done


# --------------------------------------------------------------------------- simulator
class SimulatedFeed(Feed):
    """Random-walk prices with trending / choppy regimes. Great for testing."""

    def __init__(self, symbols, market="sim", start_prices=None, tps=5):
        super().__init__(symbols)
        self.market = market
        self.tps = tps
        self.state = {}
        for s in symbols:
            p = (start_prices or {}).get(s, random.uniform(50, 500))
            self.state[s] = {"p": p, "drift": 0.0, "vol": 0.0004}

    async def _run(self, emit):
        self.connected = True
        while True:
            for s, st in self.state.items():
                if random.random() < 0.004:  # regime change
                    st["drift"] = random.choice([-1, 0, 0, 1]) * random.uniform(0.00002, 0.00012)
                    st["vol"] = random.uniform(0.0001, 0.0008)
                ret = st["drift"] + st["vol"] * random.gauss(0, 1) / math.sqrt(self.tps)
                st["p"] *= math.exp(ret)
                p = st["p"]
                half = p * 0.00005
                side = 1 if ret > 0 else -1
                emit(Tick(symbol=s, ts=time.time(), price=p, size=random.expovariate(1.0),
                          side=side if random.random() < 0.7 else -side,
                          bid=p - half, ask=p + half,
                          bid_size=random.uniform(1, 10) * (1.5 if side > 0 else 1),
                          ask_size=random.uniform(1, 10) * (1.5 if side < 0 else 1)))
            await asyncio.sleep(1 / self.tps)
