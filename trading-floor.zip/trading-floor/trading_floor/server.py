"""Web server: live dashboard + JSON API + Server-Sent Events stream (1 update/second)."""
from __future__ import annotations

import asyncio
import contextlib
import json
import os
import secrets
from pathlib import Path

from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import FileResponse, JSONResponse, StreamingResponse, Response
from starlette.routing import Route

from .engine import Engine

WEB = Path(__file__).parent / "web"


def create_app(engine: Engine) -> Starlette:
    token = os.getenv("DASHBOARD_TOKEN", "")

    def authorized(req: Request) -> bool:
        if not token:
            return True
        got = req.query_params.get("token") or req.headers.get("x-token", "")
        return secrets.compare_digest(got, token)

    def guard(fn):
        async def wrapper(req: Request):
            if not authorized(req):
                return Response("unauthorized — add ?token=YOUR_DASHBOARD_TOKEN", status_code=401)
            return await fn(req)
        return wrapper

    @guard
    async def index(req):
        return FileResponse(WEB / "index.html")

    @guard
    async def state(req):
        return JSONResponse(engine.snapshot())

    @guard
    async def chart(req):
        return JSONResponse(engine.chart(req.path_params["symbol"].upper()))

    @guard
    async def stream(req):
        async def gen():
            while True:
                if await req.is_disconnected():
                    break
                yield f"data: {json.dumps(engine.snapshot(), default=float)}\n\n"
                await asyncio.sleep(1)
        return StreamingResponse(gen(), media_type="text/event-stream",
                                 headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

    @guard
    async def kill(req):
        await engine.panic()
        return JSONResponse({"ok": True, "paused": True})

    @guard
    async def resume(req):
        engine.resume()
        return JSONResponse({"ok": True, "paused": False})

    @contextlib.asynccontextmanager
    async def lifespan(app):
        task = asyncio.create_task(engine.run())
        yield
        task.cancel()

    return Starlette(lifespan=lifespan, routes=[
        Route("/", index),
        Route("/api/state", state),
        Route("/api/chart/{symbol}", chart),
        Route("/api/stream", stream),
        Route("/api/kill", kill, methods=["POST"]),
        Route("/api/resume", resume, methods=["POST"]),
    ])
