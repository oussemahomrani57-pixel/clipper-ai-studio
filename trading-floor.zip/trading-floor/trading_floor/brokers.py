"""Order execution.

PaperBroker  : fake money, realistic fills at bid/ask + fees (default)
BinanceBroker: real crypto spot orders (testnet by default)
AlpacaBroker : real US stock orders (paper account by default)
OandaBroker  : real forex orders (practice account by default)

Real brokers only run when config mode = "live" AND the .env file contains
CONFIRM_LIVE_TRADING=YES_I_UNDERSTAND_THE_RISK.
"""
from __future__ import annotations

import asyncio
import hashlib
import hmac
import logging
import math
import time
import urllib.parse
import uuid

from .market.candles import MarketState
from .models import Order, Fill

log = logging.getLogger("broker")


class Broker:
    name = "broker"

    async def place(self, order: Order, ms: MarketState) -> Fill:
        try:
            return await asyncio.to_thread(self._place, order, ms)
        except Exception as e:  # noqa: BLE001
            log.error("%s order failed: %s", self.name, e)
            return Fill(order.symbol, order.side, 0, 0, 0, time.time(), self.name, ok=False, error=str(e))

    def _place(self, order: Order, ms: MarketState) -> Fill:  # pragma: no cover
        raise NotImplementedError


class PaperBroker(Broker):
    name = "paper"

    def __init__(self, fee_bps: float = 10, slippage_bps: float = 2):
        self.fee = fee_bps / 10_000
        self.slip = slippage_bps / 10_000

    async def place(self, order, ms):
        p = ms.last_price
        if order.side == "BUY":
            price = (ms.ask or p) * (1 + self.slip)
            qty = order.notional / price
        else:
            price = (ms.bid or p) * (1 - self.slip)
            qty = order.qty or 0
        fee = qty * price * self.fee
        return Fill(order.symbol, order.side, qty, price, fee, time.time(), self.name,
                    order_id=uuid.uuid4().hex[:10])


# --------------------------------------------------------------------------- Binance
class BinanceBroker(Broker):
    name = "binance"

    def __init__(self, key, secret, testnet=True, fee_bps=10):
        import requests
        if not key or not secret:
            raise RuntimeError("BINANCE_KEY / BINANCE_SECRET missing in .env")
        self.key, self.secret = key, secret.encode()
        self.base = "https://testnet.binance.vision" if testnet else "https://api.binance.com"
        self.s = requests.Session()
        self.s.headers["X-MBX-APIKEY"] = key
        self.fee_bps = fee_bps
        self._filters = {}

    def _signed(self, method, path, params):
        params = dict(params, timestamp=int(time.time() * 1000), recvWindow=5000)
        q = urllib.parse.urlencode(params)
        sig = hmac.new(self.secret, q.encode(), hashlib.sha256).hexdigest()
        r = self.s.request(method, f"{self.base}{path}?{q}&signature={sig}", timeout=10)
        if r.status_code >= 400:
            raise RuntimeError(f"Binance {r.status_code}: {r.text}")
        return r.json()

    def _lot(self, symbol):
        if symbol not in self._filters:
            info = self.s.get(f"{self.base}/api/v3/exchangeInfo", params={"symbol": symbol}, timeout=10).json()
            f = {x["filterType"]: x for x in info["symbols"][0]["filters"]}
            self._filters[symbol] = {"base": info["symbols"][0]["baseAsset"],
                                     "step": float(f["LOT_SIZE"]["stepSize"])}
        return self._filters[symbol]

    def _place(self, order, ms):
        lot = self._lot(order.symbol)
        if order.side == "BUY":
            params = {"symbol": order.symbol, "side": "BUY", "type": "MARKET",
                      "quoteOrderQty": f"{order.notional:.2f}"}
        else:
            step = lot["step"]
            qty = math.floor((order.qty or 0) / step) * step
            decimals = max(0, -int(round(math.log10(step)))) if step < 1 else 0
            params = {"symbol": order.symbol, "side": "SELL", "type": "MARKET",
                      "quantity": f"{qty:.{decimals}f}"}
        r = self._signed("POST", "/api/v3/order", params)
        qty = float(r["executedQty"])
        quote = float(r["cummulativeQuoteQty"])
        price = quote / qty if qty else 0
        base_fee = sum(float(f["commission"]) for f in r.get("fills", []) if f["commissionAsset"] == lot["base"])
        if order.side == "BUY":
            qty -= base_fee  # we received less coin than executed
        fee = quote * self.fee_bps / 10_000
        return Fill(order.symbol, order.side, qty, price, fee, time.time(), self.name,
                    order_id=str(r.get("orderId")))


# --------------------------------------------------------------------------- Alpaca
class AlpacaBroker(Broker):
    name = "alpaca"

    def __init__(self, key, secret, paper=True):
        import requests
        if not key or not secret:
            raise RuntimeError("ALPACA_KEY / ALPACA_SECRET missing in .env")
        self.base = "https://paper-api.alpaca.markets" if paper else "https://api.alpaca.markets"
        self.s = requests.Session()
        self.s.headers.update({"APCA-API-KEY-ID": key, "APCA-API-SECRET-KEY": secret})

    def _wait_fill(self, oid):
        for _ in range(30):
            o = self.s.get(f"{self.base}/v2/orders/{oid}", timeout=10).json()
            if o["status"] == "filled":
                return o
            if o["status"] in ("canceled", "rejected", "expired"):
                raise RuntimeError(f"Alpaca order {o['status']}")
            time.sleep(0.5)
        raise RuntimeError("Alpaca order not filled in 15s")

    def _place(self, order, ms):
        if order.side == "BUY":
            r = self.s.post(f"{self.base}/v2/orders", timeout=10, json={
                "symbol": order.symbol, "notional": f"{order.notional:.2f}", "side": "buy",
                "type": "market", "time_in_force": "day"})
        else:
            r = self.s.delete(f"{self.base}/v2/positions/{order.symbol}", timeout=10)
        if r.status_code >= 400:
            raise RuntimeError(f"Alpaca {r.status_code}: {r.text}")
        o = self._wait_fill(r.json()["id"])
        return Fill(order.symbol, order.side, float(o["filled_qty"]), float(o["filled_avg_price"]),
                    0.0, time.time(), self.name, order_id=o["id"])


# --------------------------------------------------------------------------- OANDA
class OandaBroker(Broker):
    name = "oanda"

    def __init__(self, token, account_id, practice=True):
        import requests
        if not token or not account_id:
            raise RuntimeError("OANDA_TOKEN / OANDA_ACCOUNT_ID missing in .env")
        host = "api-fxpractice.oanda.com" if practice else "api-fxtrade.oanda.com"
        self.base = f"https://{host}/v3/accounts/{account_id}"
        self.s = requests.Session()
        self.s.headers.update({"Authorization": f"Bearer {token}", "Content-Type": "application/json"})

    def _place(self, order, ms):
        if order.side == "BUY":
            units = int(order.notional / (ms.ask or ms.last_price))
            r = self.s.post(f"{self.base}/orders", timeout=10, json={"order": {
                "units": str(units), "instrument": order.symbol, "type": "MARKET",
                "timeInForce": "FOK", "positionFill": "DEFAULT"}})
            key = "orderFillTransaction"
        else:
            r = self.s.put(f"{self.base}/positions/{order.symbol}/close", timeout=10,
                           json={"longUnits": "ALL"})
            key = "longOrderFillTransaction"
        if r.status_code >= 400:
            raise RuntimeError(f"OANDA {r.status_code}: {r.text}")
        t = r.json().get(key)
        if not t:
            raise RuntimeError(f"OANDA order not filled: {r.text}")
        return Fill(order.symbol, order.side, abs(float(t["units"])), float(t["price"]),
                    0.0, time.time(), self.name, order_id=t["id"])  # spread already in price
