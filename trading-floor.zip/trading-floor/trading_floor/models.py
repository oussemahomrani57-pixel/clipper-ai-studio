"""Core data types shared by feeds, agents, brokers and the engine."""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Optional
import time


@dataclass
class Tick:
    """One market event: a trade and/or a best bid/ask update."""
    symbol: str
    ts: float                      # unix seconds
    price: Optional[float] = None  # last trade price
    size: float = 0.0              # trade size
    side: int = 0                  # +1 buyer-initiated, -1 seller-initiated, 0 unknown
    bid: Optional[float] = None
    ask: Optional[float] = None
    bid_size: Optional[float] = None
    ask_size: Optional[float] = None


@dataclass
class Candle:
    """A 1-second OHLCV bar with buy/sell volume split."""
    ts: int
    open: float
    high: float
    low: float
    close: float
    volume: float = 0.0
    buy_volume: float = 0.0
    sell_volume: float = 0.0
    trades: int = 0


@dataclass
class Signal:
    """An agent's opinion. score in [-1, 1] (-1 strong sell, +1 strong buy)."""
    agent: str
    score: float
    confidence: float
    reason: str
    veto: bool = False

    @property
    def action(self) -> str:
        if self.veto:
            return "VETO"
        if self.score > 0.15:
            return "BUY"
        if self.score < -0.15:
            return "SELL"
        return "HOLD"

    def to_dict(self) -> dict:
        d = asdict(self)
        d["action"] = self.action
        d["score"] = round(self.score, 3)
        d["confidence"] = round(self.confidence, 3)
        return d


@dataclass
class Order:
    symbol: str
    side: str                 # "BUY" or "SELL"
    notional: float           # amount in quote currency (USD etc.)
    qty: Optional[float] = None
    reason: str = ""
    ts: float = field(default_factory=time.time)


@dataclass
class Fill:
    symbol: str
    side: str
    qty: float
    price: float
    fee: float
    ts: float
    broker: str
    order_id: str = ""
    ok: bool = True
    error: str = ""
