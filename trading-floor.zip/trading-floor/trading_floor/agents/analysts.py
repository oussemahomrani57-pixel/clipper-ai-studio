"""The 10 analyst traders. Each one has ONE job and gives a Signal every second.

Bars are 1-second candles, so a window of 60 = the last minute.
"""
from __future__ import annotations

import numpy as np

from ..indicators import ema, rsi, macd, atr, zscore, squash
from ..market.candles import MarketState
from ..models import Signal


class Analyst:
    name = "Analyst"
    job = ""
    min_bars = 30

    def analyze(self, ms: MarketState) -> Signal:
        o, h, l, c, bv, sv = ms.arrays()
        if len(c) < self.min_bars:
            return Signal(self.name, 0.0, 0.0, f"warming up ({len(c)}/{self.min_bars}s)")
        return self._analyze(ms, o, h, l, c, bv, sv)

    def _analyze(self, ms, o, h, l, c, bv, sv) -> Signal:  # pragma: no cover
        raise NotImplementedError


class TrendTrader(Analyst):
    name, job, min_bars = "Trend", "Follows the trend with fast/slow EMA crossover", 120

    def _analyze(self, ms, o, h, l, c, bv, sv):
        fast, slow = ema(c, 20)[-1], ema(c, 100)[-1]
        gap = (fast - slow) / slow * 100
        a = atr(h, l, c, 30) / c[-1] * 100 or 1e-6
        s = squash(gap / (a * 3))
        return Signal(self.name, s, min(1, abs(s) + 0.2),
                      f"EMA20 {'above' if gap > 0 else 'below'} EMA100 by {gap:.3f}%")


class MomentumTrader(Analyst):
    name, job, min_bars = "Momentum", "Buys strength, sells weakness (rate of change)", 60

    def _analyze(self, ms, o, h, l, c, bv, sv):
        roc_short = (c[-1] / c[-15] - 1) * 100
        roc_long = (c[-1] / c[-60] - 1) * 100
        vol = np.std(np.diff(np.log(c[-60:]))) * 100 * np.sqrt(15) or 1e-6
        s = squash((0.6 * roc_short + 0.4 * roc_long / 2) / vol)
        agree = np.sign(roc_short) == np.sign(roc_long)
        return Signal(self.name, s, 0.7 if agree else 0.35,
                      f"15s {roc_short:+.3f}%, 60s {roc_long:+.3f}%")


class MeanReversionTrader(Analyst):
    name, job, min_bars = "MeanRevert", "Fades over-stretched moves (Bollinger z-score)", 120

    def _analyze(self, ms, o, h, l, c, bv, sv):
        z = zscore(c, 120)
        s = -squash((abs(z) - 1.5) * np.sign(z)) if abs(z) > 1.5 else 0.0
        return Signal(self.name, s, min(1, abs(z) / 3),
                      f"price is {z:+.2f} std from 2-min mean")


class RSITrader(Analyst):
    name, job, min_bars = "RSI", "Reads overbought / oversold with RSI(14)", 45

    def _analyze(self, ms, o, h, l, c, bv, sv):
        r = rsi(c, 14)
        if r < 30:
            s = (30 - r) / 30
        elif r > 70:
            s = -(r - 70) / 30
        else:
            s = (r - 50) / 100  # mild momentum read in the middle zone
        return Signal(self.name, float(np.clip(s, -1, 1)), 0.6 if (r < 30 or r > 70) else 0.25,
                      f"RSI {r:.1f}")


class MACDTrader(Analyst):
    name, job, min_bars = "MACD", "Trades MACD histogram turns", 60

    def _analyze(self, ms, o, h, l, c, bv, sv):
        m, sig, hist = macd(c, 12, 26, 9)
        scale = np.std(hist[-120:]) or 1e-9
        s = squash(hist[-1] / scale / 1.5)
        turning = np.sign(hist[-1]) != np.sign(hist[-5])
        return Signal(self.name, s, 0.7 if turning else 0.45,
                      f"hist {hist[-1]:+.4g}{' (cross!)' if turning else ''}")


class BreakoutTrader(Analyst):
    name, job, min_bars = "Breakout", "Catches breaks of the 3-minute range (Donchian)", 180

    def _analyze(self, ms, o, h, l, c, bv, sv):
        hi, lo = h[-181:-1].max(), l[-181:-1].min()
        rng = hi - lo or 1e-9
        p = c[-1]
        if p > hi:
            return Signal(self.name, 0.9, 0.8, f"broke ABOVE 3m high {hi:.6g}")
        if p < lo:
            return Signal(self.name, -0.9, 0.8, f"broke BELOW 3m low {lo:.6g}")
        pos = (p - lo) / rng  # 0..1 inside range
        return Signal(self.name, (pos - 0.5) * 0.4, 0.2, f"inside range ({pos*100:.0f}%)")


class VolumeTrader(Analyst):
    name, job, min_bars = "Volume", "Watches volume spikes and price vs VWAP", 120

    def _analyze(self, ms, o, h, l, c, bv, sv):
        vol = bv + sv
        if vol[-120:].sum() == 0:
            return Signal(self.name, 0.0, 0.0, "no trade volume on this market")
        vwap = (c[-120:] * vol[-120:]).sum() / vol[-120:].sum()
        recent, base = vol[-10:].mean(), vol[-120:].mean() or 1e-9
        spike = recent / base
        direction = np.sign(c[-1] - c[-10])
        above = (c[-1] - vwap) / vwap * 100
        s = squash(direction * max(0, spike - 1) * 0.8 + above * 5)
        return Signal(self.name, s, min(1, 0.3 + max(0, spike - 1) * 0.3),
                      f"volume x{spike:.1f}, {above:+.3f}% vs VWAP")


class OrderFlowTrader(Analyst):
    name, job, min_bars = "OrderFlow", "Reads buyer vs seller aggression and the order book", 20

    def _analyze(self, ms, o, h, l, c, bv, sv):
        b, s_ = bv[-30:].sum(), sv[-30:].sum()
        flow = (b - s_) / (b + s_) if (b + s_) > 0 else 0.0
        book = 0.0
        if ms.bid_size and ms.ask_size:
            book = (ms.bid_size - ms.ask_size) / (ms.bid_size + ms.ask_size)
        s = float(np.clip(0.7 * flow + 0.3 * book, -1, 1))
        return Signal(self.name, s, 0.3 + 0.5 * abs(flow),
                      f"aggressor flow {flow:+.2f}, book imbalance {book:+.2f}")


class PatternTrader(Analyst):
    name, job, min_bars = "Pattern", "Spots candlestick patterns on 15-second bars", 90

    def _analyze(self, ms, o, h, l, c, bv, sv):
        # resample 1s -> 15s bars
        n = (len(c) // 15) * 15
        O = o[-n:].reshape(-1, 15)[:, 0]
        H = h[-n:].reshape(-1, 15).max(1)
        L = l[-n:].reshape(-1, 15).min(1)
        C = c[-n:].reshape(-1, 15)[:, -1]
        if len(C) < 3:
            return Signal(self.name, 0, 0, "not enough bars")
        po, pc, co, cc = O[-2], C[-2], O[-1], C[-1]
        body = abs(cc - co)
        rng = H[-1] - L[-1] or 1e-9
        if pc < po and cc > co and cc >= po and co <= pc:
            return Signal(self.name, 0.8, 0.65, "bullish engulfing")
        if pc > po and cc < co and cc <= po and co >= pc:
            return Signal(self.name, -0.8, 0.65, "bearish engulfing")
        lower = min(co, cc) - L[-1]
        upper = H[-1] - max(co, cc)
        if lower > 2 * body and upper < body and C[-3] > C[-1]:
            return Signal(self.name, 0.6, 0.5, "hammer after drop")
        if upper > 2 * body and lower < body and C[-3] < C[-1]:
            return Signal(self.name, -0.6, 0.5, "shooting star after rise")
        return Signal(self.name, 0.0, 0.1, f"no pattern (body {body/rng*100:.0f}% of range)")


class RegimeTrader(Analyst):
    name, job, min_bars = "Regime", "Decides if market is trending or choppy (efficiency ratio)", 120

    def _analyze(self, ms, o, h, l, c, bv, sv):
        w = c[-120:]
        net = w[-1] - w[0]
        path = np.abs(np.diff(w)).sum() or 1e-9
        er = abs(net) / path  # 1 = clean trend, ~0 = noise
        s = float(np.sign(net) * er * 2) if er > 0.15 else 0.0
        kind = "TRENDING" if er > 0.3 else "choppy" if er < 0.15 else "mixed"
        return Signal(self.name, float(np.clip(s, -1, 1)), er, f"{kind} (efficiency {er:.2f})")


ALL_ANALYSTS = [TrendTrader, MomentumTrader, MeanReversionTrader, RSITrader, MACDTrader,
                BreakoutTrader, VolumeTrader, OrderFlowTrader, PatternTrader, RegimeTrader]
