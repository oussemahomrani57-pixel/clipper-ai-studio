"""Trader #11 (Risk Manager) and Trader #12 (Head Trader).

The Head Trader collects the 10 analysts' votes, weights each analyst by how
often it has been RIGHT recently, and makes the final call. The Risk Manager
can veto any entry and forces exits (stop-loss, take-profit, trailing stop).
"""
from __future__ import annotations

import time
from collections import deque
from typing import Dict, List, Optional

import numpy as np

from ..indicators import atr
from ..market.candles import MarketState
from ..models import Signal
from ..portfolio import Portfolio


class RiskManager:
    name = "Risk"
    job = "Protects the money: position limits, stop-loss, daily loss limit, veto"

    def __init__(self, cfg: dict):
        self.max_positions = cfg.get("max_open_positions", 3)
        self.position_pct = cfg.get("position_size_pct", 10) / 100
        self.max_position_usd = cfg.get("max_position_usd", 100)
        self.stop_loss = cfg.get("stop_loss_pct", 0.8)
        self.take_profit = cfg.get("take_profit_pct", 1.5)
        self.trailing = cfg.get("trailing_stop_pct", 0.6)
        self.max_daily_loss = cfg.get("max_daily_loss_pct", 3)
        self.max_trades_hour = cfg.get("max_trades_per_hour", 20)
        self.cooldown = cfg.get("cooldown_seconds", 60)
        self.max_spread = cfg.get("max_spread_pct", 0.15)
        self.max_hold = cfg.get("max_hold_minutes", 60) * 60
        self.stale = cfg.get("stale_data_seconds", 10)
        self._last_exit: Dict[str, float] = {}
        self._trade_times = deque()
        self.halted = False
        self.halt_reason = ""

    def size(self, pf: Portfolio, prices) -> float:
        return min(pf.equity(prices) * self.position_pct, self.max_position_usd, pf.cash * 0.98)

    def check_entry(self, ms: MarketState, pf: Portfolio, prices, now: float) -> Signal:
        def veto(r):
            return Signal(self.name, 0, 1, r, veto=True)

        if self.halted:
            return veto(f"trading halted: {self.halt_reason}")
        eq = pf.equity(prices)
        day_loss = (pf.day_start_equity - eq) / pf.day_start_equity * 100
        if day_loss >= self.max_daily_loss:
            self.halted, self.halt_reason = True, f"daily loss {day_loss:.2f}% hit limit"
            return veto(self.halt_reason)
        if ms.symbol in pf.positions:
            return veto("already in a position")
        if len(pf.positions) >= self.max_positions:
            return veto(f"max {self.max_positions} open positions")
        if now - ms.last_tick_ts > self.stale:
            return veto("market data is stale")
        sp = ms.spread_pct
        if sp is not None and sp > self.max_spread:
            return veto(f"spread too wide ({sp:.3f}%)")
        if now - self._last_exit.get(ms.symbol, 0) < self.cooldown:
            return veto("cooling down after last trade")
        while self._trade_times and now - self._trade_times[0] > 3600:
            self._trade_times.popleft()
        if len(self._trade_times) >= self.max_trades_hour:
            return veto("too many trades this hour")
        if self.size(pf, prices) < 5:
            return veto("not enough cash")
        o, h, l, c, *_ = ms.arrays()
        if len(c) > 60:
            vol = atr(h, l, c, 30) / c[-1] * 100
            if vol > self.stop_loss:  # one-second ATR bigger than whole stop = chaos
                return veto(f"volatility too high (ATR {vol:.3f}%)")
        return Signal(self.name, 0, 1, "OK to trade")

    def check_exit(self, ms: MarketState, pf: Portfolio, now: float) -> Optional[str]:
        pos = pf.positions.get(ms.symbol)
        if not pos or ms.last_price is None:
            return None
        p = ms.bid or ms.last_price
        pos.peak = max(pos.peak, p)
        chg = pos.pnl_pct(p)
        if chg <= -self.stop_loss:
            return f"STOP-LOSS {chg:.2f}%"
        if chg >= self.take_profit:
            return f"TAKE-PROFIT {chg:+.2f}%"
        drop = (pos.peak - p) / pos.peak * 100
        if pos.peak > pos.entry * (1 + self.trailing / 100) and drop >= self.trailing:
            return f"TRAILING STOP (-{drop:.2f}% from peak)"
        if now - pos.opened_ts > self.max_hold:
            return "max hold time reached"
        if self.halted:
            return f"halted: {self.halt_reason}"
        return None

    def record_trade(self, symbol: str, side: str, now: float):
        self._trade_times.append(now)
        if side == "SELL":
            self._last_exit[symbol] = now


class HeadTrader:
    name = "Head"
    job = "Weighs every trader's vote by their track record and makes the final call"

    def __init__(self, analyst_names: List[str], cfg: dict):
        self.entry = cfg.get("entry_threshold", 0.35)
        self.exit = cfg.get("exit_threshold", -0.15)
        self.min_agree = cfg.get("min_agreeing_traders", 5)
        self.horizon = cfg.get("score_horizon_seconds", 30)
        self.accuracy = {n: 0.5 for n in analyst_names}
        self.calls = {n: 0 for n in analyst_names}
        self._pending: Dict[str, deque] = {}

    def weight(self, name: str) -> float:
        return float(np.clip(1 + 4 * (self.accuracy[name] - 0.5), 0.1, 2.5))

    def learn(self, symbol: str, price: float, now: float, signals: List[Signal]):
        """Remember today's votes; grade the votes from `horizon` seconds ago."""
        q = self._pending.setdefault(symbol, deque())
        q.append((now, price, {s.agent: s.score for s in signals if s.confidence > 0}))
        while q and now - q[0][0] >= self.horizon:
            _, p0, votes = q.popleft()
            ret = price / p0 - 1
            if abs(ret) < 1e-5:
                continue  # price didn't move: nobody is graded
            for name, sc in votes.items():
                if abs(sc) < 0.15:
                    continue
                hit = 1.0 if np.sign(sc) == np.sign(ret) else 0.0
                self.accuracy[name] = 0.97 * self.accuracy[name] + 0.03 * hit
                self.calls[name] += 1

    def decide(self, signals: List[Signal], in_position: bool) -> dict:
        num = den = 0.0
        buy = sell = 0
        for s in signals:
            w = self.weight(s.agent) * s.confidence
            num += w * s.score
            den += w
            buy += s.action == "BUY"
            sell += s.action == "SELL"
        combined = num / den if den else 0.0
        action, why = "HOLD", ""
        if not in_position and combined >= self.entry and buy >= self.min_agree:
            action, why = "BUY", f"{buy} traders bullish, score {combined:+.2f}"
        elif in_position and (combined <= self.exit or sell >= self.min_agree):
            action, why = "SELL", f"{sell} traders bearish, score {combined:+.2f}"
        else:
            why = f"score {combined:+.2f} ({buy} buy / {sell} sell)"
        return {"action": action, "score": combined, "buy_votes": buy,
                "sell_votes": sell, "reason": why}

    def leaderboard(self) -> List[dict]:
        return sorted(({"agent": n, "accuracy": a * 100, "weight": self.weight(n),
                        "graded_calls": self.calls[n]} for n, a in self.accuracy.items()),
                      key=lambda d: -d["accuracy"])
