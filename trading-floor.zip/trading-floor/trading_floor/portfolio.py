"""Tracks the money the bot is allowed to use, open positions and P&L."""
from __future__ import annotations

import time
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional

from .models import Fill


@dataclass
class Position:
    symbol: str
    market: str
    qty: float
    entry: float
    opened_ts: float
    peak: float
    cost: float  # entry notional incl. fees

    def pnl(self, price: float) -> float:
        return self.qty * price - self.cost

    def pnl_pct(self, price: float) -> float:
        return (price / self.entry - 1) * 100


@dataclass
class Portfolio:
    budget: float                      # money the bot may use (USD)
    cash: float = 0.0
    realized: float = 0.0
    fees: float = 0.0
    positions: Dict[str, Position] = field(default_factory=dict)
    trades: List[dict] = field(default_factory=list)
    day: str = ""
    day_start_equity: float = 0.0

    def __post_init__(self):
        self.cash = self.budget
        self.day = time.strftime("%Y-%m-%d")
        self.day_start_equity = self.budget

    def equity(self, prices: Dict[str, float]) -> float:
        return self.cash + sum(p.qty * prices.get(s, p.entry) for s, p in self.positions.items())

    def roll_day(self, prices):
        today = time.strftime("%Y-%m-%d")
        if today != self.day:
            self.day, self.day_start_equity = today, self.equity(prices)

    def apply(self, f: Fill, market: str) -> Optional[dict]:
        if not f.ok or f.qty <= 0:
            return None
        self.fees += f.fee
        if f.side == "BUY":
            cost = f.qty * f.price + f.fee
            self.cash -= cost
            self.positions[f.symbol] = Position(f.symbol, market, f.qty, f.price, f.ts, f.price, cost)
            rec = {"ts": f.ts, "symbol": f.symbol, "side": "BUY", "qty": f.qty, "price": f.price,
                   "fee": f.fee, "pnl": None, "broker": f.broker}
        else:
            pos = self.positions.pop(f.symbol, None)
            proceeds = f.qty * f.price - f.fee
            self.cash += proceeds
            pnl = proceeds - (pos.cost if pos else 0)
            self.realized += pnl
            rec = {"ts": f.ts, "symbol": f.symbol, "side": "SELL", "qty": f.qty, "price": f.price,
                   "fee": f.fee, "pnl": pnl, "broker": f.broker}
        self.trades.append(rec)
        self.trades = self.trades[-500:]
        return rec

    def snapshot(self, prices) -> dict:
        eq = self.equity(prices)
        wins = [t for t in self.trades if t["pnl"] is not None and t["pnl"] > 0]
        closed = [t for t in self.trades if t["pnl"] is not None]
        return {
            "budget": self.budget, "cash": self.cash, "equity": eq,
            "pnl": eq - self.budget, "pnl_pct": (eq / self.budget - 1) * 100,
            "day_pnl": eq - self.day_start_equity, "realized": self.realized, "fees": self.fees,
            "win_rate": (len(wins) / len(closed) * 100) if closed else None,
            "closed_trades": len(closed),
            "positions": [dict(asdict(p), price=prices.get(s, p.entry),
                               pnl=p.pnl(prices.get(s, p.entry)),
                               pnl_pct=p.pnl_pct(prices.get(s, p.entry)))
                          for s, p in self.positions.items()],
            "trades": self.trades[-30:][::-1],
        }
