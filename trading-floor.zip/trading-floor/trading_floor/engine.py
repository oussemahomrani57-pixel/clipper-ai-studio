"""The trading floor: runs the feeds, asks the 12 traders every second, executes."""
from __future__ import annotations

import asyncio
import logging
import os
import time
from collections import deque
from typing import Dict, List

from .agents.analysts import ALL_ANALYSTS
from .agents.desk import HeadTrader, RiskManager
from .brokers import AlpacaBroker, BinanceBroker, OandaBroker, PaperBroker, Broker
from .market.candles import MarketState
from .market.feeds import AlpacaFeed, BinanceFeed, OandaFeed, SimulatedFeed, Feed
from .models import Order, Tick
from .portfolio import Portfolio

log = logging.getLogger("engine")
LIVE_PHRASE = "YES_I_UNDERSTAND_THE_RISK"

SIM_PRICES = {"BTCUSDT": 90000, "ETHUSDT": 3000, "SOLUSDT": 140, "AAPL": 230, "TSLA": 350,
              "NVDA": 180, "EUR_USD": 1.08, "GBP_USD": 1.27, "USD_JPY": 150}


class Engine:
    def __init__(self, cfg: dict, demo: bool = False):
        self.cfg = cfg
        self.mode = cfg.get("mode", "paper").lower()
        if self.mode == "live" and os.getenv("CONFIRM_LIVE_TRADING") != LIVE_PHRASE:
            raise SystemExit(
                "\n[STOP] mode is 'live' but CONFIRM_LIVE_TRADING is not set.\n"
                f"Add CONFIRM_LIVE_TRADING={LIVE_PHRASE} to .env only if you accept that\n"
                "this bot can LOSE REAL MONEY. Start with testnet/practice accounts first.\n")
        self.demo = demo
        self.analysts = [A() for A in ALL_ANALYSTS]
        self.risk = RiskManager(cfg.get("risk", {}))
        self.head = HeadTrader([a.name for a in self.analysts], cfg.get("head_trader", {}))
        self.pf = Portfolio(budget=float(cfg.get("budget_usd", 1000)))
        self.markets: Dict[str, MarketState] = {}
        self.feeds: List[Feed] = []
        self.brokers: Dict[str, Broker] = {}
        self.feed_kind: Dict[str, str] = {}
        self.latest: Dict[str, dict] = {}
        self.events = deque(maxlen=200)
        self.history: Dict[str, deque] = {}
        self.markers: Dict[str, deque] = {}
        self._busy = set()
        self.started = time.time()
        self.paused = False
        self._build()

    # ------------------------------------------------------------------ setup
    def _build(self):
        env = os.getenv
        paper = PaperBroker(**self.cfg.get("paper", {}))
        for market, mc in self.cfg.get("markets", {}).items():
            if not mc.get("enabled", True):
                continue
            syms = [s.upper() for s in mc.get("symbols", [])]
            kind = "simulated" if self.demo else mc.get("feed", "auto")
            feed, broker = None, paper
            try:
                if market == "crypto" and kind in ("auto", "binance"):
                    feed = BinanceFeed(syms)
                    if self.mode == "live":
                        broker = BinanceBroker(env("BINANCE_KEY"), env("BINANCE_SECRET"),
                                               testnet=mc.get("testnet", True))
                elif market == "stocks" and kind in ("auto", "alpaca"):
                    if kind == "alpaca" or (env("ALPACA_KEY") and env("ALPACA_SECRET")):
                        feed = AlpacaFeed(syms, env("ALPACA_KEY"), env("ALPACA_SECRET"),
                                          mc.get("data_feed", "iex"))
                        if self.mode == "live":
                            broker = AlpacaBroker(env("ALPACA_KEY"), env("ALPACA_SECRET"),
                                                  paper=mc.get("paper_account", True))
                elif market == "forex" and kind in ("auto", "oanda"):
                    if kind == "oanda" or (env("OANDA_TOKEN") and env("OANDA_ACCOUNT_ID")):
                        practice = mc.get("practice", True)
                        feed = OandaFeed(syms, env("OANDA_TOKEN"), env("OANDA_ACCOUNT_ID"), practice)
                        if self.mode == "live":
                            broker = OandaBroker(env("OANDA_TOKEN"), env("OANDA_ACCOUNT_ID"), practice)
            except RuntimeError as e:
                raise SystemExit(f"[{market}] {e}")
            if feed is None:  # no keys / demo -> simulated prices, always paper money
                feed = SimulatedFeed(syms, market=market, start_prices=SIM_PRICES)
                broker = paper
                if not self.demo:
                    log.warning("%s: no API keys -> using SIMULATED prices", market)
            self.feeds.append(feed)
            self.feed_kind[market] = "simulated" if isinstance(feed, SimulatedFeed) else feed.__class__.__name__
            self.brokers[market] = broker
            for s in syms:
                self.markets[s] = MarketState(s, market)
                self.history[s] = deque(maxlen=900)
                self.markers[s] = deque(maxlen=100)

    def _on_tick(self, t: Tick):
        ms = self.markets.get(t.symbol)
        if ms:
            ms.on_tick(t)

    def log_event(self, kind: str, msg: str, symbol: str = ""):
        e = {"ts": time.time(), "kind": kind, "symbol": symbol, "msg": msg}
        self.events.appendleft(e)
        log.info("[%s] %s %s", kind, symbol, msg)

    def prices(self):
        return {s: m.last_price for s, m in self.markets.items() if m.last_price}

    # ------------------------------------------------------------------ main loop
    async def run(self):
        for f in self.feeds:
            asyncio.create_task(f.run(self._on_tick))
        self.log_event("info", f"Trading floor open — mode {self.mode.upper()}, "
                               f"{len(self.markets)} symbols, 12 traders on duty")
        while True:
            now = time.time()
            await asyncio.sleep(1 - (now % 1))  # tick exactly on each second
            try:
                self.step(time.time())
            except Exception:  # noqa: BLE001
                log.exception("step failed")

    def step(self, now: float):
        prices = self.prices()
        self.pf.roll_day(prices)
        for sym, ms in self.markets.items():
            ms.roll(now)
            if ms.last_price is None:
                continue
            self.history[sym].append((int(now), ms.last_price))
            signals = [a.analyze(ms) for a in self.analysts]
            self.head.learn(sym, ms.last_price, now, signals)
            in_pos = sym in self.pf.positions
            decision = self.head.decide(signals, in_pos)
            risk_sig = None

            exit_reason = self.risk.check_exit(ms, self.pf, now)
            if in_pos and exit_reason:
                decision = dict(decision, action="SELL", reason=f"Risk: {exit_reason}")
            if decision["action"] == "BUY":
                risk_sig = self.risk.check_entry(ms, self.pf, prices, now)
                if risk_sig.veto:
                    decision = dict(decision, action="HOLD", reason=f"BUY vetoed — {risk_sig.reason}")
            if risk_sig is None:
                risk_sig = self.risk.check_entry(ms, self.pf, prices, now) if not in_pos else None

            if self.paused and decision["action"] == "BUY":
                decision = dict(decision, action="HOLD", reason="paused from dashboard")
            if decision["action"] in ("BUY", "SELL") and sym not in self._busy:
                self._busy.add(sym)
                asyncio.get_running_loop().create_task(self._execute(ms, decision, prices))

            self.latest[sym] = {
                "symbol": sym, "market": ms.market, "price": ms.last_price,
                "bid": ms.bid, "ask": ms.ask, "spread_pct": ms.spread_pct,
                "bars": len(ms.candles), "ticks": ms.tick_count,
                "signals": [s.to_dict() for s in signals],
                "risk": risk_sig.to_dict() if risk_sig else
                {"agent": "Risk", "action": "WATCH", "score": 0, "confidence": 1,
                 "reason": "guarding open position", "veto": False},
                "decision": decision,
            }

    async def _execute(self, ms: MarketState, decision: dict, prices):
        sym = ms.symbol
        self._busy.add(sym)  # also set by step() so the next second can't double-order
        try:
            broker = self.brokers[ms.market]
            if decision["action"] == "BUY":
                order = Order(sym, "BUY", self.risk.size(self.pf, prices), reason=decision["reason"])
            else:
                pos = self.pf.positions.get(sym)
                if not pos:
                    return
                order = Order(sym, "SELL", pos.qty * ms.last_price, qty=pos.qty, reason=decision["reason"])
            fill = await broker.place(order, ms)
            if not fill.ok:
                self.log_event("error", f"{order.side} failed on {broker.name}: {fill.error}", sym)
                return
            rec = self.pf.apply(fill, ms.market)
            self.risk.record_trade(sym, fill.side, time.time())
            self.markers[sym].append((int(fill.ts), fill.price, fill.side))
            pnl = f" P&L {rec['pnl']:+.2f}" if rec and rec["pnl"] is not None else ""
            self.log_event("trade", f"{fill.side} {fill.qty:.6g} @ {fill.price:.6g} "
                                    f"[{broker.name}]{pnl} — {decision['reason']}", sym)
        finally:
            self._busy.discard(sym)

    # ------------------------------------------------------------------ controls
    async def panic(self):
        """Kill switch: stop new trades and close everything."""
        self.paused = True
        self.log_event("warn", "KILL SWITCH — closing all positions")
        prices = self.prices()
        for sym in list(self.pf.positions):
            ms = self.markets[sym]
            await self._execute(ms, {"action": "SELL", "reason": "kill switch"}, prices)

    def resume(self):
        self.paused = False
        self.risk.halted = False
        self.log_event("info", "Trading resumed")

    def snapshot(self) -> dict:
        prices = self.prices()
        return {
            "ts": time.time(), "mode": self.mode, "demo": self.demo, "paused": self.paused,
            "halted": self.risk.halted, "halt_reason": self.risk.halt_reason,
            "uptime": time.time() - self.started,
            "feeds": [{"market": f.market, "kind": self.feed_kind.get(f.market), "connected": f.connected,
                       "error": f.last_error, "broker": self.brokers[f.market].name} for f in self.feeds],
            "traders": [{"name": a.name, "job": a.job} for a in self.analysts] +
                       [{"name": self.risk.name, "job": self.risk.job},
                        {"name": self.head.name, "job": self.head.job}],
            "leaderboard": self.head.leaderboard(),
            "symbols": list(self.latest.values()),
            "portfolio": self.pf.snapshot(prices),
            "events": list(self.events)[:60],
        }

    def chart(self, sym: str) -> dict:
        return {"symbol": sym, "points": list(self.history.get(sym, [])),
                "markers": list(self.markers.get(sym, []))}
