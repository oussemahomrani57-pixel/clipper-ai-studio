"""Small, dependency-free (numpy only) technical indicators."""
from __future__ import annotations

import numpy as np


def ema(x: np.ndarray, n: int) -> np.ndarray:
    if len(x) == 0:
        return x
    a = 2 / (n + 1)
    out = np.empty_like(x, dtype=float)
    out[0] = x[0]
    for i in range(1, len(x)):
        out[i] = a * x[i] + (1 - a) * out[i - 1]
    return out


def rsi(close: np.ndarray, n: int = 14) -> float:
    if len(close) < n + 1:
        return 50.0
    d = np.diff(close[-(n * 3):])
    up = np.where(d > 0, d, 0.0)
    dn = np.where(d < 0, -d, 0.0)
    au, ad = ema(up, n)[-1], ema(dn, n)[-1]
    if ad == 0:
        return 100.0 if au > 0 else 50.0
    rs = au / ad
    return 100 - 100 / (1 + rs)


def macd(close: np.ndarray, fast=12, slow=26, sig=9):
    m = ema(close, fast) - ema(close, slow)
    s = ema(m, sig)
    return m, s, m - s


def atr(high, low, close, n=14) -> float:
    if len(close) < 2:
        return 0.0
    prev = close[:-1]
    tr = np.maximum(high[1:] - low[1:], np.maximum(abs(high[1:] - prev), abs(low[1:] - prev)))
    return float(ema(tr[-(n * 3):], n)[-1])


def zscore(x: np.ndarray, n: int) -> float:
    w = x[-n:]
    sd = w.std()
    return 0.0 if sd == 0 else float((w[-1] - w.mean()) / sd)


def squash(v: float, k: float = 1.0) -> float:
    """Map any number to [-1, 1] smoothly."""
    return float(np.tanh(v * k))
