# Architecture

## Components

| Component | Runs on | Responsibilities | Why there |
|---|---|---|---|
| **Web app** (`apps/web`) | Cloudflare Pages (static) | UI, Local mode storage (localStorage + IndexedDB for video), browser chat monitor, canvas editor + MediaRecorder export | Free, global CDN, works offline-first on iPhone |
| **API Worker** (`apps/worker`) | Cloudflare Workers | Twitch OAuth (confidential client), token encryption/refresh, Helix proxy, Create Clip + confirmation | Short request/response work; free 100k req/day |
| **Database** | Supabase Postgres + Auth + Storage | Users, all records, RLS, job queue, private video bucket | Free tier, RLS gives per-user isolation without custom backend code |
| **Engine** (`apps/engine`) | Always-on VM / container | EventSub WebSocket chat monitoring, MomentDetector, auto Create Clip, FFmpeg render jobs, transcription jobs, heartbeat | Needs persistent connections and long CPU work — impossible on serverless free tiers |
| **Shared** (`packages/shared`) | everywhere | Scoring engine, earnings maths, subtitle formats, crypto, Twitch client | One tested implementation for browser + server |

## Data modes in the web app

`lib/store.ts` exposes one API (`useStore`, `db.insert/update/remove`) with two backends:
- **Local** — no account; localStorage (records) + IndexedDB (video blobs).
- **Cloud** — Supabase PostgREST with the user's JWT; RLS enforces ownership.
DEMO DATA is local-only, flagged `is_demo`, badged everywhere and removable.

## Auto clipping pipeline

```
EventSub channel.chat.message ─► MomentDetector.addMessage
stream.online / channel.update ─► MomentDetector.addEvent
every 2 s ─► evaluate():
   score = Σ weight_i × component_i   (velocity vs baseline, reactions/repeats, keywords, events, chatter breadth)
   guards: min messages · min score · re-arm hysteresis (dup prevention) · cooldown · hourly cap · daily cap
   ─► markTriggered (before the request → no duplicate in-flight triggers)
   ─► detection_events row (reasons) ─► POST /helix/clips ─► clips row (status processing)
   ─► confirm after 15 s (retry ×3) ─► ready | failed + notification
429 ─► global backoff using Ratelimit-Reset
```
Trigger history is reloaded from `detection_events` on restart so caps survive crashes.

## Job system

`jobs` table + `claim_job(worker, kinds)` SQL function (`FOR UPDATE SKIP LOCKED`) → no job runs twice.
Each job: status, attempts/max_attempts, error, run_after (exponential backoff), timestamps, `dedupe_key` unique while queued/running.
Kinds: `render` (FFmpeg, argument array — no shell), `transcribe` (whisper.cpp / OpenAI), with `clip_create`, `publish`, `monitor` reserved.

## Security model

- Browser holds: Supabase anon key + its own session. Nothing else.
- Worker/Engine hold: Twitch secret, service role key, encryption key.
- `twitch_tokens`, `social_tokens`: RLS enabled with **no policies** → unreadable by any browser session.
- `twitch_accounts`: browser can read its own; only the Worker writes.
- `jobs`: browser may insert `queued` jobs and cancel them; cannot mark them succeeded.
- OAuth `state` = HMAC-SHA256(userId.ts.nonce), 10-minute expiry, timing-safe compare.
- Input validation: Twitch logins/IDs regex-checked server-side, URLs validated, numeric fields constrained in SQL.
- Static hosting headers in `apps/web/public/_headers`.

## Future AI signals (designed, not built)
Audio excitement (RMS/pitch spikes from the HLS audio of your *own* channel), speech keywords via whisper streaming, scene-change detection. They plug in as extra `StreamEvent`s / weighted components in `MomentDetector` — the "Other" weight is reserved for them.
