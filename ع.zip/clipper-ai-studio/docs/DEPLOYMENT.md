# Deployment guide (iPhone-friendly)

Order: **GitHub → Supabase → Twitch → Worker → Pages → Engine**. Steps 1–5 are free and can be done in Safari.

## 1. GitHub (free)
- Create a **private** repository and upload this project (GitHub web → *Add file → Upload files*, or the GitHub iOS app / Working Copy).
- `.gitignore` already excludes `.env*` files. Never upload real secrets.

## 2. Supabase (free tier)
1. supabase.com → New project (choose an EU region if you're in France).
2. **SQL Editor** → paste `supabase/migrations/0001_init.sql` → Run.
3. **Authentication → URL Configuration** → Site URL = your Pages URL (step 5), add it to Redirect URLs too.
4. **Authentication → Providers → Email**: enabled (magic link).
5. **Project Settings → API**: copy *Project URL*, *anon key* (web) and *service_role key* (Worker/Engine only).

> Free projects pause after a period of inactivity; a running Engine (heartbeat every 30 s) keeps it active.

## 3. Twitch app
Follow [`SETUP_TWITCH.md`](SETUP_TWITCH.md).

## 4. API Worker (Cloudflare Workers free plan)
**From a computer:**
```bash
cd apps/worker && npm install
# edit wrangler.toml [vars]
npx wrangler secret put TWITCH_CLIENT_SECRET
npx wrangler secret put SUPABASE_SERVICE_ROLE_KEY
npx wrangler secret put TOKEN_ENCRYPTION_KEY
npx wrangler secret put OAUTH_STATE_SECRET
npx wrangler deploy
```
**From iPhone:** Cloudflare dashboard → Workers & Pages → Create → *Import a repository* → root directory `apps/worker` (deploy command `npx wrangler deploy`) → then Settings → Variables: add the vars, and the 4 secrets as **Encrypted**.

Check: open `https://<worker>/api/health` → `{"ok":true,"missing":[]}`.

## 5. Web app (Cloudflare Pages, free)
Workers & Pages → Create → Pages → connect the GitHub repo:
- Build command: `npm install && npm run build -w @clipper/web`
- Output directory: `apps/web/dist`
- Environment variables: `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`, `VITE_API_URL`, and `NODE_VERSION=22`

Then set the Worker's `APP_URL` to the Pages URL (exact origin — it's used for CORS and redirects).
On iPhone: open the site in Safari → Share → **Add to Home Screen** for a full-screen app.

## 6. Engine (24/7 monitoring + FFmpeg) — needs an always-on machine
This is the one component that can't be free *and* reliable on serverless. Options:
- **Free:** Oracle Cloud "Always Free" ARM VM (requires a card for identity verification; capacity not always available).
- **Cheap:** a small VPS (Hetzner, OVH, Scaleway…) — roughly €4–6/month; enough for several channels + light FFmpeg.
- **Test only:** a spare PC/Raspberry Pi at home.

```bash
git clone <your repo> && cd clipper-ai-studio
docker build -f apps/engine/Dockerfile -t clipper-engine .
docker run -d --restart unless-stopped --name clipper-engine --env-file engine.env clipper-engine
```
`engine.env` contains the Engine section of `.env.example` (same secrets as the Worker). Without Docker: install Node 22 + FFmpeg, then `cd apps/engine && npm start`.

Check: Dashboard → "Auto engine: Online" (heartbeat < 90 s old). The app never shows it online without a real heartbeat.

### Optional: free transcription with whisper.cpp
Build whisper.cpp on the Engine host, download `ggml-base.bin`, set `TRANSCRIBE_PROVIDER=whisper_cpp` and `WHISPER_CMD`. CPU transcription of a 30 s clip takes seconds to a minute depending on the VM.

## Updating
Push to GitHub → Pages and the Worker (if Git-connected) redeploy automatically. Engine: `git pull && docker build … && docker restart`.
