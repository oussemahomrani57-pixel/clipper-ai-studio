# Testing

## Automated (Node 22, no dependencies)

```bash
npm test                              # runs both suites below
node --experimental-strip-types --test packages/shared/test/*.test.ts
node --experimental-strip-types --test apps/engine/test/*.test.ts
npm run typecheck -w @clipper/web     # after npm install
npm run typecheck -w @clipper/worker
npm run typecheck -w @clipper/engine
```

Covered:
- Viral scoring: quiet chat doesn't trigger; reaction burst triggers once; re-arm/cooldown block duplicates; hourly limit; weight normalization.
- Earnings: no CPM → 0 (never invented); caps; estimated vs confirmed.
- Subtitles: SRT/VTT round-trip.
- Crypto: AES-GCM round-trip, tamper detection.
- FFmpeg argument builder: trim, crop, 9:16 pad, preset fallback, no shell injection.

## Manual checklist

**Local mode (no setup)**
- [ ] Every page renders on iPhone width (390 px) and desktop; bottom tab bar + "More" sheet work.
- [ ] Streamers: add `shroud` by username → card appears; favorite / monitor toggles persist after reload.
- [ ] Live Monitor: Start → state `connected`; on a live channel the chart moves and the score updates; Stop works.
- [ ] Auto Clipper: change weights → normalized %; simulator gauge reacts; settings persist.
- [ ] Library: upload a video → appears as `upload`; preview plays; CSV/JSON export downloads.
- [ ] Subtitles: add/split/delete captions, save, export SRT, import it back.
- [ ] Editor: Fill 9:16, text overlay, Export → MP4 on Safari (WebM/MP4 on Chrome) at 1080×1920; new clip in library.
- [ ] Publisher: create post records; "Share video to app" opens the iOS share sheet; confirm with a TikTok URL → status published.
- [ ] Campaigns: add campaign with CPM 1, max 30; add 2 submissions of 20 000 views → estimate capped at 30.
- [ ] Settings: Load / remove DEMO DATA; export + import backup.

**Cloud mode**
- [ ] `/api/health` ok; magic-link sign-in; Dashboard shows Cloud + Backend online.
- [ ] Connect Twitch → account listed with scopes; Disconnect revokes.
- [ ] Manual clip on a live channel → processing → ready with embed; on an offline channel → clear error + retry.
- [ ] RLS: with a second account, the first account's rows are invisible (try `GET /rest/v1/clips` with each JWT).
- [ ] Engine: heartbeat appears; enable Auto clipping + one streamer; detection events with reasons appear; cooldown respected.
- [ ] Render job: queue from the Editor → Engine produces an MP4 in storage → notification.
