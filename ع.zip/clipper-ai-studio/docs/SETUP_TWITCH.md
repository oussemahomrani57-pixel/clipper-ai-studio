# Twitch application setup

Free. Takes ~5 minutes, works from Safari on iPhone.

1. Enable two-factor authentication on your Twitch account (required to register apps).
2. Open **https://dev.twitch.tv/console/apps** → **Register Your Application**.
3. Fill in:
   - **Name**: e.g. `Clipper AI Studio <yourname>` (must be unique on Twitch)
   - **OAuth Redirect URLs**: `https://clipper-ai-api.<your-subdomain>.workers.dev/api/twitch/callback`
     (exactly your Worker URL + `/api/twitch/callback`; for local dev also add `http://localhost:8787/api/twitch/callback`)
   - **Category**: Application Integration
   - **Client Type**: **Confidential** (the secret stays on the server)
4. Save → **Manage** → copy the **Client ID** → `TWITCH_CLIENT_ID`.
5. **New Secret** → copy it once → `TWITCH_CLIENT_SECRET` (Worker + Engine secret only — never in the web app or GitHub).

## Scopes requested (minimum)

| Scope | Why |
|---|---|
| `clips:edit` | Create Clip (`POST /helix/clips`) — manual and automatic clips |
| `user:read:chat` | Engine reads chat of monitored channels via EventSub `channel.chat.message` (WebSocket transport) |

Search, user lookups and live status use an **app access token** (no user scope).
Optional later: `channel:manage:clips` / `editor:manage:clips` lets the broadcaster or their editors use *Get Clips Download* to fetch clip video files — only for their own channel.

## How the login flow works

1. App → `GET /api/twitch/connect` (with your Supabase session) → Worker returns Twitch's authorize URL with a signed, 10-minute `state`.
2. You approve on Twitch → Twitch redirects to the Worker callback.
3. Worker verifies `state`, exchanges the code with the secret, encrypts tokens (AES-256-GCM) and stores them; redirects to `#/settings?twitch=connected`.
4. Tokens are refreshed automatically; if refresh fails the account is marked **expired** and you get a "Reconnect" notification.
5. **Disconnect** revokes the token at Twitch and deletes it.

## Rules the app respects

- Clips can only be created on **live** channels that allow clipping; Twitch decides.
- Rate limits: the client reads `Ratelimit-Reset` on HTTP 429 and backs off (Engine pauses clip requests).
- EventSub WebSocket sessions have subscription limits; failures are logged per subscription, never hidden.
