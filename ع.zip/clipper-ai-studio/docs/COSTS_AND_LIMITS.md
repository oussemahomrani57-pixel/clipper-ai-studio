# Costs, free-tier limits and the "100 clips/day" target

Prices/limits change — check each provider's pricing page before relying on them.

| Service | Free tier used for | Watch out for | When you'd pay |
|---|---|---|---|
| Cloudflare Pages | Hosting the app | Build minutes/month | Practically never for this app |
| Cloudflare Workers | API | Daily request cap, CPU time per request | Only with heavy usage |
| Supabase | DB, Auth, Storage | DB size, **storage (1 GB)**, bandwidth, pause after inactivity | Storing many videos → move video to R2 or delete after publishing |
| Cloudflare R2 (optional) | Video storage | 10 GB free, no egress fees | Above ~10 GB |
| Engine VM | 24/7 monitoring + FFmpeg | Must be always on | ~€4–6/month VPS (or Oracle Always Free) |
| Transcription | Subtitles | whisper.cpp is free but uses CPU | OpenAI API is billed per audio minute |
| Twitch API | Everything Twitch | Rate limits per token | Free |

**Nothing paid is required** to use Local mode, the browser monitor, the editor, subtitles (manual), publisher, campaigns or analytics.

## Capacity planning for ~100 clips/day

| Constraint | Reality | Design response |
|---|---|---|
| Twitch Create Clip | Only on live channels that allow clips; rate-limited per user token; Twitch may reject bursts | Cooldowns, hourly/daily caps, 429 backoff, success confirmed before counting |
| Number of streamers | 100/day ≈ 6/h across 16 active hours → need several live channels | Multi-streamer monitoring in one EventSub session per account |
| EventSub WebSocket | Subscription limits per session/token | Errors surfaced per subscription; Conduits are the upgrade path |
| Video processing | 30 s 1080×1920 H.264 on a small VPS ≈ seconds–tens of seconds | One job at a time per engine; add engines (claim_job is concurrency-safe) |
| Storage | ~5–15 MB per vertical clip → 100/day ≈ 0.5–1.5 GB/day | Delete renders after publishing, or R2 |
| Social platforms | Upload APIs need app review; daily upload quotas | Manual share-sheet workflow today, API later |
| Campaign rules | Each campaign limits accepted content/platforms | Per-campaign requirements tracked |

Measure real throughput with the event log and Analytics before scaling. Reliability > artificial numbers.
