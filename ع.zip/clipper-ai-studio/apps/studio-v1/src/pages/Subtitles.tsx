import { AnimatePresence, motion } from 'framer-motion';
import { useEffect, useRef, useState, useMemo } from 'react';
import { parseSubtitles, toSRT, toVTT, type Cue } from '@shared/subtitles.ts';
import { Badge, Button, Card, CardHeader, EmptyState, Field, Input, Notice, PageHeader, Segmented, Select, Slider, Switch } from '../components/ui.tsx';
import { Icon } from '../components/Icon.tsx';
import { files } from '../lib/idb.ts';
import { drawSubtitle } from '../lib/render.ts';
import { useRoute } from '../lib/router.ts';
import { db, toast, useStore } from '../lib/store.ts';
import { useSystem } from '../lib/system.ts';
import { download, fmtTime } from '../lib/format.ts';
import type { SubtitleStyle } from '../lib/types.ts';

const TEMPLATES: { value: SubtitleStyle['template']; label: string }[] = [
  { value: 'pop', label: 'Pop' }, { value: 'karaoke', label: 'Karaoke' }, { value: 'clean', label: 'Clean' }, { value: 'boxed', label: 'Boxed' },
];

export default function Subtitles() {
  const { params } = useRoute();
  const allClips = useStore((s) => s.tables.clips);
  const clips = useMemo(() => allClips.filter((c) => c.local_file || c.storage_path), [allClips]);
  const docs = useStore((s) => s.tables.subtitles);
  const settings = useStore((s) => s.settings);
  const mode = useStore((s) => s.mode);
  const sys = useSystem();
  const [clipId, setClipId] = useState(params.get('clip') ?? clips[0]?.id ?? '');
  const doc = docs.find((d) => d.clip_id === clipId);
  const [cues, setCues] = useState<Cue[]>([]);
  const [style, setStyle] = useState<SubtitleStyle>(settings.subtitles.style);
  const [src, setSrc] = useState<string | null>(null);
  const [t, setT] = useState(0);
  const [dirty, setDirty] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const clip = clips.find((c) => c.id === clipId);

  useEffect(() => { setCues(doc?.cues ?? []); setStyle(doc?.style ?? settings.subtitles.style); setDirty(false); }, [doc?.id, clipId]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    setSrc(null); if (!clipId) return;
    let url: string | null = null;
    files.get(clipId).then((b) => { if (b) { url = URL.createObjectURL(b); setSrc(url); } });
    return () => { if (url) URL.revokeObjectURL(url); };
  }, [clipId]);

  useEffect(() => {
    let raf = 0;
    const loop = () => {
      const v = videoRef.current; const c = canvasRef.current;
      if (v && c) {
        setT(v.currentTime);
        const ctx = c.getContext('2d')!;
        ctx.clearRect(0, 0, c.width, c.height);
        drawSubtitle(ctx, cues, v.currentTime, style, c.width, c.height);
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [cues, style]);

  const change = (next: Cue[]) => { setCues([...next].sort((a, b) => a.start - b.start)); setDirty(true); };
  const add = () => { const start = videoRef.current?.currentTime ?? (cues.at(-1)?.end ?? 0); change([...cues, { id: crypto.randomUUID(), start, end: start + 2, text: 'New caption' }]); };
  const split = (c: Cue) => { const mid = (c.start + c.end) / 2; const w = c.text.split(' '); const h = Math.ceil(w.length / 2); change([...cues.filter((x) => x.id !== c.id), { ...c, end: mid, text: w.slice(0, h).join(' ') }, { id: crypto.randomUUID(), start: mid, end: c.end, text: w.slice(h).join(' ') || '…' }]); };

  async function save() {
    if (!clipId) return;
    const invalid = cues.find((c) => !(c.end > c.start) || !c.text.trim());
    if (invalid) return toast('error', 'Fix invalid captions', 'Each caption needs text and end > start.');
    try {
      if (doc) await db.update('subtitles', doc.id, { cues, style });
      else await db.insert('subtitles', { clip_id: clipId, cues, style, language: 'auto', provider: 'manual' });
      setDirty(false); toast('success', 'Subtitles saved', 'They appear in the Video Editor preview and exports.');
    } catch (e) { toast('error', 'Save failed', (e as Error).message); }
  }

  async function importFile(f: File) {
    const parsed = parseSubtitles(await f.text());
    if (!parsed.length) return toast('error', 'No captions found', 'Use a valid .srt or .vtt file.');
    change(parsed.map((c) => ({ ...c, id: crypto.randomUUID() }))); toast('success', `Imported ${parsed.length} captions`);
  }

  async function transcribe() {
    if (!clip?.storage_path) return;
    try {
      await db.insert('jobs', { kind: 'transcribe', status: 'queued', attempts: 0, result: null, error: null, completed_at: null, payload: { input_path: clip.storage_path, clip_id: clip.id, language: 'auto' } });
      toast('success', 'Transcription queued', 'The Engine will create subtitles; you\'ll get a notification.');
    } catch (e) { toast('error', 'Could not queue', (e as Error).message); }
  }

  const canAuto = mode === 'cloud' && Boolean(clip?.storage_path) && settings.subtitles.provider !== 'manual';

  return (
    <div>
      <PageHeader title="Subtitles" subtitle="Automatic transcripts when an engine provider is configured — and a full manual editor that always works." badge={dirty ? <Badge tone="amber">Unsaved</Badge> : undefined}
        actions={<Button variant="primary" icon="check" onClick={save} disabled={!clipId || !dirty}>Save</Button>} />
      <Card className="p-4 mb-4"><Select value={clipId} onChange={setClipId} options={[{ value: '', label: clips.length ? 'Choose a video…' : 'Upload a video in the Library first' }, ...clips.map((c) => ({ value: c.id, label: c.title ?? 'Untitled' }))]} /></Card>

      {!clipId ? <Card><EmptyState icon="captions" title="Pick a video to subtitle">Subtitles are attached to a video in your Library.</EmptyState></Card> : (
        <div className="grid lg:grid-cols-[minmax(0,340px)_1fr] gap-4">
          <div className="space-y-4">
            <Card className="p-3">
              <div className="relative mx-auto rounded-2xl overflow-hidden bg-black" style={{ aspectRatio: '9/16', maxHeight: '60dvh' }}>
                {src ? <video ref={videoRef} src={src} playsInline controls className="absolute inset-0 size-full object-contain" /> : <div className="absolute inset-0 grid place-items-center text-xs text-muted p-6 text-center">Video not on this device — you can still edit text and timings.</div>}
                <canvas ref={canvasRef} width={540} height={960} className="absolute inset-0 size-full pointer-events-none" />
              </div>
              <div className="text-xs text-muted font-mono mt-2 text-center">{fmtTime(t)}</div>
            </Card>
            <Card>
              <CardHeader title="Caption style" icon="type" />
              <div className="px-5 pb-5 space-y-4">
                <Segmented value={style.template} onChange={(v) => { setStyle({ ...style, template: v }); setDirty(true); }} options={TEMPLATES} />
                <div className="grid grid-cols-3 gap-2">
                  <Select value={style.font} onChange={(v) => { setStyle({ ...style, font: v }); setDirty(true); }} className="col-span-3" options={['Inter', 'Space Grotesk', 'Impact', 'Arial Black', 'Georgia'].map((f) => ({ value: f, label: f }))} />
                  <Field label="Text"><input type="color" value={style.color} onChange={(e) => { setStyle({ ...style, color: e.target.value }); setDirty(true); }} className="field h-11 p-1" /></Field>
                  <Field label="Highlight"><input type="color" value={style.highlight} onChange={(e) => { setStyle({ ...style, highlight: e.target.value }); setDirty(true); }} className="field h-11 p-1" /></Field>
                  <Field label="CAPS"><div className="h-11 flex items-center"><Switch checked={style.uppercase} onChange={(v) => { setStyle({ ...style, uppercase: v }); setDirty(true); }} /></div></Field>
                </div>
                <Field label="Size"><Slider value={style.size} min={32} max={120} onChange={(v) => { setStyle({ ...style, size: v }); setDirty(true); }} /></Field>
                <Field label="Position"><Slider value={Math.round(style.position * 100)} min={10} max={92} suffix="%" onChange={(v) => { setStyle({ ...style, position: v / 100 }); setDirty(true); }} /></Field>
              </div>
            </Card>
          </div>

          <div className="space-y-4 min-w-0">
            <Card>
              <CardHeader title="Automatic transcription" icon="sparkles" action={<Badge tone={canAuto && sys.engine?.online ? 'green' : 'muted'}>{settings.subtitles.provider === 'manual' ? 'no provider' : settings.subtitles.provider}</Badge>} />
              <div className="px-5 pb-5">
                {canAuto ? <Button icon="sparkles" onClick={transcribe}>Transcribe with Engine</Button>
                  : <Notice tone="info" title="Not available yet">Needs: Cloud mode, the video in cloud storage, a provider set in Settings → Subtitles (free <b>whisper.cpp</b> on your Engine, or paid OpenAI), and a running Engine. Manual editing below always works.</Notice>}
              </div>
            </Card>

            <Card>
              <CardHeader title={`Captions (${cues.length})`} icon="captions" action={<div className="flex gap-1">
                <label className="inline-flex"><input type="file" accept=".srt,.vtt,text/vtt" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) void importFile(f); e.target.value = ''; }} /><span className="h-9 px-3 rounded-xl text-[13px] inline-flex items-center gap-1.5 hover:bg-white/[.06] text-muted cursor-pointer"><Icon name="upload" size={15} />Import</span></label>
                <Button size="sm" variant="ghost" icon="download" disabled={!cues.length} onClick={() => download('subtitles.srt', toSRT(cues), 'text/plain')}>SRT</Button>
                <Button size="sm" variant="ghost" icon="download" disabled={!cues.length} onClick={() => download('subtitles.vtt', toVTT(cues), 'text/vtt')}>VTT</Button>
              </div>} />
              <div className="px-5 pb-5">
                {cues.length === 0 && <p className="text-sm text-muted mb-3">No captions yet. Play the video, pause where speech starts and tap “Add caption”.</p>}
                <div className="space-y-2">
                  <AnimatePresence initial={false}>
                    {cues.map((c) => {
                      const active = t >= c.start && t < c.end;
                      return (
                        <motion.div layout key={c.id} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, height: 0 }}
                          className={`rounded-xl border p-3 ${active ? 'border-green/40 bg-green/[.05]' : 'border-white/5 bg-white/[.02]'}`}>
                          <div className="flex items-center gap-2 mb-2">
                            <Input type="number" step="0.1" min="0" value={c.start.toFixed(1)} onChange={(e) => change(cues.map((x) => x.id === c.id ? { ...x, start: Number(e.target.value) } : x))} className="!w-24 !py-1.5 font-mono text-sm" aria-label="Start" />
                            <span className="text-muted">→</span>
                            <Input type="number" step="0.1" min="0" value={c.end.toFixed(1)} onChange={(e) => change(cues.map((x) => x.id === c.id ? { ...x, end: Number(e.target.value) } : x))} className="!w-24 !py-1.5 font-mono text-sm" aria-label="End" />
                            <div className="ml-auto flex">
                              <Button size="sm" variant="ghost" icon="play" aria-label="Jump" onClick={() => { if (videoRef.current) videoRef.current.currentTime = c.start; }} />
                              <Button size="sm" variant="ghost" icon="scissors" aria-label="Split" onClick={() => split(c)} />
                              <Button size="sm" variant="ghost" icon="trash" aria-label="Delete" onClick={() => change(cues.filter((x) => x.id !== c.id))} />
                            </div>
                          </div>
                          <Input value={c.text} onChange={(e) => change(cues.map((x) => x.id === c.id ? { ...x, text: e.target.value } : x))} />
                        </motion.div>
                      );
                    })}
                  </AnimatePresence>
                </div>
                <Button className="w-full mt-3" icon="plus" onClick={add}>Add caption at {fmtTime(t)}</Button>
              </div>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}
