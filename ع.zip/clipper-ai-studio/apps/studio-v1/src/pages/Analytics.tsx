import { useMemo, useState } from 'react';
import { estimateCampaign } from '@shared/earnings.ts';
import { Badge, Card, CardHeader, EmptyState, Notice, PageHeader, Segmented, Stat } from '../components/ui.tsx';
import { AreaChart, HBars, StackedBars } from '../components/charts.tsx';
import { PLATFORMS } from './Publisher.tsx';
import { isDemoActive, useStore } from '../lib/store.ts';
import { dayKey, fmtMoney, fmtNum, lastNDays } from '../lib/format.ts';
import type { Platform } from '../lib/types.ts';

export default function Analytics() {
  const t = useStore((s) => s.tables);
  const currency = useStore((s) => s.settings.currency);
  const demo = useStore(isDemoActive);
  const [range, setRange] = useState<'7' | '30' | '90'>('30');
  const [platform, setPlatform] = useState<'all' | Platform>('all');
  const days = lastNDays(Number(range));
  const since = days[0];

  const d = useMemo(() => {
    const clips = t.clips.filter((c) => dayKey(c.created_at) >= since);
    const posts = t.posts.filter((p) => dayKey(p.created_at) >= since && (platform === 'all' || p.platform === platform));
    const published = posts.filter((p) => p.status === 'published');
    const viewsBy = (['tiktok', 'instagram', 'youtube'] as Platform[]).map((p) => ({ label: PLATFORMS[p].label, value: published.filter((x) => x.platform === p).reduce((a, x) => a + (x.views ?? 0), 0), color: PLATFORMS[p].color }));
    const best = [...published].filter((p) => p.views != null).sort((a, b) => (b.views ?? 0) - (a.views ?? 0)).slice(0, 5);
    const camp = t.campaigns.map((c) => {
      const subs = t.campaign_submissions.filter((s) => s.campaign_id === c.id && (platform === 'all' || s.platform === platform));
      return { c, subs, ...estimateCampaign(c, subs) };
    });
    const byMonth = new Map<string, { clips: number; published: number }>();
    for (const c of t.clips) { const m = c.created_at.slice(0, 7); byMonth.set(m, { clips: (byMonth.get(m)?.clips ?? 0) + 1, published: byMonth.get(m)?.published ?? 0 }); }
    for (const p of t.posts.filter((x) => x.status === 'published')) { const m = p.created_at.slice(0, 7); byMonth.set(m, { clips: byMonth.get(m)?.clips ?? 0, published: (byMonth.get(m)?.published ?? 0) + 1 }); }
    return {
      clips, published, viewsBy, best, camp,
      manual: clips.filter((c) => c.type === 'manual').length, auto: clips.filter((c) => c.type === 'auto').length,
      views: published.reduce((a, p) => a + (p.views ?? 0), 0),
      est: camp.reduce((a, x) => a + x.estimated, 0), conf: camp.reduce((a, x) => a + x.confirmed, 0),
      perDay: (type: 'manual' | 'auto') => days.map((day) => clips.filter((c) => c.type === type && dayKey(c.created_at) === day).length),
      viewsPerDay: days.map((day) => published.filter((p) => dayKey(p.created_at) === day).reduce((a, p) => a + (p.views ?? 0), 0)),
      months: [...byMonth.entries()].sort((a, b) => b[0].localeCompare(a[0])).slice(0, 6),
    };
  }, [t, since, platform, range]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div>
      <PageHeader title="Analytics" subtitle="Computed from your own records. Views come from what you confirm per post; earnings split into estimated vs verified." badge={demo ? <Badge tone="amber">Includes demo data</Badge> : undefined}
        actions={<div className="flex flex-wrap gap-2"><Segmented value={range} onChange={setRange} options={[{ value: '7', label: '7d' }, { value: '30', label: '30d' }, { value: '90', label: '90d' }]} />
          <Segmented value={platform} onChange={setPlatform} options={[{ value: 'all', label: 'All' }, { value: 'tiktok', label: 'TikTok' }, { value: 'instagram', label: 'IG' }, { value: 'youtube', label: 'YT' }]} /></div>} />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Stat label="Total clips" value={d.clips.length} icon="scissors" sub={`${d.manual} manual · ${d.auto} auto`} />
        <Stat label="Published posts" value={d.published.length} icon="send" tone="blue" />
        <Stat label="Views (confirmed by you)" value={d.views} icon="eye" tone="green" />
        <Card className="p-4 sm:p-5">
          <div className="text-[13px] text-muted">Earnings</div>
          <div className="mt-2 font-display text-2xl font-semibold text-green tabular-nums">{fmtMoney(d.conf, currency)}</div>
          <div className="text-xs text-muted">verified · <span className="text-text/80">{fmtMoney(d.est, currency)}</span> estimated</div>
        </Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-4 mt-4">
        <Card><CardHeader title="Clips per day" icon="chart" /><div className="px-5 pb-5">{d.clips.length ? <StackedBars labels={days} series={[{ name: 'Auto', color: '#7857ff', data: d.perDay('auto') }, { name: 'Manual', color: '#32a5ff', data: d.perDay('manual') }]} /> : <EmptyState icon="chart" title="No clips in this period" />}</div></Card>
        <Card><CardHeader title="Views over time" subtitle="By post publish date" icon="eye" /><div className="px-5 pb-5">{d.views ? <AreaChart data={d.viewsPerDay} labels={days} format={fmtNum} /> : <EmptyState icon="eye" title="No views recorded">Confirm posts with their view counts in the Social Publisher.</EmptyState>}</div></Card>
        <Card><CardHeader title="Views by platform" icon="layers" /><div className="px-5 pb-5"><HBars items={d.viewsBy} format={fmtNum} /></div></Card>
        <Card>
          <CardHeader title="Best-performing clips" icon="star" />
          <div className="px-5 pb-5 divide-y divide-white/5">
            {d.best.length === 0 && <p className="text-sm text-muted py-3">No posts with views yet.</p>}
            {d.best.map((p, i) => <div key={p.id} className="py-2.5 flex items-center gap-3 text-sm"><span className="font-display text-muted w-5">{i + 1}</span><span className="flex-1 truncate">{t.clips.find((c) => c.id === p.clip_id)?.title ?? 'Clip'}</span><Badge>{PLATFORMS[p.platform].label}</Badge><span className="tabular-nums w-16 text-right">{fmtNum(p.views)}</span></div>)}
          </div>
        </Card>
      </div>

      <Card className="mt-4">
        <CardHeader title="Campaign performance" icon="target" />
        <div className="px-5 pb-5 overflow-x-auto">
          {d.camp.length === 0 ? <p className="text-sm text-muted">No campaigns.</p> : (
            <table className="w-full text-sm min-w-[560px]">
              <thead><tr className="text-left text-xs text-muted"><th className="py-2 font-medium">Campaign</th><th className="font-medium">Posts</th><th className="font-medium">Eligible views</th><th className="font-medium text-right">Estimated</th><th className="font-medium text-right">Verified</th></tr></thead>
              <tbody className="divide-y divide-white/5">{d.camp.map(({ c, subs, estimated, confirmed }) => (
                <tr key={c.id}><td className="py-2.5">{c.name}</td><td>{subs.length}</td><td className="tabular-nums">{fmtNum(subs.reduce((a, s) => a + (s.eligible_views ?? 0), 0))}</td><td className="text-right tabular-nums text-muted">{fmtMoney(estimated, c.currency)}</td><td className="text-right tabular-nums text-green">{fmtMoney(confirmed, c.currency)}</td></tr>
              ))}</tbody>
            </table>
          )}
          <div className="mt-4"><Notice tone="info" title="Estimated ≠ verified">Estimates use the CPM and caps you entered and per-post eligible views. Only “verified” reflects money a campaign actually approved.</Notice></div>
        </div>
      </Card>

      <Card className="mt-4">
        <CardHeader title="Monthly statistics" icon="clock" />
        <div className="px-5 pb-5 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
          {d.months.length === 0 && <p className="text-sm text-muted col-span-full">No data yet.</p>}
          {d.months.map(([m, v]) => <div key={m} className="rounded-xl bg-white/[.03] border border-white/5 p-3"><div className="text-xs text-muted">{m}</div><div className="font-display font-semibold mt-1">{v.clips} clips</div><div className="text-xs text-muted">{v.published} published</div></div>)}
        </div>
      </Card>
    </div>
  );
}
