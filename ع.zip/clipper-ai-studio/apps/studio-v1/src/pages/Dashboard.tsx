import { motion } from 'framer-motion';
import { Badge, Button, Card, CardHeader, DemoBadge, EmptyState, Notice, Stat, Waveform } from '../components/ui.tsx';
import { StackedBars } from '../components/charts.tsx';
import { StatusPills } from '../components/StatusPills.tsx';
import { Icon } from '../components/Icon.tsx';
import { ClipThumb } from './Library.tsx';
import { navigate } from '../lib/router.ts';
import { db, isDemoActive, toast, useStore } from '../lib/store.ts';
import { useSystem } from '../lib/system.ts';
import { buildDemo } from '../lib/demo.ts';
import { useEffect } from 'react';
import { refreshLive, useLive } from '../lib/live.ts';
import { cx, dayKey, isToday, lastNDays, timeAgo } from '../lib/format.ts';

export default function Dashboard() {
  const t = useStore((s) => s.tables);
  const mode = useStore((s) => s.mode);
  const demo = useStore(isDemoActive);
  const sys = useSystem();
  const live = useLive();
  useEffect(() => { refreshLive().catch(() => undefined); }, [sys.api]);
  const days = lastNDays(14);
  const byDay = (type: 'manual' | 'auto') => days.map((d) => t.clips.filter((c) => c.type === type && dayKey(c.created_at) === d).length);
  const queue = t.jobs.filter((j) => j.status === 'queued' || j.status === 'running').length + t.clips.filter((c) => c.status === 'processing' || c.status === 'requested').length;
  const monitored = t.streamers.filter((s) => s.monitor_enabled || s.auto_clip_enabled).length;
  const empty = t.clips.length === 0 && t.streamers.length === 0;

  const checklist = [
    { done: t.streamers.length > 0, label: 'Add a streamer', go: () => navigate('streamers') },
    { done: mode === 'cloud', label: 'Create your free cloud account (Supabase)', go: () => navigate('settings') },
    { done: sys.api === 'online', label: 'Deploy the API Worker (Cloudflare, free)', go: () => navigate('settings') },
    { done: sys.twitch.some((a) => a.status === 'active'), label: 'Connect Twitch', go: () => navigate('settings') },
    { done: Boolean(sys.engine?.online), label: 'Run the Engine for 24/7 auto clipping', go: () => navigate('auto') },
  ];
  const progress = checklist.filter((c) => c.done).length;

  return (
    <div className="space-y-6">
      {/* Hero */}
      <Card className="relative overflow-hidden p-5 sm:p-7">
        <div className="absolute -right-20 -top-24 size-72 rounded-full bg-purple/25 blur-3xl" />
        <div className="absolute right-24 -bottom-24 size-60 rounded-full bg-blue/20 blur-3xl" />
        <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div>
            <div className="flex items-center gap-2 mb-2"><Badge tone="purple">Clipper AI Studio</Badge>{demo && <DemoBadge />}</div>
            <h1 className="font-display text-[28px] sm:text-4xl font-semibold tracking-tight leading-[1.1]">Your stream. Your clips.<br /><span className="text-gradient">Automatically.</span></h1>
            <p className="text-muted text-sm mt-3 max-w-lg">One platform for multiple streamers: detect hype moments from chat, create native Twitch clips, edit vertical videos and track campaign earnings.</p>
          </div>
          <div className="flex flex-col gap-3 md:items-end">
            <Waveform active={sys.engine?.online ?? false} bars={26} className="h-10" />
            <div className="flex gap-2">
              <Button variant="primary" icon="scissors" onClick={() => navigate('manual')}>Clip right now</Button>
              <Button icon="bolt" onClick={() => navigate('auto')}>Auto clipper</Button>
            </div>
          </div>
        </div>
      </Card>

      <StatusPills />

      {demo && <Notice tone="warn" title="DEMO DATA is loaded" action={<Button size="sm" variant="secondary" onClick={() => { db.removeDemo(); toast('success', 'Demo data removed'); }}>Remove demo data</Button>}>Numbers below include fictional sample records. They are not real production statistics.</Notice>}

      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
        <Stat label="Twitch accounts" value={sys.twitch.filter((a) => a.status === 'active').length} icon="twitch" tone="purple" sub={sys.api === 'online' ? 'connected' : 'backend required'} />
        <Stat label="Monitored streamers" value={monitored} icon="users" tone="blue" sub={`${t.streamers.length} saved`} />
        <Stat label="Live now" value={Object.keys(live.streams).length} unknown={!live.known} icon="wifi" tone="green" sub={live.known ? 'from Twitch' : 'needs backend'} />
        <Stat label="Clips today" value={t.clips.filter((c) => isToday(c.created_at)).length} icon="scissors" tone="purple" />
        <Stat label="Detections today" value={t.detection_events.filter((d) => isToday(d.created_at)).length} icon="sparkles" tone="amber" />
        <Stat label="Published" value={t.posts.filter((p) => p.status === 'published').length} icon="send" tone="green" sub={`${queue} in queue`} />
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <CardHeader title="Clips created" subtitle="Last 14 days · manual vs automatic" icon="chart" />
          <div className="px-5 pb-5">
            {t.clips.length ? <StackedBars labels={days} series={[{ name: 'Auto', color: '#7857ff', data: byDay('auto') }, { name: 'Manual', color: '#32a5ff', data: byDay('manual') }]} />
              : <EmptyState icon="chart" title="No clips yet">Your clip activity chart appears here once you create clips.</EmptyState>}
          </div>
        </Card>

        <Card>
          <CardHeader title="Get to 24/7 clipping" subtitle={`${progress} of ${checklist.length} steps`} icon="sparkles" />
          <div className="px-5 pb-5 space-y-2">
            <div className="h-1.5 rounded-full bg-white/5 overflow-hidden mb-3"><motion.div className="h-full bg-gradient-to-r from-purple to-blue" initial={{ width: 0 }} animate={{ width: `${(progress / checklist.length) * 100}%` }} /></div>
            {checklist.map((c) => (
              <button key={c.label} onClick={c.go} className="w-full flex items-center gap-3 p-2.5 rounded-xl hover:bg-white/[.04] text-left">
                <span className={cx('grid place-items-center size-6 rounded-full border shrink-0', c.done ? 'bg-green/15 border-green/40 text-green' : 'border-white/15 text-transparent')}><Icon name="check" size={13} /></span>
                <span className={cx('text-sm flex-1', c.done && 'text-muted line-through')}>{c.label}</span>
                <Icon name="chevronRight" size={15} className="text-muted" />
              </button>
            ))}
          </div>
        </Card>
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <CardHeader title="Recent clips" icon="library" action={<Button size="sm" variant="ghost" onClick={() => navigate('library')}>View all</Button>} />
          {t.clips.length === 0 ? (
            <EmptyState icon="scissors" title={empty ? 'Start by adding a streamer' : 'No clips yet'} action={<>
              <Button variant="primary" icon="plus" onClick={() => navigate('streamers')}>Add streamer</Button>
              {mode === 'local' && <Button icon="layers" onClick={() => { db.loadDemo(buildDemo()); toast('info', 'DEMO DATA loaded', 'Fictional records, clearly labelled.'); }}>Explore with demo data</Button>}
            </>}>Clips you create manually or automatically will show up here.</EmptyState>
          ) : (
            <div className="px-5 pb-5 grid grid-cols-2 sm:grid-cols-3 gap-3">
              {t.clips.slice(0, 6).map((c) => (
                <button key={c.id} onClick={() => navigate('library')} className="text-left group">
                  <ClipThumb clip={c} />
                  <div className="mt-2 text-sm font-medium truncate">{c.title ?? 'Untitled clip'}</div>
                  <div className="text-xs text-muted">{c.streamer_login} · {timeAgo(c.created_at)}</div>
                </button>
              ))}
            </div>
          )}
        </Card>

        <Card>
          <CardHeader title="Recent activity" icon="clock" />
          <div className="px-5 pb-5">
            {t.notifications.length === 0 ? <p className="text-sm text-muted py-6 text-center">Nothing yet. Alerts for live streamers, detections and clips land here.</p> : (
              <ol className="relative border-l border-white/10 ml-1.5 space-y-4">
                {t.notifications.slice(0, 7).map((n) => (
                  <li key={n.id} className="pl-4 relative">
                    <span className="absolute -left-[5px] top-1.5 size-2.5 rounded-full bg-gradient-to-br from-purple to-blue ring-4 ring-bg" />
                    <div className="text-sm">{n.title}</div>
                    <div className="text-xs text-muted">{timeAgo(n.created_at)}</div>
                  </li>
                ))}
              </ol>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}
