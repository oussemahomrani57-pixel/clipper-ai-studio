import { AnimatePresence, motion } from 'framer-motion';
import { useState } from 'react';
import { BLOCK_LABEL } from '@shared/scoring.ts';
import { Badge, Button, Card, CardHeader, EmptyState, Notice, PageHeader, Switch, Waveform } from '../components/ui.tsx';
import { AreaChart, ScoreGauge } from '../components/charts.tsx';
import { Icon } from '../components/Icon.tsx';
import { browserMonitor } from '../lib/browserMonitor.ts';
import { useStore } from '../lib/store.ts';
import { twitchReady, useSystem } from '../lib/system.ts';
import { navigate } from '../lib/router.ts';
import { cx, timeAgo } from '../lib/format.ts';

const COMP = [['chatVelocity', 'Chat velocity'], ['reactions', 'Reactions'], ['keywords', 'Keywords'], ['streamEvents', 'Stream events'], ['other', 'Chatter breadth']] as const;

export default function LiveMonitor() {
  const mon = browserMonitor.use();
  const streamers = useStore((s) => s.tables.streamers);
  const events = useStore((s) => s.tables.detection_events);
  const settings = useStore((s) => s.settings);
  const sys = useSystem();
  const candidates = streamers.filter((s) => s.monitor_enabled && !s.is_demo);
  const [focus, setFocus] = useState<string | null>(null);
  const views = Object.values(mon.channels);
  const active = views.find((v) => v.login === focus) ?? views[0];
  const threshold = settings.detector.minScore ?? 70;

  return (
    <div>
      <PageHeader title="Live Monitor" subtitle="Real-time chat analysis and viral-moment scoring for your monitored streamers."
        actions={mon.running ? <Button variant="danger" icon="pause" onClick={() => browserMonitor.stop()}>Stop monitoring</Button>
          : <Button variant="primary" icon="play" disabled={!candidates.length} onClick={() => browserMonitor.start(candidates)}>Start browser monitor</Button>} />

      <div className="grid md:grid-cols-2 gap-3 mb-5">
        <Card className="p-4 flex items-center gap-4">
          <div className={cx('grid place-items-center size-11 rounded-xl', mon.state === 'connected' ? 'bg-green/12 text-green' : mon.state === 'idle' ? 'bg-white/5 text-muted' : 'bg-amber/12 text-amber')}><Icon name="monitor" /></div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-medium flex items-center gap-2">Browser monitor <Badge tone={mon.state === 'connected' ? 'green' : mon.state === 'idle' ? 'muted' : 'amber'} dot={mon.state === 'connected'}>{mon.state}</Badge></div>
            <div className="text-xs text-muted mt-0.5">Anonymous read-only Twitch chat · stops when this app is closed or your iPhone locks</div>
          </div>
          {mon.state === 'connected' && <Waveform bars={10} />}
        </Card>
        <Card className="p-4 flex items-center gap-4">
          <div className={cx('grid place-items-center size-11 rounded-xl', sys.engine?.online ? 'bg-green/12 text-green' : 'bg-white/5 text-muted')}><Icon name="cpu" /></div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-medium flex items-center gap-2">24/7 Engine <Badge tone={sys.engine?.online ? 'green' : 'muted'}>{!sys.engine ? 'not deployed' : sys.engine.online ? 'online' : 'offline'}</Badge></div>
            <div className="text-xs text-muted mt-0.5">{sys.engine?.online ? `Watching ${sys.engine.channels} channels · EventSub ${sys.engine.eventsub ? 'connected' : 'reconnecting'}` : sys.engine?.lastSeen ? `Last heartbeat ${timeAgo(sys.engine.lastSeen)} — NOT monitoring now` : 'Runs on a server so monitoring continues when your phone is off'}</div>
          </div>
        </Card>
      </div>

      {mon.running && twitchReady(sys) && settings.auto_clipping_enabled && (
        <Card className="p-4 mb-5 flex items-center justify-between gap-3">
          <div className="text-sm"><div className="font-medium">Request real clips from this browser</div><div className="text-xs text-muted">Off = detections are only logged (dry run). The Engine is the reliable option.</div></div>
          <Switch checked={mon.clipFromBrowser} onChange={(v) => browserMonitor.setClipFromBrowser(v)} />
        </Card>
      )}

      {!candidates.length && !mon.running && (
        <Card><EmptyState icon="users" title="No streamers to monitor" action={<Button variant="primary" onClick={() => navigate('streamers')}>Manage streamers</Button>}>Turn on "Monitor chat" for at least one streamer.</EmptyState></Card>
      )}

      {candidates.length > 0 && !mon.running && (
        <Notice tone="info" title={`${candidates.length} streamer(s) ready`}>Press <b>Start browser monitor</b> to read their public chat in real time. Live/offline status is shown on the Streamers page when the backend is connected; chat on an offline channel stays quiet.</Notice>
      )}

      {mon.running && (
        <>
          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1 mb-4">
            {views.map((v) => (
              <button key={v.login} onClick={() => setFocus(v.login)} className={cx('shrink-0 flex items-center gap-2 px-3.5 h-10 rounded-xl border text-sm', active?.login === v.login ? 'bg-purple/20 border-purple/40' : 'bg-white/[.03] border-white/5 text-muted')}>
                <span className={cx('size-2 rounded-full', (v.last?.score ?? 0) >= threshold ? 'bg-green animate-pulse-soft' : v.buckets[v.buckets.length - 1] > 0 ? 'bg-blue' : 'bg-muted/40')} />{v.login}
                <span className="font-mono text-xs tabular-nums">{v.last?.score ?? 0}</span>
              </button>
            ))}
          </div>

          {active && (
            <div className="grid lg:grid-cols-3 gap-4">
              <Card className="lg:col-span-2">
                <CardHeader title={`Chat activity · ${active.login}`} subtitle={`${(active.buckets.slice(-6).reduce((a, b) => a + b, 0))} messages in the last minute · ${active.total} total`} icon="chart" />
                <div className="px-5 pb-5"><AreaChart data={active.buckets.map((b) => b * 6)} labels={active.buckets.map((_, i) => `${Math.round((active.buckets.length - 1 - i) * 10)}s ago`)} format={(v) => `${v} msg/min`} /></div>
              </Card>
              <Card>
                <CardHeader title="Viral score" subtitle={`Threshold ${threshold} · peak ${active.peak}`} icon="sparkles" />
                <div className="px-5 pb-5 flex flex-col items-center">
                  <ScoreGauge score={active.last?.score ?? 0} threshold={threshold} />
                  <div className="text-xs text-muted mt-2 h-4">{active.last?.blockedBy ? BLOCK_LABEL[active.last.blockedBy] : active.last ? 'Would trigger' : ''}</div>
                  <div className="w-full mt-4 space-y-2.5">
                    {COMP.map(([k, label]) => (
                      <div key={k}>
                        <div className="flex justify-between text-xs mb-1"><span className="text-muted">{label}</span><span className="tabular-nums">{Math.round((active.last?.components[k] ?? 0) * 100)}%</span></div>
                        <div className="h-1.5 rounded-full bg-white/[.06] overflow-hidden"><motion.div className="h-full bg-gradient-to-r from-purple to-blue" animate={{ width: `${(active.last?.components[k] ?? 0) * 100}%` }} /></div>
                      </div>
                    ))}
                  </div>
                </div>
              </Card>
              <Card className="lg:col-span-1">
                <CardHeader title="Chat feed" subtitle="Last messages (not stored)" icon="captions" />
                <div className="px-5 pb-5 space-y-2 min-h-[120px]">
                  <AnimatePresence initial={false}>
                    {active.recent.map((m) => (
                      <motion.div key={`${m.ts}-${m.userId}`} layout initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} className="text-sm truncate"><span className="text-[#b3a2ff] font-medium">{m.user}</span> <span className="text-text/85">{m.text}</span></motion.div>
                    ))}
                  </AnimatePresence>
                  {!active.recent.length && <p className="text-sm text-muted">Waiting for chat… (offline channels are quiet)</p>}
                </div>
              </Card>
              <Card className="lg:col-span-2">
                <CardHeader title="Why it scores" icon="info" />
                <div className="px-5 pb-5 text-sm space-y-1.5">
                  {active.last?.reasons.length ? active.last.reasons.map((r) => <div key={r} className="flex gap-2"><Icon name="chevronRight" size={15} className="text-purple mt-0.5" />{r}</div>) : <p className="text-muted">No strong signal right now. Chat analysis can't see or hear the video — it only measures how chat reacts.</p>}
                </div>
              </Card>
            </div>
          )}
        </>
      )}

      <Card className="mt-5">
        <CardHeader title="Detection log" subtitle="Every detected moment and what happened" icon="layers" />
        <div className="px-5 pb-5">
          {events.length === 0 ? <p className="text-sm text-muted py-4">No detections yet.</p> : (
            <div className="divide-y divide-white/5">
              {events.slice(0, 25).map((e) => (
                <div key={e.id} className="py-3 flex items-start gap-3">
                  <div className={cx('font-display font-semibold tabular-nums w-10 text-center rounded-lg py-1 text-sm', e.score >= threshold ? 'bg-green/12 text-green' : 'bg-white/5')}>{e.score}</div>
                  <div className="min-w-0 flex-1">
                    <div className="text-sm flex flex-wrap items-center gap-2"><b>{e.streamer_login}</b>
                      <Badge tone={e.action === 'clip_requested' ? 'purple' : e.action === 'skipped' ? 'red' : 'muted'}>{e.action.replace('_', ' ')}</Badge>
                      <Badge tone="muted">{e.source}</Badge>{e.is_demo && <Badge tone="amber">Demo</Badge>}
                    </div>
                    <div className="text-xs text-muted mt-1">{e.reasons.join(' · ') || '—'}{e.blocked_by ? ` · ${e.blocked_by}` : ''}</div>
                  </div>
                  <span className="text-xs text-muted shrink-0">{timeAgo(e.created_at)}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}
