import { useCallback, useEffect, useRef, useState, type PointerEvent as RPointerEvent, useMemo } from 'react';
import { Badge, Button, Card, CardHeader, EmptyState, Field, Input, Notice, PageHeader, Progress, Segmented, Select, Slider } from '../components/ui.tsx';
import { Icon } from '../components/Icon.tsx';
import { files } from '../lib/idb.ts';
import { navigate, useRoute } from '../lib/router.ts';
import { db, notify, toast, useStore } from '../lib/store.ts';
import { cropFor, drawFrame, drawOverlay, drawSubtitle, pickRecorderMime, type Framing, type Overlay } from '../lib/render.ts';
import { cx, download, fmtTime } from '../lib/format.ts';

const PRESETS = { '1080x1920': [1080, 1920], '720x1280': [720, 1280] } as const;
const FONTS = ['Inter', 'Space Grotesk', 'Impact', 'Arial Black', 'Georgia', 'Courier New'];

export default function VideoEditor() {
  const { params } = useRoute();
  const allClips = useStore((s) => s.tables.clips);
  const clips = useMemo(() => allClips.filter((c) => c.local_file || c.storage_path), [allClips]);
  const subtitleDocs = useStore((s) => s.tables.subtitles);
  const settings = useStore((s) => s.settings);
  const mode = useStore((s) => s.mode);
  const [clipId, setClipId] = useState(params.get('clip') ?? '');
  const [src, setSrc] = useState<string | null>(null);
  const [srcName, setSrcName] = useState('');
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [dur, setDur] = useState(0);
  const [range, setRange] = useState<[number, number]>([0, 0]);
  const [t, setT] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [framing, setFraming] = useState<Framing>({ zoom: 1, panX: 0, panY: 0, background: settings.video.background });
  const [overlay, setOverlay] = useState<Overlay>({ text: '', font: settings.video.font, color: '#FFFFFF', size: 70, y: 0.14 });
  const [useSubs, setUseSubs] = useState(true);
  const [preset, setPreset] = useState<keyof typeof PRESETS>(settings.video.preset);
  const [exporting, setExporting] = useState<number | null>(null);
  const [thumb, setThumb] = useState<string | null>(null);
  const audioRef = useRef<{ ctx: AudioContext; dest: MediaStreamAudioDestinationNode } | null>(null);
  const clip = clips.find((c) => c.id === clipId);
  const subs = subtitleDocs.find((s) => s.clip_id === clipId);

  // load source
  useEffect(() => {
    if (!clipId) return;
    let url: string | null = null;
    files.get(clipId).then((b) => {
      if (b) { url = URL.createObjectURL(b); setSrc(url); setSrcName(clip?.title ?? 'clip'); }
      else { setSrc(null); toast('info', 'This video is not stored on this device', clip?.storage_path ? 'Use server export (FFmpeg) or re-upload it here.' : undefined); }
    });
    return () => { if (url) URL.revokeObjectURL(url); };
  }, [clipId]); // eslint-disable-line react-hooks/exhaustive-deps

  const pickFile = (f: File) => { setClipId(''); setSrc(URL.createObjectURL(f)); setSrcName(f.name); };

  const paint = useCallback(() => {
    const v = videoRef.current; const c = canvasRef.current;
    if (!v || !c || v.readyState < 2) return;
    const ctx = c.getContext('2d')!;
    drawFrame(ctx, v, c.width, c.height, framing);
    drawOverlay(ctx, overlay, c.width, c.height);
    if (useSubs && subs) drawSubtitle(ctx, subs.cues, v.currentTime, subs.style ?? settings.subtitles.style, c.width, c.height);
  }, [framing, overlay, useSubs, subs, settings.subtitles.style]);

  // render loop
  useEffect(() => {
    let raf = 0;
    const loop = () => {
      const v = videoRef.current;
      if (v) {
        setT(v.currentTime);
        if (!v.paused && v.currentTime >= range[1] && exporting === null) { v.pause(); v.currentTime = range[0]; }
      }
      paint();
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [paint, range, exporting]);

  const onMeta = () => { const v = videoRef.current!; setDur(v.duration); setRange([0, Math.min(v.duration, 60)]); v.currentTime = 0.01; };
  const toggle = () => { const v = videoRef.current; if (!v) return; if (v.paused) { if (v.currentTime < range[0] || v.currentTime >= range[1]) v.currentTime = range[0]; void v.play(); setPlaying(true); } else { v.pause(); setPlaying(false); } };

  async function exportLocal() {
    const v = videoRef.current; const preview = canvasRef.current;
    const mime = pickRecorderMime();
    if (!v || !preview || !mime) return toast('error', 'On-device export not supported in this browser', 'Use server export, or update iOS/Safari.');
    const [W, H] = PRESETS[preset];
    const out = document.createElement('canvas'); out.width = W; out.height = H;
    const ctx = out.getContext('2d')!;
    try {
      if (!audioRef.current) {
        const ac = new AudioContext(); const srcNode = ac.createMediaElementSource(v); const dest = ac.createMediaStreamDestination();
        srcNode.connect(dest); srcNode.connect(ac.destination); audioRef.current = { ctx: ac, dest };
      }
      await audioRef.current.ctx.resume();
      const stream = new MediaStream([...out.captureStream(30).getVideoTracks(), ...audioRef.current.dest.stream.getAudioTracks()]);
      const rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: preset === '1080x1920' ? 8_000_000 : 5_000_000 });
      const chunks: Blob[] = [];
      rec.ondataavailable = (e) => e.data.size && chunks.push(e.data);
      const done = new Promise<void>((r) => (rec.onstop = () => r()));
      v.pause(); v.currentTime = range[0];
      await new Promise((r) => (v.onseeked = r));
      setExporting(0);
      rec.start(250); await v.play();
      await new Promise<void>((resolve) => {
        const step = () => {
          drawFrame(ctx, v, W, H, framing); drawOverlay(ctx, overlay, W, H);
          if (useSubs && subs) drawSubtitle(ctx, subs.cues, v.currentTime, subs.style ?? settings.subtitles.style, W, H);
          setExporting(Math.min(100, ((v.currentTime - range[0]) / (range[1] - range[0])) * 100));
          if (v.currentTime >= range[1] || v.ended) { v.pause(); resolve(); } else requestAnimationFrame(step);
        };
        requestAnimationFrame(step);
      });
      rec.stop(); await done;
      const ext = mime.includes('mp4') ? 'mp4' : 'webm';
      const blob = new Blob(chunks, { type: mime.split(';')[0] });
      const id = crypto.randomUUID();
      await files.put(id, blob);
      await db.insert('clips', { id, title: `${srcName} · ${preset} export`, type: 'upload', status: 'ready', publish_status: 'unpublished', local_file: true, duration_sec: range[1] - range[0], streamer_login: clip?.streamer_login ?? null, streamer_id: clip?.streamer_id ?? null, twitch_clip_id: null, url: null, edit_url: null, thumbnail_url: null, detection_score: null, error: null, storage_path: null });
      download(`clipper-${preset}.${ext}`, blob);
      toast('success', `Exported ${ext.toUpperCase()} (${(blob.size / 1e6).toFixed(1)} MB)`, 'Saved to your Library too.');
      void notify('render_completed', 'Video export ready', srcName, '#/library');
    } catch (e) { toast('error', 'Export failed', (e as Error).message); }
    finally { setExporting(null); }
  }

  async function exportServer() {
    const v = videoRef.current;
    if (!clip?.storage_path) return;
    const [W, H] = PRESETS[preset];
    const crop = v ? cropFor(v.videoWidth, v.videoHeight, W, H, framing) : null;
    try {
      await db.insert('jobs', { kind: 'render', status: 'queued', attempts: 0, result: null, error: null, completed_at: null,
        payload: { input_path: clip.storage_path, preset, start: range[0], end: range[1], crop, cues: useSubs ? subs?.cues ?? [] : [], clip_id: clip.id } });
      toast('success', 'Render job queued', 'The Engine renders it with FFmpeg (black background, burned-in subtitles).');
    } catch (e) { toast('error', 'Could not queue job', (e as Error).message); }
  }

  const captureThumb = () => { const c = canvasRef.current; if (c) setThumb(c.toDataURL('image/jpeg', 0.9)); };
  const mime = typeof window !== 'undefined' ? pickRecorderMime() : null;

  return (
    <div>
      <PageHeader title="Video Editor" subtitle="Trim, reframe to vertical 9:16, add text and subtitles, then export." />
      <Card className="p-4 mb-4 flex flex-col sm:flex-row gap-3 sm:items-center">
        <Select value={clipId} onChange={setClipId} className="flex-1" options={[{ value: '', label: clips.length ? 'Choose a video from your library…' : 'No editable videos in library yet' }, ...clips.map((c) => ({ value: c.id, label: `${c.title ?? 'Untitled'}${c.local_file ? '' : ' (cloud)'}` }))]} />
        <label className="inline-flex"><input type="file" accept="video/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) pickFile(f); }} /><span className="btn-glow text-white h-11 px-4 rounded-xl inline-flex items-center gap-2 text-sm font-medium cursor-pointer"><Icon name="upload" size={17} />Open video</span></label>
      </Card>

      {!src ? (
        <Card>
          <EmptyState icon="film" title="Open a video to start editing">Use a video you own or have permission to edit — e.g. your own stream's clips, or footage a campaign provides. Twitch only allows downloading clip files for the channel owner and their editors.</EmptyState>
        </Card>
      ) : (
        <div className="grid lg:grid-cols-[minmax(0,380px)_1fr] gap-4">
          <div className="space-y-3">
            <Card className="p-3">
              <div className="relative mx-auto rounded-2xl overflow-hidden bg-black shadow-[0_0_60px_-10px_rgb(120_87_255/.45)]" style={{ aspectRatio: '9/16', maxHeight: '68dvh' }}>
                <canvas ref={canvasRef} width={540} height={960} className="size-full" onClick={toggle} />
                {exporting !== null && <div className="absolute inset-0 bg-black/70 grid place-items-center p-8"><div className="w-full text-center"><div className="font-display text-3xl font-semibold mb-3">{Math.round(exporting)}%</div><Progress value={exporting} /><p className="text-xs text-muted mt-3">Exporting in real time — keep this screen open.</p></div></div>}
              </div>
              <video ref={videoRef} src={src} playsInline onLoadedMetadata={onMeta} onPause={() => setPlaying(false)} className="hidden" crossOrigin="anonymous" />
              <div className="flex items-center gap-2 mt-3">
                <Button size="sm" variant="primary" icon={playing ? 'pause' : 'play'} onClick={toggle}>{playing ? 'Pause' : 'Play'}</Button>
                <span className="font-mono text-xs text-muted">{fmtTime(t)} / {fmtTime(dur)}</span>
                <Button size="sm" variant="ghost" icon="image" className="ml-auto" onClick={captureThumb}>Thumbnail</Button>
              </div>
            </Card>
            {thumb && <Card className="p-3 flex items-center gap-3"><img src={thumb} alt="thumbnail" className="h-24 rounded-lg" /><div className="text-sm flex-1">Thumbnail preview<div className="text-xs text-muted">From the current frame</div></div><Button size="sm" icon="download" onClick={() => fetch(thumb).then((r) => r.blob()).then((b) => download('thumbnail.jpg', b))}>Save</Button></Card>}
          </div>

          <div className="space-y-4 min-w-0">
            <Card>
              <CardHeader title="Timeline" subtitle={`Selection ${fmtTime(range[0])} → ${fmtTime(range[1])} · ${(range[1] - range[0]).toFixed(1)}s`} icon="clock" />
              <div className="px-5 pb-5"><Timeline dur={dur} range={range} t={t} onRange={setRange} onSeek={(x) => { if (videoRef.current) videoRef.current.currentTime = x; }} /></div>
            </Card>

            <div className="grid md:grid-cols-2 gap-4">
              <Card>
                <CardHeader title="Crop & position" icon="layers" />
                <div className="px-5 pb-5 space-y-4">
                  <Field label="Zoom"><Slider value={framing.zoom} min={1} max={3.5} step={0.05} onChange={(v) => setFraming({ ...framing, zoom: v })} suffix="×" /></Field>
                  <Field label="Horizontal position"><Slider value={framing.panX} min={-1} max={1} step={0.02} onChange={(v) => setFraming({ ...framing, panX: v })} /></Field>
                  <Field label="Vertical position"><Slider value={framing.panY} min={-1} max={1} step={0.02} onChange={(v) => setFraming({ ...framing, panY: v })} /></Field>
                  <Field label="Background"><Segmented value={framing.background} onChange={(v) => setFraming({ ...framing, background: v })} options={[{ value: 'blur', label: 'Blur' }, { value: 'black', label: 'Black' }, { value: 'gradient', label: 'Gradient' }]} /></Field>
                  <div className="flex gap-2"><Button size="sm" onClick={() => setFraming({ ...framing, zoom: 1, panX: 0, panY: 0 })}>Fit</Button><Button size="sm" onClick={() => setFraming({ ...framing, zoom: 3.16, panX: 0, panY: 0 })}>Fill 9:16</Button></div>
                </div>
              </Card>
              <Card>
                <CardHeader title="Text overlay" icon="type" />
                <div className="px-5 pb-5 space-y-4">
                  <Input value={overlay.text} onChange={(e) => setOverlay({ ...overlay, text: e.target.value })} placeholder="Hook text, e.g. HE DID WHAT?! 😱" />
                  <div className="grid grid-cols-2 gap-2">
                    <Select value={overlay.font} onChange={(v) => setOverlay({ ...overlay, font: v })} options={FONTS.map((f) => ({ value: f, label: f }))} />
                    <input type="color" value={overlay.color} onChange={(e) => setOverlay({ ...overlay, color: e.target.value })} className="field h-[46px] p-1" />
                  </div>
                  <Field label="Size"><Slider value={overlay.size} min={30} max={140} onChange={(v) => setOverlay({ ...overlay, size: v })} /></Field>
                  <Field label="Vertical position"><Slider value={Math.round(overlay.y * 100)} min={5} max={95} onChange={(v) => setOverlay({ ...overlay, y: v / 100 })} suffix="%" /></Field>
                </div>
              </Card>
            </div>

            <Card>
              <CardHeader title="Subtitles" icon="captions" action={subs ? <Badge tone="green">{subs.cues.length} cues</Badge> : <Badge>none</Badge>} />
              <div className="px-5 pb-5 flex flex-wrap items-center gap-3 text-sm">
                {subs ? <label className="flex items-center gap-2"><input type="checkbox" checked={useSubs} onChange={(e) => setUseSubs(e.target.checked)} className="accent-purple size-4" /> Show subtitles</label> : <span className="text-muted">No subtitles for this video yet.</span>}
                <Button size="sm" icon="captions" onClick={() => navigate('subtitles', clipId ? { clip: clipId } : undefined)} disabled={!clipId}>{subs ? 'Edit subtitles' : 'Create subtitles'}</Button>
                {!clipId && <span className="text-xs text-muted">Save the video to your Library first to attach subtitles.</span>}
              </div>
            </Card>

            <Card>
              <CardHeader title="Export" icon="download" />
              <div className="px-5 pb-5 space-y-4">
                <Segmented value={preset} onChange={setPreset} options={[{ value: '1080x1920', label: '1080 × 1920' }, { value: '720x1280', label: '720 × 1280' }]} />
                <div className="grid sm:grid-cols-2 gap-3">
                  <div className="rounded-xl border border-white/5 p-4">
                    <div className="font-medium text-sm flex items-center gap-2"><Icon name="cpu" size={16} />On this device</div>
                    <p className="text-xs text-muted mt-1.5">Free. Real-time recording in your browser. Format: <b>{mime ? (mime.includes('mp4') ? 'MP4' : 'WebM') : 'not supported'}</b>{mime?.includes('webm') && ' (TikTok/IG accept MP4 best — Safari exports MP4)'}.</p>
                    <Button variant="primary" className="w-full mt-3" icon="download" onClick={exportLocal} disabled={!mime || exporting !== null || range[1] <= range[0]} loading={exporting !== null}>Export</Button>
                  </div>
                  <div className="rounded-xl border border-white/5 p-4">
                    <div className="font-medium text-sm flex items-center gap-2"><Icon name="database" size={16} />Server (FFmpeg)</div>
                    <p className="text-xs text-muted mt-1.5">MP4 H.264, faster than real-time, works when your phone is off. Needs cloud mode, the file in cloud storage and a running Engine.</p>
                    <Button className="w-full mt-3" icon="upload" onClick={exportServer} disabled={mode !== 'cloud' || !clip?.storage_path}>Queue render</Button>
                  </div>
                </div>
                {mode !== 'cloud' && <Notice tone="info" title="Server export unavailable in Local mode">On-device export works fully offline.</Notice>}
              </div>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}

function Timeline({ dur, range, t, onRange, onSeek }: { dur: number; range: [number, number]; t: number; onRange: (r: [number, number]) => void; onSeek: (t: number) => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const drag = useRef<'start' | 'end' | 'seek' | null>(null);
  const pos = (x: number) => (dur ? (x / dur) * 100 : 0);
  const at = (clientX: number) => { const r = ref.current!.getBoundingClientRect(); return Math.max(0, Math.min(dur, ((clientX - r.left) / r.width) * dur)); };
  const move = (e: RPointerEvent) => {
    if (!drag.current) return;
    const v = at(e.clientX);
    if (drag.current === 'start') onRange([Math.min(v, range[1] - 0.5), range[1]]);
    else if (drag.current === 'end') onRange([range[0], Math.max(v, range[0] + 0.5)]);
    else onSeek(v);
  };
  return (
    <div>
      <div ref={ref} className="relative h-14 rounded-xl bg-white/[.04] border border-white/5 touch-none select-none"
        onPointerDown={(e) => { (e.target as HTMLElement).setPointerCapture(e.pointerId); const role = (e.target as HTMLElement).dataset.role as 'start' | 'end' | undefined; drag.current = role ?? 'seek'; if (!role) onSeek(at(e.clientX)); }}
        onPointerMove={move} onPointerUp={() => (drag.current = null)}>
        <div className="absolute inset-y-0 bg-gradient-to-r from-purple/30 to-blue/30 border-y-2 border-purple/70" style={{ left: `${pos(range[0])}%`, width: `${pos(range[1] - range[0])}%` }} />
        {(['start', 'end'] as const).map((h) => (
          <div key={h} data-role={h} className="absolute inset-y-0 w-4 -ml-2 cursor-ew-resize grid place-items-center z-10" style={{ left: `${pos(h === 'start' ? range[0] : range[1])}%` }}>
            <span data-role={h} className="h-9 w-2 rounded-full bg-white shadow-[0_0_10px_#7857ff]" />
          </div>
        ))}
        <div className={cx('absolute inset-y-0 w-0.5 bg-green pointer-events-none')} style={{ left: `${pos(t)}%` }} />
      </div>
      <div className="flex justify-between text-[11px] text-muted font-mono mt-1.5"><span>0:00</span><span>{fmtTime(dur)}</span></div>
    </div>
  );
}
