import { AnimatePresence, motion } from 'framer-motion';
import { useEffect, useState } from 'react';
import { Badge, Button, Card, EmptyState, Field, Input, LiveDot, Modal, Notice, PageHeader, Slider, Switch } from '../components/ui.tsx';
import { Icon } from '../components/Icon.tsx';
import { api, type ChannelResult } from '../lib/api.ts';
import { db, toast, useStore } from '../lib/store.ts';
import { useSystem } from '../lib/system.ts';
import { isLive, refreshLive, useLive } from '../lib/live.ts';
import { navigate } from '../lib/router.ts';
import { cx, fmtNum, timeAgo } from '../lib/format.ts';
import type { Streamer } from '../lib/types.ts';

export function Avatar({ s, size = 48 }: { s: Pick<Streamer, 'login' | 'display_name' | 'profile_image_url'>; size?: number }) {
  if (s.profile_image_url) return <img src={s.profile_image_url} alt="" width={size} height={size} className="rounded-2xl object-cover shrink-0" style={{ width: size, height: size }} />;
  const hue = [...s.login].reduce((a, c) => a + c.charCodeAt(0), 0) % 360;
  return <div className="rounded-2xl grid place-items-center font-display font-semibold shrink-0" style={{ width: size, height: size, fontSize: size * 0.38, background: `linear-gradient(135deg, hsl(${hue} 70% 45%), hsl(${(hue + 50) % 360} 80% 55%))` }}>{(s.display_name ?? s.login).slice(0, 1).toUpperCase()}</div>;
}

export default function Streamers() {
  const streamers = useStore((s) => s.tables.streamers);
  const mode = useStore((s) => s.mode);
  const sys = useSystem();
  const live = useLive();
  const [q, setQ] = useState('');
  const [results, setResults] = useState<ChannelResult[]>([]);
  const [searching, setSearching] = useState(false);
  const [edit, setEdit] = useState<Streamer | null>(null);
  const canSearch = sys.api === 'online' && mode === 'cloud';

  useEffect(() => { refreshLive().catch(() => undefined); }, [sys.api, streamers.length]);

  useEffect(() => {
    if (!canSearch || q.trim().length < 2) { setResults([]); return; }
    const t = setTimeout(async () => {
      setSearching(true);
      try { setResults(await api<ChannelResult[]>(`/api/twitch/search?q=${encodeURIComponent(q.trim())}`)); }
      catch (e) { toast('error', 'Search failed', (e as Error).message); }
      finally { setSearching(false); }
    }, 350); // debounce to avoid unnecessary requests
    return () => clearTimeout(t);
  }, [q, canSearch]);

  async function add(r: { login: string; id?: string; display_name?: string; thumbnail_url?: string }) {
    const login = r.login.toLowerCase().trim();
    if (!/^[a-z0-9_]{2,25}$/.test(login)) return toast('error', 'Invalid Twitch username', 'Use 2–25 letters, numbers or underscores.');
    if (streamers.some((s) => s.login === login)) return toast('info', `${login} is already in your list`);
    try {
      await db.insert('streamers', { login, twitch_user_id: r.id ?? null, display_name: r.display_name ?? login, profile_image_url: r.thumbnail_url ?? null, is_favorite: false, monitor_enabled: true, auto_clip_enabled: false, preferences: {}, last_live_at: null });
      toast('success', `${r.display_name ?? login} added`);
      setQ(''); setResults([]);
    } catch (e) { toast('error', 'Could not add streamer', (e as Error).message); }
  }

  const sorted = [...streamers].sort((a, b) => Number(b.is_favorite) - Number(a.is_favorite) || Number(isLive(b.twitch_user_id)) - Number(isLive(a.twitch_user_id)) || a.login.localeCompare(b.login));
  const upd = (s: Streamer, p: Partial<Streamer>) => db.update('streamers', s.id, p).catch((e) => toast('error', 'Update failed', (e as Error).message));

  return (
    <div>
      <PageHeader title="Streamers" subtitle="Channels you clip. Live status and search come from the official Twitch Helix API." actions={canSearch && <Button icon="refresh" onClick={() => refreshLive(true).then(() => toast('success', 'Live status refreshed')).catch((e) => toast('error', 'Refresh failed', e.message))}>Refresh live</Button>} />

      <Card className="p-4 sm:p-5 mb-5">
        <div className="relative">
          <Icon name="search" className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder={canSearch ? 'Search Twitch channels…' : 'Twitch username (e.g. shroud)'} className="pl-10 pr-28" autoCapitalize="off" autoCorrect="off"
            onKeyDown={(e) => { if (e.key === 'Enter' && !canSearch) void add({ login: q }); }} />
          <div className="absolute right-1.5 top-1/2 -translate-y-1/2">
            {canSearch ? (searching && <span className="text-xs text-muted pr-3">Searching…</span>) : <Button size="sm" variant="primary" icon="plus" onClick={() => add({ login: q })} disabled={!q.trim()}>Add</Button>}
          </div>
        </div>
        {!canSearch && <p className="text-xs text-muted mt-2.5">Local mode: add by exact username. Search, profile pictures, IDs and live status need the backend + cloud account (Settings). Clips can only be created for channels with an ID.</p>}
        <AnimatePresence>
          {results.length > 0 && (
            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="mt-3 grid sm:grid-cols-2 gap-2 overflow-hidden">
              {results.map((r) => (
                <button key={r.id} onClick={() => add({ login: r.broadcaster_login, id: r.id, display_name: r.display_name, thumbnail_url: r.thumbnail_url })} className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-white/[.05] text-left border border-white/5">
                  <img src={r.thumbnail_url} alt="" className="size-10 rounded-xl" />
                  <span className="min-w-0 flex-1"><span className="flex items-center gap-2 text-sm font-medium">{r.display_name}{r.is_live && <Badge tone="red" dot>Live</Badge>}</span><span className="block text-xs text-muted truncate">{r.game_name || r.title || r.broadcaster_login}</span></span>
                  <Icon name="plus" className="text-muted" />
                </button>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </Card>

      <Notice tone="info" title="Only monitor sources you're allowed to use">Reading public chat is permitted by Twitch, but creating clips uses your own Twitch account and respects each channel's clip settings. For campaigns, make sure the streamer allows reposting their content.</Notice>

      {sorted.length === 0 ? (
        <Card className="mt-5"><EmptyState icon="users" title="No streamers yet">Search or type a Twitch username above to add your first channel.</EmptyState></Card>
      ) : (
        <div className="mt-5 grid sm:grid-cols-2 xl:grid-cols-3 gap-3">
          <AnimatePresence initial={false}>
            {sorted.map((s, i) => {
              const l = isLive(s.twitch_user_id); const info = s.twitch_user_id ? live.streams[s.twitch_user_id] : undefined;
              return (
                <motion.div key={s.id} layout initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0, transition: { delay: i * 0.03 } }} exit={{ opacity: 0, scale: 0.96 }}>
                  <Card hover className={cx('p-4 h-full', l && 'border-red/30')}>
                    <div className="flex items-start gap-3">
                      <div className="relative"><Avatar s={s} />{l && <span className="absolute -bottom-1 -right-1 px-1.5 rounded-md bg-red text-[9px] font-bold">LIVE</span>}</div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2"><span className="font-semibold truncate">{s.display_name ?? s.login}</span>{s.is_demo && <Badge tone="amber">Demo</Badge>}</div>
                        <div className="text-xs text-muted flex items-center gap-1.5 mt-0.5"><LiveDot live={l} />{l === null ? 'Live status unknown' : l ? `${fmtNum(info?.viewer_count)} viewers · ${info?.game_name ?? ''}` : 'Offline'}</div>
                        {!s.twitch_user_id && <div className="text-[11px] text-amber mt-1">No Twitch ID yet — re-add via search (cloud) to enable clipping</div>}
                      </div>
                      <button onClick={() => upd(s, { is_favorite: !s.is_favorite })} className={cx('size-9 grid place-items-center rounded-xl hover:bg-white/5', s.is_favorite ? 'text-amber' : 'text-muted')} aria-label="Favorite">
                        <Icon name="star" className={s.is_favorite ? 'fill-amber' : ''} />
                      </button>
                    </div>
                    {info?.title && <p className="text-xs text-muted mt-3 line-clamp-2">{info.title}</p>}
                    <div className="mt-4 space-y-2.5 text-sm">
                      <div className="flex items-center justify-between"><span className="text-muted">Monitor chat</span><Switch checked={s.monitor_enabled} onChange={(v) => upd(s, { monitor_enabled: v })} /></div>
                      <div className="flex items-center justify-between"><span className="text-muted">Auto clip</span><Switch checked={s.auto_clip_enabled} onChange={(v) => upd(s, { auto_clip_enabled: v })} disabled={!s.twitch_user_id && !s.is_demo} /></div>
                    </div>
                    <div className="mt-4 flex gap-2">
                      <Button size="sm" variant="secondary" icon="scissors" className="flex-1" onClick={() => navigate('manual', { streamer: s.id })} disabled={!s.twitch_user_id}>Clip</Button>
                      <Button size="sm" variant="ghost" icon="settings" onClick={() => setEdit(s)} aria-label="Preferences" />
                      <Button size="sm" variant="ghost" icon="external" onClick={() => window.open(`https://twitch.tv/${s.login}`, '_blank', 'noopener')} aria-label="Open on Twitch" />
                    </div>
                    {s.last_live_at && <div className="text-[11px] text-muted mt-2">Last live {timeAgo(s.last_live_at)}</div>}
                  </Card>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      )}
      <PrefsModal streamer={edit} onClose={() => setEdit(null)} />
    </div>
  );
}

function PrefsModal({ streamer, onClose }: { streamer: Streamer | null; onClose: () => void }) {
  const global = useStore((s) => s.settings.detector);
  const [p, setP] = useState<Streamer['preferences']>({});
  useEffect(() => { setP(streamer?.preferences ?? {}); }, [streamer]);
  if (!streamer) return <Modal open={false} onClose={onClose} title="">{null}</Modal>;
  const save = async () => { await db.update('streamers', streamer.id, { preferences: p }); toast('success', 'Preferences saved'); onClose(); };
  const remove = async () => { if (!confirm(`Remove ${streamer.login}? Clips are kept.`)) return; await db.remove('streamers', streamer.id); toast('success', 'Streamer removed'); onClose(); };
  return (
    <Modal open onClose={onClose} title={`${streamer.display_name ?? streamer.login} · clipping preferences`}
      footer={<><Button variant="danger" icon="trash" onClick={remove} className="mr-auto">Remove</Button><Button variant="ghost" onClick={() => setP({})}>Use global</Button><Button variant="primary" onClick={save}>Save</Button></>}>
      <p className="text-sm text-muted mb-4">Overrides for this channel only. Empty = global Auto Clipper settings.</p>
      <div className="space-y-5">
        <Field label={`Minimum viral score ${p.minScore == null ? `(global ${global.minScore})` : ''}`}><Slider value={p.minScore ?? global.minScore ?? 70} min={30} max={100} onChange={(v) => setP({ ...p, minScore: v })} /></Field>
        <Field label={`Cooldown ${p.cooldownSec == null ? `(global ${global.cooldownSec}s)` : ''}`}><Slider value={p.cooldownSec ?? global.cooldownSec ?? 120} min={30} max={900} step={15} suffix="s" onChange={(v) => setP({ ...p, cooldownSec: v })} /></Field>
        <Field label={`Max clips per hour ${p.maxPerHour == null ? `(global ${global.maxPerHour})` : ''}`}><Slider value={p.maxPerHour ?? global.maxPerHour ?? 6} min={1} max={30} onChange={(v) => setP({ ...p, maxPerHour: v })} /></Field>
      </div>
    </Modal>
  );
}
