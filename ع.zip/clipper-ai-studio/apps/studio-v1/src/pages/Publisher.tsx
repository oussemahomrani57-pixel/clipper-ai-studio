import { useEffect, useState } from 'react';
import { Badge, Button, Card, CardHeader, EmptyState, Field, Input, Modal, Notice, PageHeader, Select } from '../components/ui.tsx';
import { Icon } from '../components/Icon.tsx';
import { files } from '../lib/idb.ts';
import { useRoute } from '../lib/router.ts';
import { db, toast, useStore } from '../lib/store.ts';
import { cx, download, fmtNum, timeAgo } from '../lib/format.ts';
import type { Platform, Post } from '../lib/types.ts';

export const PLATFORMS: Record<Platform, { label: string; color: string; captionMax: number; hashtagMax: number; domains: RegExp; api: string[] }> = {
  tiktok: { label: 'TikTok', color: '#ff2d55', captionMax: 2200, hashtagMax: 30, domains: /(^|\.)tiktok\.com$/, api: ['TikTok developer app + Content Posting API', 'App audit by TikTok — unaudited apps can only post privately', 'OAuth scope video.publish'] },
  instagram: { label: 'Instagram Reels', color: '#c13584', captionMax: 2200, hashtagMax: 30, domains: /(^|\.)instagram\.com$/, api: ['Instagram Professional (Business/Creator) account linked to a Facebook Page', 'Meta app with instagram_content_publish + review', 'Video must be at a public URL for the Graph API'] },
  youtube: { label: 'YouTube Shorts', color: '#ff0000', captionMax: 5000, hashtagMax: 15, domains: /(^|\.)(youtube\.com|youtu\.be)$/, api: ['Google Cloud project + YouTube Data API v3', 'OAuth scope youtube.upload; unverified apps upload as private only', 'Quota: an upload costs a large share of the default daily quota'] },
};

export default function Publisher() {
  const { params } = useRoute();
  const clips = useStore((s) => s.tables.clips);
  const posts = useStore((s) => s.tables.posts);
  const [clipId, setClipId] = useState(params.get('clip') ?? '');
  const [caption, setCaption] = useState('');
  const [tags, setTags] = useState('');
  const [targets, setTargets] = useState<Platform[]>(['tiktok', 'youtube', 'instagram']);
  const [hasFile, setHasFile] = useState(false);
  const [confirm, setConfirm] = useState<Post | null>(null);
  const clip = clips.find((c) => c.id === clipId);

  useEffect(() => { if (clip && !caption) setCaption(clip.title ?? ''); if (clipId) files.get(clipId).then((b) => setHasFile(!!b)); else setHasFile(false); }, [clipId]); // eslint-disable-line react-hooks/exhaustive-deps

  const hashtags = tags.split(/[\s,]+/).map((h) => h.replace(/^#/, '').trim()).filter(Boolean);
  const full = `${caption.trim()}${hashtags.length ? `\n\n${hashtags.map((h) => `#${h}`).join(' ')}` : ''}`;

  async function prepare() {
    if (!clipId) return toast('error', 'Choose a clip first');
    for (const p of targets) {
      const L = PLATFORMS[p];
      if (full.length > L.captionMax) return toast('error', `${L.label}: caption too long`, `${full.length}/${L.captionMax} characters`);
      if (hashtags.length > L.hashtagMax) return toast('error', `${L.label}: too many hashtags`, `max ${L.hashtagMax}`);
    }
    for (const p of targets) await db.insert('posts', { clip_id: clipId, platform: p, caption: full, hashtags, status: 'ready', method: 'manual', scheduled_at: null, post_url: null, error: null, views: null });
    toast('success', `${targets.length} post(s) ready`, 'Share the video, then confirm each post with its URL.');
  }

  async function share() {
    const blob = clipId ? await files.get(clipId) : undefined;
    await navigator.clipboard?.writeText(full).catch(() => undefined);
    if (blob) {
      const file = new File([blob], `${(clip?.title ?? 'clip').replace(/[^\w-]+/g, '_')}.${blob.type.includes('mp4') ? 'mp4' : 'webm'}`, { type: blob.type });
      if (navigator.canShare?.({ files: [file] })) {
        try { await navigator.share({ files: [file], text: full }); toast('info', 'Caption copied', 'Paste it in the app you shared to.'); return; } catch { return; }
      }
      download(file.name, blob); toast('info', 'Video downloaded & caption copied');
    } else if (clip?.url) {
      if (navigator.share) await navigator.share({ url: clip.url, text: full }).catch(() => undefined);
      else toast('info', 'Caption copied');
    } else toast('error', 'No video file on this device for this clip');
  }

  return (
    <div>
      <PageHeader title="Social Publisher" subtitle="Prepare captions, share to TikTok, Reels and Shorts, and track every post. Nothing is marked published until you confirm the live URL." />
      <div className="grid lg:grid-cols-5 gap-4">
        <Card className="lg:col-span-3">
          <CardHeader title="Compose" icon="edit" />
          <div className="px-5 pb-5 space-y-4">
            <Select value={clipId} onChange={setClipId} options={[{ value: '', label: 'Choose a clip…' }, ...clips.map((c) => ({ value: c.id, label: `${c.title ?? 'Untitled'}${c.is_demo ? ' (demo)' : ''}` }))]} />
            <Field label="Caption / description"><textarea value={caption} onChange={(e) => setCaption(e.target.value)} rows={4} className="field resize-y" placeholder="Hook + context. Tag the streamer if the campaign requires it." /></Field>
            <Field label="Hashtags" hint="Space or comma separated"><Input value={tags} onChange={(e) => setTags(e.target.value)} placeholder="#twitch #gaming #clips" /></Field>
            <div>
              <div className="text-[13px] font-medium mb-2">Destinations</div>
              <div className="grid sm:grid-cols-3 gap-2">
                {(Object.keys(PLATFORMS) as Platform[]).map((p) => {
                  const on = targets.includes(p); const L = PLATFORMS[p]; const over = full.length > L.captionMax;
                  return (
                    <button key={p} onClick={() => setTargets(on ? targets.filter((x) => x !== p) : [...targets, p])} className={cx('rounded-xl border p-3 text-left transition-colors', on ? 'border-purple/50 bg-purple/10' : 'border-white/5 bg-white/[.02]')}>
                      <div className="flex items-center justify-between"><span className="text-sm font-medium flex items-center gap-2"><span className="size-2.5 rounded-full" style={{ background: L.color }} />{L.label}</span>{on && <Icon name="check" size={15} className="text-purple" />}</div>
                      <div className={cx('text-[11px] mt-1 tabular-nums', over ? 'text-red' : 'text-muted')}>{full.length}/{L.captionMax} chars · {hashtags.length}/{L.hashtagMax} tags</div>
                    </button>
                  );
                })}
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button variant="primary" icon="check" onClick={prepare} disabled={!clipId || !targets.length}>Create post records</Button>
              <Button icon="share" onClick={share} disabled={!clipId}>{hasFile ? 'Share video to app' : 'Share link'}</Button>
              <Button variant="ghost" icon="copy" onClick={() => navigator.clipboard.writeText(full).then(() => toast('success', 'Caption copied'))}>Copy caption</Button>
            </div>
            <p className="text-xs text-muted">On iPhone, “Share video to app” opens the iOS share sheet so you can send the MP4 straight to TikTok, Instagram or YouTube.</p>
          </div>
        </Card>

        <div className="lg:col-span-2 space-y-3">
          {(Object.keys(PLATFORMS) as Platform[]).map((p) => (
            <Card key={p} className="p-4">
              <div className="flex items-center justify-between"><span className="font-medium flex items-center gap-2"><span className="size-2.5 rounded-full" style={{ background: PLATFORMS[p].color }} />{PLATFORMS[p].label}</span><Badge>API not connected</Badge></div>
              <p className="text-xs text-muted mt-2">Direct upload/scheduling via API is <b>planned</b> and needs:</p>
              <ul className="text-xs text-muted mt-1 space-y-0.5">{PLATFORMS[p].api.map((a) => <li key={a}>• {a}</li>)}</ul>
            </Card>
          ))}
        </div>
      </div>

      <Card className="mt-4">
        <CardHeader title="Posts" subtitle="Publishing status tracking" icon="send" />
        <div className="px-5 pb-5">
          {posts.length === 0 ? <EmptyState icon="send" title="No posts yet">Create post records above to track where each clip goes.</EmptyState> : (
            <div className="divide-y divide-white/5">
              {posts.map((p) => {
                const c = clips.find((x) => x.id === p.clip_id);
                return (
                  <div key={p.id} className="py-3 flex flex-wrap items-center gap-3">
                    <span className="size-2.5 rounded-full" style={{ background: PLATFORMS[p.platform].color }} />
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-medium truncate">{c?.title ?? 'Deleted clip'} <span className="text-muted font-normal">· {PLATFORMS[p.platform].label}</span> {p.is_demo && <Badge tone="amber">Demo</Badge>}</div>
                      <div className="text-xs text-muted">{timeAgo(p.created_at)}{p.views != null && ` · ${fmtNum(p.views)} views`}{p.post_url && <> · <a className="text-blue" href={p.post_url} target="_blank" rel="noopener noreferrer">open</a></>}</div>
                    </div>
                    <Badge tone={p.status === 'published' ? 'green' : p.status === 'failed' ? 'red' : 'blue'}>{p.status}</Badge>
                    <Button size="sm" variant="secondary" onClick={() => setConfirm(p)}>{p.status === 'published' ? 'Update' : 'Confirm published'}</Button>
                    <Button size="sm" variant="ghost" icon="trash" aria-label="Delete" onClick={() => db.remove('posts', p.id)} />
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </Card>
      <ConfirmModal post={confirm} onClose={() => setConfirm(null)} />
    </div>
  );
}

function ConfirmModal({ post, onClose }: { post: Post | null; onClose: () => void }) {
  const [url, setUrl] = useState(''); const [views, setViews] = useState('');
  useEffect(() => { setUrl(post?.post_url ?? ''); setViews(post?.views?.toString() ?? ''); }, [post]);
  if (!post) return null;
  const L = PLATFORMS[post.platform];
  async function save() {
    let host = '';
    try { const u = new URL(url); host = u.hostname; if (u.protocol !== 'https:') throw new Error(); } catch { return toast('error', 'Enter a valid https:// URL'); }
    if (!L.domains.test(host)) return toast('error', `That isn't a ${L.label} URL`);
    const v = views.trim() === '' ? null : Math.max(0, Math.round(Number(views)));
    await db.update('posts', post!.id, { post_url: url, status: 'published', views: Number.isFinite(v as number) ? v : null });
    if (post!.clip_id) await db.update('clips', post!.clip_id, { publish_status: 'published' }).catch(() => undefined);
    toast('success', 'Marked as published'); onClose();
  }
  return (
    <Modal open onClose={onClose} title={`Confirm ${L.label} post`} footer={<><Button variant="ghost" onClick={onClose}>Cancel</Button><Button variant="primary" onClick={save}>Save</Button></>}>
      <Notice tone="info" title="Published only when you confirm">Paste the live post URL from {L.label}. Views are entered by you from the platform's own stats.</Notice>
      <div className="space-y-4 mt-4">
        <Field label="Post URL"><Input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://" inputMode="url" /></Field>
        <Field label="Views (optional)"><Input value={views} onChange={(e) => setViews(e.target.value)} inputMode="numeric" placeholder="e.g. 12500" /></Field>
      </div>
    </Modal>
  );
}
