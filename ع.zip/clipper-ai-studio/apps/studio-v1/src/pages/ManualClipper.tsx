import { AnimatePresence, motion } from 'framer-motion';
import { useEffect, useRef, useState, useMemo } from 'react';
import { Badge, Button, Card, CardHeader, Field, Input, Notice, PageHeader, Progress, Select, Slider, Switch } from '../components/ui.tsx';
import { Icon } from '../components/Icon.tsx';
import { Avatar } from './Streamers.tsx';
import { api, ApiError } from '../lib/api.ts';
import { db, notify, toast, useStore } from '../lib/store.ts';
import { twitchReady, useSystem } from '../lib/system.ts';
import { navigate, useRoute } from '../lib/router.ts';
import { cx } from '../lib/format.ts';

type Phase = 'idle' | 'requesting' | 'processing' | 'ready' | 'failed';
const STEPS = ['Send Create Clip request', 'Twitch accepts (clip ID)', 'Twitch processes the clip', 'Confirm & save to library'];

export default function ManualClipper() {
  const { params } = useRoute();
  const allStreamers = useStore((s) => s.tables.streamers);
  const streamers = useMemo(() => allStreamers.filter((x) => x.twitch_user_id), [allStreamers]);
  const sys = useSystem();
  const ready = twitchReady(sys);
  const [sid, setSid] = useState(params.get('streamer') ?? '');
  const [title, setTitle] = useState('');
  const [useDuration, setUseDuration] = useState(false);
  const [duration, setDuration] = useState(30);
  const [phase, setPhase] = useState<Phase>('idle');
  const [err, setErr] = useState<string | null>(null);
  const [result, setResult] = useState<{ clipId: string; url?: string; editUrl?: string; twitchId?: string; thumb?: string } | null>(null);
  const [elapsed, setElapsed] = useState(0);
  const cancelled = useRef(false);

  useEffect(() => { if (!sid && streamers[0]) setSid(streamers[0].id); }, [streamers, sid]);
  useEffect(() => () => { cancelled.current = true; }, []);
  useEffect(() => {
    if (phase !== 'processing') return;
    const t = setInterval(() => setElapsed((e) => e + 1), 1000);
    return () => clearInterval(t);
  }, [phase]);

  const streamer = streamers.find((s) => s.id === sid);
  const step = phase === 'idle' ? -1 : phase === 'requesting' ? 0 : phase === 'processing' ? (elapsed < 3 ? 1 : 2) : 3;

  async function clip() {
    if (!streamer?.twitch_user_id) return;
    setPhase('requesting'); setErr(null); setResult(null); setElapsed(0);
    try {
      const r = await api<{ clip_id: string; twitch_clip_id: string; edit_url: string }>('/api/clips', {
        method: 'POST',
        body: JSON.stringify({ broadcaster_id: streamer.twitch_user_id, streamer_id: streamer.id, title: title.trim() || undefined, duration: useDuration ? duration : undefined, type: 'manual' }),
      });
      setResult({ clipId: r.clip_id, editUrl: r.edit_url, twitchId: r.twitch_clip_id });
      setPhase('processing');
      await db.refresh('clips');
      // Twitch recommends checking ~15 s after creation; poll up to ~60 s.
      await new Promise((res) => setTimeout(res, 12_000));
      for (let i = 0; i < 10 && !cancelled.current; i++) {
        const c = await api<{ status: 'ready' | 'processing' | 'failed'; clip?: { url: string; thumbnail_url: string } }>(`/api/clips/${r.clip_id}/confirm`, { method: 'POST' });
        if (c.status === 'ready') {
          setResult((x) => ({ ...x!, url: c.clip?.url, thumb: c.clip?.thumbnail_url }));
          setPhase('ready'); toast('success', 'Clip created!', streamer.display_name ?? streamer.login);
          await db.refresh('clips'); await db.refresh('notifications');
          return;
        }
        if (c.status === 'failed') throw new Error('Twitch did not confirm the clip (stream offline, clipping disabled by the channel, or processing failed).');
        await new Promise((res) => setTimeout(res, 5000));
      }
    } catch (e) {
      const msg = e instanceof ApiError && e.status === 404 && /offline|not live/i.test(e.message) ? 'The channel is offline — Twitch can only clip live streams.' : (e as Error).message;
      setErr(msg); setPhase('failed');
      toast('error', 'Clip failed', msg);
      void notify('clip_failed', 'Clip creation failed', msg, '#/manual');
    }
  }

  const busy = phase === 'requesting' || phase === 'processing';
  const parent = typeof location !== 'undefined' ? location.hostname : 'localhost';

  return (
    <div>
      <PageHeader title="Manual Clipper" subtitle="Create a native Twitch clip of what's happening right now, with the official Create Clip API." />
      {!ready && (
        <div className="mb-5">
          <Notice tone="warn" title="Requires your cloud account, the API Worker and a connected Twitch account" action={<Button size="sm" variant="primary" onClick={() => navigate('settings')}>Open setup</Button>}>
            Status now — API: <b>{sys.api.replace('_', ' ')}</b>, Twitch: <b>{sys.twitch.length ? sys.twitch[0].status : 'not connected'}</b>. The button stays disabled until a real request can be sent.
          </Notice>
        </div>
      )}
      <div className="grid lg:grid-cols-5 gap-4">
        <Card className="lg:col-span-3 p-5 sm:p-7">
          <div className="space-y-4">
            <Field label="Streamer">
              {streamers.length ? (
                <Select value={sid} onChange={setSid} options={streamers.map((s) => ({ value: s.id, label: s.display_name ?? s.login }))} />
              ) : <Button className="w-full" icon="plus" onClick={() => navigate('streamers')}>Add a streamer with a Twitch ID first</Button>}
            </Field>
            {streamer && <div className="flex items-center gap-3 p-3 rounded-xl bg-white/[.03]"><Avatar s={streamer} size={40} /><div className="text-sm"><div className="font-medium">{streamer.display_name}</div><div className="text-muted text-xs">twitch.tv/{streamer.login}</div></div></div>}
            <Field label="Clip title (optional)" hint="Sent to Twitch as the clip title. If empty, Twitch uses its default (the stream title).">
              <Input value={title} maxLength={100} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Insane clutch 1v4" />
            </Field>
            <div className="rounded-xl border border-white/5 p-3.5">
              <div className="flex items-center justify-between"><span className="text-sm">Custom duration <span className="text-muted">(optional)</span></span><Switch checked={useDuration} onChange={setUseDuration} /></div>
              {useDuration && <div className="mt-3"><Slider value={duration} min={5} max={60} onChange={setDuration} suffix="s" /><p className="text-xs text-muted mt-2">Twitch added an optional duration parameter to Create Clip (Dec 2025). Twitch validates the value — if it's rejected you'll see the exact error. There is no start-time control: clips always capture the moments just before the request.</p></div>}
            </div>
          </div>

          <div className="flex flex-col items-center mt-8">
            <motion.button whileTap={{ scale: 0.95 }} onClick={clip} disabled={!ready || !streamer || busy}
              className={cx('relative size-44 sm:size-52 rounded-full grid place-items-center font-display font-bold text-lg tracking-wide text-white transition-opacity disabled:opacity-40', ready && !busy && 'ring-pulse')}
              style={{ background: 'radial-gradient(circle at 30% 25%, #9d86ff, #7857ff 45%, #3a5bff 80%, #32a5ff)' }}>
              <span className="absolute inset-2 rounded-full border border-white/20" />
              {busy ? <span className="flex flex-col items-center gap-2"><span className="size-8 rounded-full border-[3px] border-white/30 border-t-white animate-spin-slow" /><span className="text-sm">{phase === 'requesting' ? 'Requesting…' : `Processing ${elapsed}s`}</span></span>
                : <span className="flex flex-col items-center gap-1.5"><Icon name="scissors" size={34} />CLIP RIGHT<br />NOW</span>}
            </motion.button>
            <p className="text-xs text-muted mt-4 text-center max-w-sm">The channel must be live and allow clips. Uses your Twitch account (scope clips:edit).</p>
          </div>
        </Card>

        <div className="lg:col-span-2 space-y-4">
          <Card>
            <CardHeader title="Request status" icon="clock" action={phase !== 'idle' && <Badge tone={phase === 'ready' ? 'green' : phase === 'failed' ? 'red' : 'blue'} dot={busy}>{phase}</Badge>} />
            <div className="px-5 pb-5 space-y-3">
              <Progress value={phase === 'ready' ? 100 : phase === 'failed' ? 100 : ((step + 1) / STEPS.length) * 100} tone={phase === 'failed' ? 'red' : phase === 'ready' ? 'green' : 'brand'} />
              {STEPS.map((s, i) => (
                <div key={s} className="flex items-center gap-3 text-sm">
                  <span className={cx('grid place-items-center size-6 rounded-full text-[11px] font-semibold border', i < step || phase === 'ready' ? 'bg-green/15 border-green/40 text-green' : i === step && phase !== 'failed' ? 'border-blue text-blue' : phase === 'failed' && i === step ? 'border-red text-red' : 'border-white/10 text-muted')}>
                    {i < step || phase === 'ready' ? <Icon name="check" size={12} /> : i + 1}
                  </span>
                  <span className={i <= step ? '' : 'text-muted'}>{s}</span>
                </div>
              ))}
              <AnimatePresence>
                {err && <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="rounded-xl bg-red/10 border border-red/25 p-3 text-sm text-red">{err}<div className="mt-2"><Button size="sm" variant="danger" icon="refresh" onClick={clip}>Retry</Button></div></motion.div>}
              </AnimatePresence>
            </div>
          </Card>

          <Card>
            <CardHeader title="Clip preview" icon="play" />
            <div className="px-5 pb-5">
              {phase === 'ready' && result?.twitchId ? (
                <>
                  <div className="aspect-video rounded-xl overflow-hidden bg-black">
                    <iframe title="Clip preview" src={`https://clips.twitch.tv/embed?clip=${result.twitchId}&parent=${parent}&autoplay=false`} className="w-full h-full" allowFullScreen />
                  </div>
                  <div className="flex flex-wrap gap-2 mt-3">
                    {result.url && <Button size="sm" icon="external" onClick={() => window.open(result.url, '_blank', 'noopener')}>Open clip</Button>}
                    {result.editUrl && <Button size="sm" icon="edit" onClick={() => window.open(result.editUrl, '_blank', 'noopener')}>Edit on Twitch</Button>}
                    <Button size="sm" variant="ghost" icon="library" onClick={() => navigate('library')}>Library</Button>
                  </div>
                </>
              ) : <div className="aspect-video rounded-xl border border-dashed border-white/10 grid place-items-center text-sm text-muted">{busy ? 'Waiting for Twitch…' : 'Your clip appears here'}</div>}
            </div>
          </Card>

          <Notice tone="info" title="Native clip ≠ downloaded footage">A Twitch clip lives on Twitch (link, embed, edit page). Downloading the video file through the API is only allowed for the broadcaster or their editors. To edit vertically, use clips from your own channel or a file you have rights to (Video Editor → upload).</Notice>
        </div>
      </div>
    </div>
  );
}
