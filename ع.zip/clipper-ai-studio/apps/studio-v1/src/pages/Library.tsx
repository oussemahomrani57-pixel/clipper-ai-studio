import { AnimatePresence, motion } from 'framer-motion';
import { useEffect, useMemo, useRef, useState } from 'react';
import { Badge, Button, Card, EmptyState, Field, Input, Modal, PageHeader, Select } from '../components/ui.tsx';
import { Icon } from '../components/Icon.tsx';
import { api } from '../lib/api.ts';
import { auth } from '../lib/auth.ts';
import { config } from '../lib/config.ts';
import { files } from '../lib/idb.ts';
import { navigate } from '../lib/router.ts';
import { db, toast, useStore } from '../lib/store.ts';
import { cx, download, timeAgo } from '../lib/format.ts';
import type { Clip } from '../lib/types.ts';

type Filter = 'all' | 'manual' | 'auto' | 'upload' | 'processing' | 'ready' | 'failed' | 'published';
const FILTERS: Filter[] = ['all', 'manual', 'auto', 'upload', 'processing', 'ready', 'failed', 'published'];

export function ClipThumb({ clip, className }: { clip: Clip; className?: string }) {
  const hue = [...(clip.streamer_login ?? clip.id)].reduce((a, c) => a + c.charCodeAt(0), 0) % 360;
  return (
    <div className={cx('relative aspect-video rounded-xl overflow-hidden border border-white/5', className)} style={{ background: `linear-gradient(135deg, hsl(${hue} 55% 22%), hsl(${(hue + 60) % 360} 60% 14%))` }}>
      {clip.thumbnail_url ? <img src={clip.thumbnail_url} alt="" loading="lazy" className="absolute inset-0 size-full object-cover" /> : <Icon name={clip.type === 'upload' ? 'film' : 'play'} size={28} className="absolute inset-0 m-auto text-white/40" />}
      <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-black/70 to-transparent" />
      <div className="absolute top-2 left-2 flex gap-1">
        <Badge tone={clip.type === 'auto' ? 'purple' : clip.type === 'manual' ? 'blue' : 'muted'}>{clip.type}</Badge>
        {clip.is_demo && <Badge tone="amber">Demo</Badge>}
      </div>
      {clip.detection_score != null && <span className="absolute top-2 right-2 px-1.5 py-0.5 rounded-md bg-black/60 text-[11px] font-mono">⚡{clip.detection_score}</span>}
      {clip.status === 'processing' && <div className="absolute inset-0 skeleton opacity-40" />}
      {clip.duration_sec != null && <span className="absolute bottom-2 right-2 text-[11px] font-mono text-white/90">{Math.round(clip.duration_sec)}s</span>}
    </div>
  );
}

const statusTone = (s: Clip['status']) => (s === 'ready' ? 'green' : s === 'failed' ? 'red' : 'blue') as 'green' | 'red' | 'blue';

export default function Library() {
  const clips = useStore((s) => s.tables.clips);
  const mode = useStore((s) => s.mode);
  const [filter, setFilter] = useState<Filter>('all');
  const [q, setQ] = useState('');
  const [sort, setSort] = useState<'new' | 'old' | 'score'>('new');
  const [page, setPage] = useState(1);
  const [preview, setPreview] = useState<Clip | null>(null);
  const [edit, setEdit] = useState<Clip | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const PER = 24;

  const list = useMemo(() => {
    let l = clips.filter((c) => {
      if (filter === 'all') return true;
      if (filter === 'published') return c.publish_status === 'published';
      if (['manual', 'auto', 'upload'].includes(filter)) return c.type === filter;
      return c.status === filter || (filter === 'processing' && c.status === 'requested');
    });
    if (q.trim()) { const k = q.toLowerCase(); l = l.filter((c) => `${c.title} ${c.streamer_login}`.toLowerCase().includes(k)); }
    return [...l].sort((a, b) => sort === 'score' ? (b.detection_score ?? -1) - (a.detection_score ?? -1) : sort === 'old' ? a.created_at.localeCompare(b.created_at) : b.created_at.localeCompare(a.created_at));
  }, [clips, filter, q, sort]);
  useEffect(() => setPage(1), [filter, q, sort]);

  async function upload(f: File) {
    if (!f.type.startsWith('video/')) return toast('error', 'Please choose a video file');
    if (f.size > 500 * 1024 * 1024) return toast('error', 'File too large', 'Max 500 MB on device.');
    const id = crypto.randomUUID();
    try {
      await files.put(id, f);
      let storage_path: string | null = null;
      if (mode === 'cloud') {
        const token = await auth.token();
        storage_path = `${auth.session!.user.id}/uploads/${id}-${f.name.replace(/[^\w.-]/g, '_')}`;
        const r = await fetch(`${config.supabaseUrl}/storage/v1/object/videos/${storage_path}`, { method: 'POST', headers: { apikey: config.supabaseAnonKey, Authorization: `Bearer ${token}`, 'Content-Type': f.type }, body: f });
        if (!r.ok) { storage_path = null; toast('error', 'Cloud upload failed — kept on this device only'); }
      }
      const v = document.createElement('video');
      v.preload = 'metadata'; v.src = URL.createObjectURL(f);
      const duration = await new Promise<number | null>((res) => { v.onloadedmetadata = () => res(v.duration); v.onerror = () => res(null); });
      await db.insert('clips', { id, title: f.name.replace(/\.[^.]+$/, ''), type: 'upload', status: 'ready', publish_status: 'unpublished', streamer_login: null, streamer_id: null, twitch_clip_id: null, url: null, edit_url: null, thumbnail_url: null, detection_score: null, error: null, storage_path, local_file: true, duration_sec: duration });
      toast('success', 'Video added', storage_path ? 'Saved on device + cloud' : 'Saved on this device');
    } catch (e) { toast('error', 'Upload failed', (e as Error).message); }
  }

  async function retry(c: Clip) {
    try {
      const r = await api<{ status: string }>(`/api/clips/${c.id}/confirm`, { method: 'POST' });
      await db.refresh('clips');
      toast(r.status === 'ready' ? 'success' : 'info', `Status: ${r.status}`);
    } catch (e) { toast('error', 'Retry failed', (e as Error).message); }
  }

  async function remove(c: Clip) {
    if (!confirm('Delete this clip record? (The Twitch clip itself stays on Twitch.)')) return;
    await db.remove('clips', c.id).catch((e) => toast('error', 'Delete failed', e.message));
    if (c.local_file) void files.remove(c.id);
  }

  function exportMeta(kind: 'json' | 'csv') {
    const cols = ['id', 'created_at', 'type', 'status', 'publish_status', 'streamer_login', 'title', 'url', 'detection_score', 'duration_sec', 'is_demo'] as const;
    if (kind === 'json') return download('clips.json', JSON.stringify(list, null, 2));
    const esc = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""')}"`;
    download('clips.csv', [cols.join(','), ...list.map((c) => cols.map((k) => esc(c[k])).join(','))].join('\n'), 'text/csv');
  }

  const counts = (f: Filter) => f === 'all' ? clips.length : f === 'published' ? clips.filter((c) => c.publish_status === 'published').length : ['manual', 'auto', 'upload'].includes(f) ? clips.filter((c) => c.type === f).length : clips.filter((c) => c.status === f).length;

  return (
    <div>
      <PageHeader title="Clip Library" subtitle="Every Twitch clip and uploaded video in one place."
        actions={<>
          <input ref={fileRef} type="file" accept="video/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) void upload(f); e.target.value = ''; }} />
          <Button variant="primary" icon="upload" onClick={() => fileRef.current?.click()}>Upload video</Button>
          <Button icon="download" onClick={() => exportMeta('csv')}>CSV</Button>
          <Button icon="download" variant="ghost" onClick={() => exportMeta('json')}>JSON</Button>
        </>} />

      <div className="flex flex-col sm:flex-row gap-2 mb-4">
        <div className="relative flex-1"><Icon name="search" className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" /><Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search title or streamer" className="pl-10" /></div>
        <Select value={sort} onChange={setSort} className="sm:w-48" options={[{ value: 'new', label: 'Newest first' }, { value: 'old', label: 'Oldest first' }, { value: 'score', label: 'Highest score' }]} />
      </div>
      <div className="flex gap-1.5 overflow-x-auto no-scrollbar pb-1 mb-5">
        {FILTERS.map((f) => (
          <button key={f} onClick={() => setFilter(f)} className={cx('shrink-0 px-3.5 h-9 rounded-xl text-sm capitalize border transition-colors', filter === f ? 'bg-purple/20 border-purple/40 text-white' : 'bg-white/[.03] border-white/5 text-muted hover:text-text')}>
            {f} <span className="text-xs opacity-60 ml-0.5">{counts(f)}</span>
          </button>
        ))}
      </div>

      {list.length === 0 ? <Card><EmptyState icon="library" title="No clips here" action={<Button onClick={() => navigate('manual')} icon="scissors">Create a clip</Button>}>Try another filter, create a Twitch clip, or upload a video you have rights to.</EmptyState></Card> : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
            <AnimatePresence initial={false}>
              {list.slice(0, page * PER).map((c, i) => (
                <motion.div key={c.id} layout initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0, transition: { delay: Math.min(i, 12) * 0.025 } }} exit={{ opacity: 0, scale: 0.95 }}>
                  <Card hover className="p-3">
                    <button className="block w-full" onClick={() => setPreview(c)}><ClipThumb clip={c} /></button>
                    <div className="mt-3 px-1">
                      <div className="font-medium text-sm truncate">{c.title ?? 'Untitled clip'}</div>
                      <div className="text-xs text-muted mt-0.5">{c.streamer_login ?? 'Uploaded'} · {timeAgo(c.created_at)}</div>
                      <div className="flex flex-wrap gap-1 mt-2">
                        <Badge tone={statusTone(c.status)} dot={c.status === 'processing'}>{c.status}</Badge>
                        <Badge tone={c.publish_status === 'published' ? 'green' : 'muted'}>{c.publish_status}</Badge>
                      </div>
                      {c.error && <p className="text-xs text-red mt-2 line-clamp-2">{c.error}</p>}
                    </div>
                    <div className="flex gap-1 mt-3">
                      {c.status === 'failed' && c.twitch_clip_id && <Button size="sm" variant="secondary" icon="refresh" onClick={() => retry(c)}>Retry</Button>}
                      {(c.type === 'upload' || c.storage_path) && <Button size="sm" variant="secondary" icon="film" onClick={() => navigate('editor', { clip: c.id })}>Edit</Button>}
                      <Button size="sm" variant="ghost" icon="send" onClick={() => navigate('publisher', { clip: c.id })} aria-label="Publish" />
                      <Button size="sm" variant="ghost" icon="edit" onClick={() => setEdit(c)} aria-label="Edit metadata" />
                      <Button size="sm" variant="ghost" icon="trash" onClick={() => remove(c)} aria-label="Delete" className="ml-auto hover:text-red" />
                    </div>
                  </Card>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
          {list.length > page * PER && <div className="flex justify-center mt-6"><Button onClick={() => setPage((p) => p + 1)}>Load more ({list.length - page * PER})</Button></div>}
        </>
      )}
      <PreviewModal clip={preview} onClose={() => setPreview(null)} />
      <MetaModal clip={edit} onClose={() => setEdit(null)} />
    </div>
  );
}

function PreviewModal({ clip, onClose }: { clip: Clip | null; onClose: () => void }) {
  const [src, setSrc] = useState<string | null>(null);
  useEffect(() => {
    setSrc(null);
    if (!clip?.local_file) return;
    let url: string | null = null;
    files.get(clip.id).then((b) => { if (b) { url = URL.createObjectURL(b); setSrc(url); } });
    return () => { if (url) URL.revokeObjectURL(url); };
  }, [clip]);
  return (
    <Modal open={!!clip} onClose={onClose} title={clip?.title ?? 'Preview'} wide>
      {clip && (
        <div>
          {clip.twitch_clip_id && !clip.is_demo ? (
            <div className="aspect-video rounded-xl overflow-hidden bg-black"><iframe title="clip" className="size-full" allowFullScreen src={`https://clips.twitch.tv/embed?clip=${clip.twitch_clip_id}&parent=${location.hostname}&autoplay=true`} /></div>
          ) : src ? <video src={src} controls playsInline className="w-full max-h-[60dvh] rounded-xl bg-black" />
            : <div className="aspect-video rounded-xl grid place-items-center bg-black/40 text-sm text-muted text-center p-6">{clip.is_demo ? 'DEMO clip — no video attached.' : clip.local_file ? 'Loading…' : 'Video file is not stored on this device.'}</div>}
          <div className="flex flex-wrap gap-2 mt-4">
            {clip.url && <Button size="sm" icon="external" onClick={() => window.open(clip.url!, '_blank', 'noopener')}>Open on Twitch</Button>}
            {clip.edit_url && <Button size="sm" icon="edit" onClick={() => window.open(clip.edit_url!, '_blank', 'noopener')}>Twitch editor</Button>}
            {clip.url && <Button size="sm" icon="copy" onClick={() => navigator.clipboard.writeText(clip.url!).then(() => toast('success', 'Link copied'))}>Copy link</Button>}
          </div>
        </div>
      )}
    </Modal>
  );
}

function MetaModal({ clip, onClose }: { clip: Clip | null; onClose: () => void }) {
  const [title, setTitle] = useState('');
  useEffect(() => setTitle(clip?.title ?? ''), [clip]);
  return (
    <Modal open={!!clip} onClose={onClose} title="Edit metadata" footer={<><Button variant="ghost" onClick={onClose}>Cancel</Button><Button variant="primary" onClick={async () => { await db.update('clips', clip!.id, { title: title.trim().slice(0, 140) || null }); toast('success', 'Saved'); onClose(); }}>Save</Button></>}>
      <Field label="Title" hint="Stored in Clipper. Twitch's own clip title is edited on Twitch."><Input value={title} maxLength={140} onChange={(e) => setTitle(e.target.value)} /></Field>
    </Modal>
  );
}
