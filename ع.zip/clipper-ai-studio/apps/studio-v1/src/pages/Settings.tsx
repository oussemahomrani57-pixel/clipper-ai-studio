import { useEffect, useRef, useState, type ReactNode } from 'react';
import { Badge, Button, Card, CardHeader, Field, Input, Notice, PageHeader, Segmented, Select, Switch } from '../components/ui.tsx';
import { Icon, type IconName } from '../components/Icon.tsx';
import { api } from '../lib/api.ts';
import { auth } from '../lib/auth.ts';
import { config, hasApi, hasCloud } from '../lib/config.ts';
import { buildDemo } from '../lib/demo.ts';
import { files } from '../lib/idb.ts';
import { navigate, useRoute } from '../lib/router.ts';
import { db, isDemoActive, toast, useStore } from '../lib/store.ts';
import { refreshSystem, useSystem } from '../lib/system.ts';
import { download } from '../lib/format.ts';

const SECTIONS: [string, string, IconName][] = [
  ['account', 'Account', 'shield'], ['twitch', 'Twitch', 'twitch'], ['clipping', 'Clipping', 'bolt'], ['video', 'Video', 'film'], ['subtitles', 'Subtitles', 'captions'],
  ['social', 'Social', 'send'], ['campaigns', 'Campaigns', 'target'], ['notifications', 'Notifications', 'bell'], ['security', 'Security', 'shield'], ['storage', 'Storage & data', 'database'], ['setup', 'Setup guide', 'info'],
];

function Section({ id, title, icon, children }: { id: string; title: string; icon: IconName; children: ReactNode }) {
  return <Card id={id} className="scroll-mt-24 min-w-0"><CardHeader title={title} icon={icon} /><div className="px-5 pb-5">{children}</div></Card>;
}

export default function Settings() {
  const { params } = useRoute();
  const s = useStore((st) => st.settings);
  const mode = useStore((st) => st.mode);
  const demo = useStore(isDemoActive);
  const sys = useSystem();
  const [email, setEmail] = useState('');
  const [sending, setSending] = useState(false);
  const [usage, setUsage] = useState<string>('…');
  const importRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const tw = params.get('twitch');
    if (!tw) return;
    const msg: Record<string, [string, 'success' | 'error']> = { connected: ['Twitch connected', 'success'], denied: ['Twitch authorization was cancelled', 'error'], expired: ['Authorization expired — try again', 'error'], invalid: ['Invalid authorization response', 'error'] };
    const [m, k] = msg[tw] ?? ['Twitch: ' + tw, 'error'];
    toast(k, m);
    void refreshSystem();
    history.replaceState(null, '', '#/settings');
  }, [params]);

  useEffect(() => { navigator.storage?.estimate?.().then((e) => setUsage(`${((e.usage ?? 0) / 1e6).toFixed(1)} MB used of ~${((e.quota ?? 0) / 1e9).toFixed(1)} GB available`)).catch(() => setUsage('unknown')); }, []);

  async function sendLink() {
    if (!/^\S+@\S+\.\S+$/.test(email)) return toast('error', 'Enter a valid email');
    setSending(true);
    try { await auth.sendMagicLink(email); toast('success', 'Check your inbox', 'Open the link on this device to sign in.'); }
    catch (e) { toast('error', 'Could not send link', (e as Error).message); }
    finally { setSending(false); }
  }

  async function connectTwitch() {
    try { const r = await api<{ url: string }>('/api/twitch/connect'); window.location.href = r.url; }
    catch (e) { toast('error', 'Cannot start Twitch login', (e as Error).message); }
  }

  async function disconnect(id: string) {
    if (!confirm('Disconnect this Twitch account? Its tokens are revoked and deleted.')) return;
    try { await api(`/api/twitch/accounts/${id}`, { method: 'DELETE' }); toast('success', 'Twitch disconnected'); await refreshSystem(); }
    catch (e) { toast('error', 'Disconnect failed', (e as Error).message); }
  }

  const notif = (k: string, label: string) => (
    <div className="flex items-center justify-between py-2.5"><span className="text-sm">{label}</span><Switch checked={s.notifications[k] !== false} onChange={(v) => db.saveSettings({ notifications: { ...s.notifications, [k]: v } })} /></div>
  );

  return (
    <div>
      <PageHeader title="Settings" subtitle="Accounts, connections, defaults and data." />
      <div className="flex gap-1.5 overflow-x-auto no-scrollbar pb-2 mb-4 -mx-1 px-1">
        {SECTIONS.map(([id, label]) => <button key={id} onClick={() => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })} className="shrink-0 px-3 h-9 rounded-xl text-sm bg-white/[.03] border border-white/5 text-muted hover:text-text">{label}</button>)}
      </div>

      <div className="grid grid-cols-1 gap-4 max-w-4xl min-w-0 break-words">
        <Section id="account" title="Account" icon="shield">
          <div className="flex flex-wrap items-center gap-2 mb-4"><span className="text-sm text-muted">Mode:</span><Badge tone={mode === 'cloud' ? 'green' : 'amber'}>{mode === 'cloud' ? 'Cloud · synced' : 'Local · this device only'}</Badge>{auth.session && <span className="text-sm">{auth.session.user.email}</span>}</div>
          {!hasCloud ? (
            <Notice tone="info" title="Cloud account not configured in this build">Everything works locally. To sync across devices and enable Twitch + 24/7 clipping, set <code>VITE_SUPABASE_URL</code> and <code>VITE_SUPABASE_ANON_KEY</code> (free Supabase project) — see the setup guide below.</Notice>
          ) : auth.session ? (
            <div className="flex flex-wrap gap-2">
              {mode === 'local' ? <Button variant="primary" onClick={() => db.setMode('cloud')}>Switch to cloud data</Button> : <Button onClick={() => db.setMode('local')}>Use local data</Button>}
              <Button variant="ghost" icon="logout" onClick={async () => { await auth.signOut(); db.setMode('local'); void refreshSystem(); toast('info', 'Signed out'); }}>Sign out</Button>
            </div>
          ) : (
            <div className="flex flex-col sm:flex-row gap-2">
              <Input type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@email.com" />
              <Button variant="primary" loading={sending} onClick={sendLink}>Email me a sign-in link</Button>
            </div>
          )}
          {mode === 'local' && auth.session && <p className="text-xs text-muted mt-3">Local data isn't uploaded automatically. Export it below if you want a backup.</p>}
        </Section>

        <Section id="twitch" title="Twitch connections" icon="twitch">
          {sys.api !== 'online' ? (
            <Notice tone="warn" title={sys.api === 'misconfigured' ? `Backend is missing secrets: ${sys.apiMissing.join(', ')}` : sys.api === 'offline' ? 'Backend unreachable' : 'Backend API not configured'}>Twitch login is handled by the API Worker so your client secret and tokens never touch the browser. {!hasApi && <>Set <code>VITE_API_URL</code> after deploying it.</>}</Notice>
          ) : mode !== 'cloud' ? <Notice tone="info" title="Sign in to your cloud account first" /> : (
            <div className="space-y-3">
              {sys.twitch.map((a) => (
                <div key={a.id} className="flex items-center gap-3 p-3 rounded-xl bg-white/[.03] border border-white/5">
                  <img src={a.profile_image_url} alt="" className="size-10 rounded-xl" />
                  <div className="flex-1 min-w-0"><div className="font-medium text-sm">{a.display_name}</div><div className="text-xs text-muted truncate">Scopes: {a.scopes.join(', ')}</div>{a.last_error && <div className="text-xs text-red">{a.last_error}</div>}</div>
                  <Badge tone={a.status === 'active' ? 'green' : 'red'}>{a.status}</Badge>
                  {a.status !== 'active' && <Button size="sm" variant="primary" onClick={connectTwitch}>Reconnect</Button>}
                  <Button size="sm" variant="ghost" icon="logout" onClick={() => disconnect(a.id)} aria-label="Disconnect" />
                </div>
              ))}
              <Button variant="primary" icon="twitch" onClick={connectTwitch}>{sys.twitch.length ? 'Connect another account' : 'Connect Twitch'}</Button>
              <p className="text-xs text-muted">Requested scopes (minimum): <code>clips:edit</code> to create clips, <code>user:read:chat</code> so the Engine can read chat via EventSub.</p>
            </div>
          )}
        </Section>

        <Section id="clipping" title="Streamers & auto clipping" icon="bolt">
          <div className="flex flex-wrap gap-2"><Button icon="users" onClick={() => navigate('streamers')}>Manage streamers</Button><Button icon="bolt" onClick={() => navigate('auto')}>Detection, cooldowns & limits</Button></div>
          <p className="text-sm text-muted mt-3">Current: score ≥ {s.detector.minScore}, cooldown {s.detector.cooldownSec}s, {s.detector.maxPerHour}/h, {s.detector.maxPerDay}/day, sensitivity {s.detector.sensitivity}.</p>
        </Section>

        <Section id="video" title="Video defaults" icon="film">
          <div className="grid sm:grid-cols-3 gap-4">
            <Field label="Export preset"><Select value={s.video.preset} onChange={(v) => db.saveSettings({ video: { ...s.video, preset: v } })} options={[{ value: '1080x1920', label: '1080 × 1920' }, { value: '720x1280', label: '720 × 1280' }]} /></Field>
            <Field label="Background"><Select value={s.video.background} onChange={(v) => db.saveSettings({ video: { ...s.video, background: v } })} options={[{ value: 'blur', label: 'Blurred' }, { value: 'black', label: 'Black' }, { value: 'gradient', label: 'Gradient' }]} /></Field>
            <Field label="Overlay font"><Select value={s.video.font} onChange={(v) => db.saveSettings({ video: { ...s.video, font: v } })} options={['Inter', 'Space Grotesk', 'Impact', 'Arial Black'].map((f) => ({ value: f, label: f }))} /></Field>
          </div>
        </Section>

        <Section id="subtitles" title="Subtitles" icon="captions">
          <Field label="Transcription provider" hint="Runs on the Engine. whisper.cpp is free (CPU, slower). OpenAI is paid per minute — only used if you set OPENAI_API_KEY on the Engine.">
            <Segmented value={s.subtitles.provider} onChange={(v) => db.saveSettings({ subtitles: { ...s.subtitles, provider: v } })} options={[{ value: 'manual', label: 'Manual only' }, { value: 'whisper_cpp', label: 'whisper.cpp (free)' }, { value: 'openai', label: 'OpenAI (paid)' }]} />
          </Field>
        </Section>

        <Section id="social" title="Social accounts" icon="send">
          <p className="text-sm text-muted">TikTok, Instagram and YouTube API connections are <b>planned</b> — each needs a developer app and platform review. Today the Publisher prepares posts, shares the MP4 via the iOS share sheet and tracks confirmed URLs.</p>
          <Button className="mt-3" icon="send" onClick={() => navigate('publisher')}>Open publisher</Button>
        </Section>

        <Section id="campaigns" title="Campaign settings" icon="target">
          <Field label="Default currency for totals"><Input value={s.currency} maxLength={3} onChange={(e) => db.saveSettings({ currency: e.target.value.toUpperCase() })} className="!w-28" /></Field>
        </Section>

        <Section id="notifications" title="In-app notifications" icon="bell">
          <div className="divide-y divide-white/5">
            {notif('streamer', 'Streamer goes live')}{notif('moment', 'Interesting moment detected')}{notif('clip_created', 'Clip created')}{notif('clip_failed', 'Clip creation failed')}{notif('render', 'Video processing completed')}{notif('publish', 'Publishing completed / failed')}{notif('connection', 'Connection expired')}
          </div>
          <p className="text-xs text-muted mt-2">Push / email / Discord notifications are prepared as future integrations.</p>
        </Section>

        <Section id="security" title="Security" icon="shield">
          <ul className="text-sm text-muted space-y-1.5">
            <li>• Twitch client secret and tokens live only on the Worker/Engine. Tokens are AES-256-GCM encrypted in the database and invisible to the browser (no RLS policy).</li>
            <li>• Every table uses Row Level Security: you can only read your own rows.</li>
            <li>• OAuth uses a signed, expiring <code>state</code> to prevent login CSRF.</li>
            <li>• This browser holds only your public Supabase key and your session.</li>
          </ul>
        </Section>

        <Section id="storage" title="Storage & data" icon="database">
          <p className="text-sm text-muted mb-3">This device: {usage}.</p>
          <div className="flex flex-wrap gap-2">
            <Button icon="download" onClick={() => download(`clipper-backup-${new Date().toISOString().slice(0, 10)}.json`, db.exportAll())}>Export all data</Button>
            {mode === 'local' && <>
              <input ref={importRef} type="file" accept="application/json" className="hidden" onChange={async (e) => { const f = e.target.files?.[0]; if (!f) return; try { db.importLocal(await f.text()); toast('success', 'Data imported'); } catch (err) { toast('error', 'Import failed', (err as Error).message); } }} />
              <Button icon="upload" onClick={() => importRef.current?.click()}>Import backup</Button>
              {!demo ? <Button icon="layers" onClick={() => { db.loadDemo(buildDemo()); toast('info', 'DEMO DATA loaded'); }}>Load DEMO DATA</Button> : <Button variant="secondary" onClick={() => { db.removeDemo(); toast('success', 'Demo data removed'); }}>Remove DEMO DATA</Button>}
              <Button variant="danger" icon="trash" onClick={async () => { if (!confirm('Erase all local data and stored videos on this device?')) return; db.clearLocal(); await files.clear(); toast('success', 'Local data erased'); }}>Erase local data</Button>
            </>}
          </div>
        </Section>

        <Section id="setup" title="Setup guide" icon="info">
          <ol className="text-sm space-y-3 list-decimal pl-5">
            <li><b>Supabase (free):</b> create a project → SQL editor → run <code>supabase/migrations/0001_init.sql</code>. Auth → URL configuration → add your site URL. Copy the Project URL and <i>anon</i> key into <code>VITE_SUPABASE_URL</code> / <code>VITE_SUPABASE_ANON_KEY</code>.</li>
            <li><b>Twitch app (free):</b> dev.twitch.tv/console → Register application → OAuth redirect URL = <code>https://&lt;your-worker&gt;.workers.dev/api/twitch/callback</code> → copy Client ID, create a Client Secret.</li>
            <li><b>API Worker (Cloudflare free):</b> deploy <code>apps/worker</code>, set secrets <code>TWITCH_CLIENT_SECRET</code>, <code>SUPABASE_SERVICE_ROLE_KEY</code>, <code>TOKEN_ENCRYPTION_KEY</code>, <code>OAUTH_STATE_SECRET</code>. Put its URL in <code>VITE_API_URL</code>.</li>
            <li><b>Engine (24/7):</b> run <code>apps/engine</code> (Docker) on an always-on machine — free tier VM or ~€4/month VPS. Same secrets as the Worker.</li>
          </ol>
          <div className="mt-4 rounded-xl bg-black/30 border border-white/5 p-3 font-mono text-xs text-muted space-y-1 break-all">
            <div>VITE_SUPABASE_URL = {config.supabaseUrl || <span className="text-amber">not set</span>}</div>
            <div>VITE_SUPABASE_ANON_KEY = {config.supabaseAnonKey ? '••• set' : <span className="text-amber">not set</span>}</div>
            <div>VITE_API_URL = {config.apiUrl || <span className="text-amber">not set</span>}</div>
            <div>API health = {sys.api}{sys.apiMissing.length ? ` (missing ${sys.apiMissing.join(', ')})` : ''}</div>
          </div>
          <Button size="sm" className="mt-3" icon="refresh" onClick={() => refreshSystem().then(() => toast('success', 'Status refreshed'))}>Re-check connections</Button>
        </Section>
      </div>
      <div className="h-6" /><div className="text-center text-xs text-muted"><Icon name="sparkles" size={12} className="inline" /> Clipper AI Studio · ONE PLATFORM. MULTIPLE STREAMERS. AUTOMATIC VIRAL CLIPS.</div>
    </div>
  );
}
