import { AnimatePresence, motion } from 'framer-motion';
import { useEffect, useState } from 'react';
import { estimateCampaign, estimateSubmission } from '@shared/earnings.ts';
import { Badge, Button, Card, EmptyState, Field, Input, Modal, Notice, PageHeader, Progress, Select } from '../components/ui.tsx';
import { Icon } from '../components/Icon.tsx';
import { db, getState, toast, useStore } from '../lib/store.ts';
import { cx, fmtMoney, fmtNum } from '../lib/format.ts';
import type { Campaign, Submission } from '../lib/types.ts';

const PLAT = ['tiktok', 'instagram', 'youtube'] as const;
const num = (s: string) => (s.trim() === '' ? null : Number.isFinite(Number(s)) && Number(s) >= 0 ? Number(s) : NaN);

export default function Campaigns() {
  const campaigns = useStore((s) => s.tables.campaigns);
  const subs = useStore((s) => s.tables.campaign_submissions);
  const [edit, setEdit] = useState<Partial<Campaign> | null>(null);
  const [subFor, setSubFor] = useState<{ campaign: Campaign; sub?: Submission } | null>(null);
  const [open, setOpen] = useState<string | null>(null);

  return (
    <div>
      <PageHeader title="Campaign Manager" subtitle="Track content-rewards campaigns (e.g. Whop) — terms, submissions, estimated vs confirmed earnings." actions={<Button variant="primary" icon="plus" onClick={() => setEdit({ platforms: ['tiktok'], currency: 'USD', status: 'active' })}>New campaign</Button>} />
      <Notice tone="info" title="Manual entry, by design">Copy terms exactly as the campaign states them. Clipper never scrapes campaign sites, never invents CPM rates, and values each post separately — views on different platforms are not combined or paid twice unless the campaign says so.</Notice>

      {campaigns.length === 0 ? <Card className="mt-5"><EmptyState icon="target" title="No campaigns yet" action={<Button variant="primary" icon="plus" onClick={() => setEdit({ platforms: ['tiktok'], currency: 'USD', status: 'active' })}>Add campaign</Button>}>Add a campaign you've joined to start tracking submissions and payouts.</EmptyState></Card> : (
        <div className="mt-5 space-y-3">
          {campaigns.map((c) => {
            const cs = subs.filter((s) => s.campaign_id === c.id);
            const e = estimateCampaign(c, cs);
            const isOpen = open === c.id;
            return (
              <Card key={c.id} className="overflow-hidden">
                <button className="w-full text-left p-4 sm:p-5" onClick={() => setOpen(isOpen ? null : c.id)}>
                  <div className="flex items-start gap-3">
                    <div className="grid place-items-center size-11 rounded-xl bg-gradient-to-br from-purple/30 to-blue/20 text-[#b3a2ff] shrink-0"><Icon name="target" /></div>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2"><span className="font-semibold">{c.name}</span><Badge tone={c.status === 'active' ? 'green' : c.status === 'paused' ? 'amber' : 'muted'}>{c.status}</Badge>{c.is_demo && <Badge tone="amber">Demo</Badge>}</div>
                      <div className="text-xs text-muted mt-1">{c.cpm != null ? `${fmtMoney(c.cpm, c.currency)} CPM` : 'CPM not set'} · max {c.max_payout != null ? fmtMoney(c.max_payout, c.currency) : '—'} · {c.platforms.join(', ')} · {cs.length} submission(s)</div>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="text-xs text-muted">Confirmed</div>
                      <div className="font-display font-semibold text-green">{fmtMoney(e.confirmed, c.currency)}</div>
                      <div className="text-[11px] text-muted">est. {fmtMoney(e.estimated, c.currency)}</div>
                    </div>
                  </div>
                  {c.max_payout != null && <Progress className="mt-4" value={(e.estimated / Math.max(1, c.max_payout)) * 100} />}
                </button>
                <AnimatePresence>
                  {isOpen && (
                    <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden border-t border-white/5">
                      <div className="p-4 sm:p-5 space-y-4">
                        {c.requirements && <div className="text-sm"><div className="text-xs text-muted mb-1">Submission requirements</div><p className="whitespace-pre-wrap">{c.requirements}</p></div>}
                        {e.capped && <Notice tone="warn" title="Estimate capped at the campaign maximum payout" />}
                        <div className="flex flex-wrap gap-2">
                          <Button size="sm" variant="primary" icon="plus" onClick={() => setSubFor({ campaign: c })}>Add submission</Button>
                          <Button size="sm" icon="edit" onClick={() => setEdit(c)}>Edit terms</Button>
                          {c.url && <Button size="sm" variant="ghost" icon="external" onClick={() => window.open(c.url!, '_blank', 'noopener')}>Campaign page</Button>}
                          <Button size="sm" variant="ghost" icon="trash" className="ml-auto" onClick={() => { if (confirm('Delete campaign and its submissions?')) void db.remove('campaigns', c.id).then(() => cs.forEach((s) => void db.remove('campaign_submissions', s.id))); }}>Delete</Button>
                        </div>
                        <div className="divide-y divide-white/5">
                          {cs.map((s) => (
                            <button key={s.id} onClick={() => setSubFor({ campaign: c, sub: s })} className="w-full py-3 flex items-center gap-3 text-left">
                              <Badge>{s.platform}</Badge>
                              <span className="text-sm truncate flex-1">{s.post_url}</span>
                              <span className="text-xs text-muted tabular-nums">{fmtNum(s.eligible_views)} views</span>
                              <span className="text-sm tabular-nums w-24 text-right">{s.confirmed_earnings != null ? <span className="text-green">{fmtMoney(s.confirmed_earnings, c.currency)}</span> : <span className="text-muted">≈{fmtMoney(estimateSubmission(c, s), c.currency)}</span>}</span>
                              <Badge tone={s.status === 'paid' ? 'green' : s.status === 'rejected' ? 'red' : s.status === 'approved' ? 'blue' : 'muted'}>{s.status}</Badge>
                            </button>
                          ))}
                          {!cs.length && <p className="text-sm text-muted py-2">No submissions yet.</p>}
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </Card>
            );
          })}
        </div>
      )}
      <CampaignModal value={edit} onClose={() => setEdit(null)} />
      <SubmissionModal ctx={subFor} onClose={() => setSubFor(null)} />
    </div>
  );
}

function CampaignModal({ value, onClose }: { value: Partial<Campaign> | null; onClose: () => void }) {
  const [f, setF] = useState<Record<string, string>>({});
  const [plats, setPlats] = useState<string[]>([]);
  const [status, setStatus] = useState<Campaign['status']>('active');
  useEffect(() => {
    if (!value) return;
    setF({ name: value.name ?? '', url: value.url ?? '', cpm: value.cpm?.toString() ?? '', currency: value.currency ?? 'USD', max: value.max_payout?.toString() ?? '', maxSub: value.max_payout_per_submission?.toString() ?? '', min: value.min_views?.toString() ?? '', req: value.requirements ?? '' });
    setPlats(value.platforms ?? []); setStatus(value.status ?? 'active');
  }, [value]);
  if (!value) return null;
  const set = (k: string) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });
  async function save() {
    if (!f.name.trim()) return toast('error', 'Name is required');
    if (f.url && !/^https?:\/\//i.test(f.url)) return toast('error', 'URL must start with https://');
    const cpm = num(f.cpm); const max = num(f.max); const maxSub = num(f.maxSub); const min = num(f.min);
    if ([cpm, max, maxSub, min].some((x) => Number.isNaN(x))) return toast('error', 'Numbers must be positive');
    const row = { name: f.name.trim().slice(0, 120), url: f.url || null, cpm, currency: f.currency.toUpperCase().slice(0, 3) || 'USD', max_payout: max, max_payout_per_submission: maxSub, min_views: min, requirements: f.req || null, platforms: plats, status, notes: null };
    try {
      if (value!.id) await db.update('campaigns', value!.id, row); else await db.insert('campaigns', row);
      toast('success', 'Campaign saved'); onClose();
    } catch (e) { toast('error', 'Save failed', (e as Error).message); }
  }
  return (
    <Modal open onClose={onClose} title={value.id ? 'Edit campaign' : 'New campaign'} footer={<><Button variant="ghost" onClick={onClose}>Cancel</Button><Button variant="primary" onClick={save}>Save</Button></>}>
      <div className="space-y-4">
        <Field label="Campaign name"><Input value={f.name} onChange={set('name')} /></Field>
        <Field label="Campaign URL"><Input value={f.url} onChange={set('url')} placeholder="https://whop.com/…" inputMode="url" /></Field>
        <div><div className="text-[13px] font-medium mb-2">Accepted platforms</div><div className="flex gap-2">{PLAT.map((p) => <button key={p} onClick={() => setPlats(plats.includes(p) ? plats.filter((x) => x !== p) : [...plats, p])} className={cx('px-3 h-9 rounded-xl border text-sm capitalize', plats.includes(p) ? 'border-purple/50 bg-purple/15' : 'border-white/10 text-muted')}>{p}</button>)}</div></div>
        <div className="grid grid-cols-2 gap-3">
          <Field label="CPM (per 1,000 views)" hint="As stated by the campaign"><Input value={f.cpm} onChange={set('cpm')} inputMode="decimal" placeholder="e.g. 1.00" /></Field>
          <Field label="Currency"><Input value={f.currency} onChange={set('currency')} maxLength={3} /></Field>
          <Field label="Max payout (campaign)"><Input value={f.max} onChange={set('max')} inputMode="decimal" /></Field>
          <Field label="Max per submission"><Input value={f.maxSub} onChange={set('maxSub')} inputMode="decimal" placeholder="optional" /></Field>
          <Field label="Minimum views" className="col-span-2"><Input value={f.min} onChange={set('min')} inputMode="numeric" placeholder="optional" /></Field>
        </div>
        <Field label="Submission requirements"><textarea value={f.req} onChange={set('req')} rows={3} className="field" /></Field>
        <Field label="Status"><Select value={status} onChange={setStatus} options={[{ value: 'active', label: 'Active' }, { value: 'paused', label: 'Paused' }, { value: 'ended', label: 'Ended' }]} /></Field>
      </div>
    </Modal>
  );
}

function SubmissionModal({ ctx, onClose }: { ctx: { campaign: Campaign; sub?: Submission } | null; onClose: () => void }) {
  const [f, setF] = useState({ platform: 'tiktok', url: '', views: '', status: 'submitted', confirmed: '' });
  useEffect(() => { const s = ctx?.sub; setF({ platform: s?.platform ?? ctx?.campaign.platforms[0] ?? 'tiktok', url: s?.post_url ?? '', views: s?.eligible_views?.toString() ?? '', status: s?.status ?? 'submitted', confirmed: s?.confirmed_earnings?.toString() ?? '' }); }, [ctx]);
  if (!ctx) return null;
  const c = ctx.campaign;
  const est = estimateSubmission(c, { eligible_views: num(f.views) ?? null, confirmed_earnings: null });
  async function save() {
    try { const u = new URL(f.url); if (!/^https?:$/.test(u.protocol)) throw new Error(); } catch { return toast('error', 'Enter a valid post URL'); }
    const views = num(f.views); const confirmed = num(f.confirmed);
    if (Number.isNaN(views) || Number.isNaN(confirmed)) return toast('error', 'Numbers must be positive');
    const row = { campaign_id: c.id, platform: f.platform as Submission['platform'], post_url: f.url, eligible_views: views, status: f.status as Submission['status'], confirmed_earnings: confirmed, post_id: null };
    try {
      if (ctx!.sub) await db.update('campaign_submissions', ctx!.sub.id, row);
      else {
        if (isDuplicate(c.id, f.url)) return toast('error', 'This URL is already submitted to this campaign');
        await db.insert('campaign_submissions', row);
      }
      toast('success', 'Submission saved'); onClose();
    } catch (e) { toast('error', 'Save failed', (e as Error).message); }
  }
  return (
    <Modal open onClose={onClose} title={ctx.sub ? 'Edit submission' : 'Add submission'} footer={<>{ctx.sub && <Button variant="danger" className="mr-auto" icon="trash" onClick={() => db.remove('campaign_submissions', ctx.sub!.id).then(onClose)}>Delete</Button>}<Button variant="ghost" onClick={onClose}>Cancel</Button><Button variant="primary" onClick={save}>Save</Button></>}>
      <div className="space-y-4">
        <Field label="Platform"><Select value={f.platform} onChange={(v) => setF({ ...f, platform: v })} options={[...PLAT, 'other'].map((p) => ({ value: p, label: p }))} /></Field>
        <Field label="Post URL"><Input value={f.url} onChange={(e) => setF({ ...f, url: e.target.value })} inputMode="url" placeholder="https://" /></Field>
        <Field label="Eligible views" hint="Views the campaign counts for this post (from its dashboard)."><Input value={f.views} onChange={(e) => setF({ ...f, views: e.target.value })} inputMode="numeric" /></Field>
        <div className="rounded-xl bg-white/[.03] border border-white/5 p-3 text-sm flex justify-between"><span className="text-muted">Estimated (not guaranteed)</span><span className="tabular-nums">{c.cpm == null ? 'Set CPM first' : fmtMoney(est, c.currency)}</span></div>
        <Field label="Status"><Select value={f.status} onChange={(v) => setF({ ...f, status: v })} options={['submitted', 'approved', 'rejected', 'paid'].map((s) => ({ value: s, label: s }))} /></Field>
        <Field label="Confirmed earnings" hint="Only enter what the campaign actually approved/paid."><Input value={f.confirmed} onChange={(e) => setF({ ...f, confirmed: e.target.value })} inputMode="decimal" /></Field>
      </div>
    </Modal>
  );
}

function isDuplicate(campaignId: string, url: string) {
  return getState().tables.campaign_submissions.some((s) => s.campaign_id === campaignId && s.post_url === url);
}
