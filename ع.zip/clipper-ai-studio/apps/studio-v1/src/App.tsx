import { MotionConfig } from 'framer-motion';
import { lazy, Suspense, useEffect, type ComponentType } from 'react';
import { Shell } from './components/Shell.tsx';
import { useRoute, type RouteId } from './lib/router.ts';
import { auth } from './lib/auth.ts';
import { db, useStore } from './lib/store.ts';
import { refreshSystem } from './lib/system.ts';
import Dashboard from './pages/Dashboard.tsx';

// Heavier pages load on demand (faster first paint on iPhone).
const pages: Record<RouteId, ComponentType> = {
  dashboard: Dashboard,
  monitor: lazy(() => import('./pages/LiveMonitor.tsx')),
  manual: lazy(() => import('./pages/ManualClipper.tsx')),
  auto: lazy(() => import('./pages/AutoClipper.tsx')),
  streamers: lazy(() => import('./pages/Streamers.tsx')),
  library: lazy(() => import('./pages/Library.tsx')),
  editor: lazy(() => import('./pages/VideoEditor.tsx')),
  subtitles: lazy(() => import('./pages/Subtitles.tsx')),
  publisher: lazy(() => import('./pages/Publisher.tsx')),
  campaigns: lazy(() => import('./pages/Campaigns.tsx')),
  analytics: lazy(() => import('./pages/Analytics.tsx')),
  settings: lazy(() => import('./pages/Settings.tsx')),
};

function Loading() {
  return (
    <div className="space-y-4">
      <div className="skeleton h-9 w-56 rounded-xl" />
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">{Array.from({ length: 4 }, (_, i) => <div key={i} className="skeleton h-28 rounded-2xl" />)}</div>
      <div className="skeleton h-72 rounded-2xl" />
    </div>
  );
}

export default function App() {
  const { route } = useRoute();
  const reduce = useStore((s) => s.settings.reduce_motion);
  const loading = useStore((s) => s.loading);
  useEffect(() => {
    (async () => {
      if (await auth.consumeRedirect()) db.setMode('cloud');
      else await db.boot();
      await refreshSystem();
    })();
    const t = setInterval(() => void refreshSystem(), 60_000);
    return () => clearInterval(t);
  }, []);
  const Page = pages[route];
  return (
    <MotionConfig reducedMotion={reduce ? 'always' : 'user'}>
      <Shell>
        <Suspense fallback={<Loading />}>{loading ? <Loading /> : <Page />}</Suspense>
      </Shell>
    </MotionConfig>
  );
}
