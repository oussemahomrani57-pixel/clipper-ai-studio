import { AnimatePresence, motion } from 'framer-motion';
import { useEffect, useRef, useState, type ReactNode, type ButtonHTMLAttributes, type InputHTMLAttributes, type HTMLAttributes } from 'react';
import { Icon, type IconName } from './Icon.tsx';
import { cx } from '../lib/format.ts';

// ───────────────────────── Button
type Variant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'success';
const VARIANTS: Record<Variant, string> = {
  primary: 'btn-glow text-white',
  secondary: 'bg-white/[.06] hover:bg-white/[.1] border border-white/10 text-text',
  ghost: 'hover:bg-white/[.06] text-muted hover:text-text',
  danger: 'bg-red/15 hover:bg-red/25 text-red border border-red/30',
  success: 'bg-green/15 hover:bg-green/25 text-green border border-green/30',
};

export function Button({ variant = 'secondary', icon, loading, size = 'md', className, children, ...rest }:
  ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant; icon?: IconName; loading?: boolean; size?: 'sm' | 'md' | 'lg' }) {
  return (
    <button
      {...rest}
      disabled={rest.disabled || loading}
      className={cx(
        'inline-flex items-center justify-center gap-2 rounded-xl font-medium transition-all duration-200 active:scale-[.97] disabled:opacity-45 disabled:pointer-events-none select-none whitespace-nowrap',
        size === 'sm' ? 'h-9 px-3 text-[13px]' : size === 'lg' ? 'h-14 px-7 text-base' : 'h-11 px-4 text-sm',
        VARIANTS[variant], className,
      )}
    >
      {loading ? <Spinner /> : icon ? <Icon name={icon} size={size === 'sm' ? 15 : 17} /> : null}
      {children}
    </button>
  );
}

export const Spinner = ({ size = 16 }: { size?: number }) => (
  <span className="inline-block rounded-full border-2 border-white/25 border-t-white animate-spin-slow" style={{ width: size, height: size }} />
);

// ───────────────────────── Card
export function Card({ children, className, hover, ...rest }: { children: ReactNode; className?: string; hover?: boolean } & HTMLAttributes<HTMLDivElement>) {
  return <div {...rest} className={cx('glass rounded-2xl', hover && 'glass-hover', className)}>{children}</div>;
}

export function CardHeader({ title, subtitle, icon, action }: { title: ReactNode; subtitle?: ReactNode; icon?: IconName; action?: ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-3 px-5 pt-5 pb-3">
      <div className="flex items-center gap-3 min-w-0">
        {icon && <div className="grid place-items-center size-9 shrink-0 rounded-xl bg-purple/15 text-purple"><Icon name={icon} size={17} /></div>}
        <div className="min-w-0">
          <h3 className="font-display font-semibold text-[15px] leading-tight truncate">{title}</h3>
          {subtitle && <p className="text-[13px] text-muted mt-0.5">{subtitle}</p>}
        </div>
      </div>
      {action}
    </div>
  );
}

// ───────────────────────── Badge / status
type Tone = 'purple' | 'blue' | 'green' | 'amber' | 'red' | 'muted';
const TONES: Record<Tone, string> = {
  purple: 'bg-purple/15 text-[#b3a2ff] border-purple/25',
  blue: 'bg-blue/15 text-blue border-blue/25',
  green: 'bg-green/12 text-green border-green/25',
  amber: 'bg-amber/12 text-amber border-amber/25',
  red: 'bg-red/12 text-red border-red/25',
  muted: 'bg-white/[.05] text-muted border-white/10',
};
export function Badge({ tone = 'muted', children, dot, className }: { tone?: Tone; children: ReactNode; dot?: boolean; className?: string }) {
  return (
    <span className={cx('inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide', TONES[tone], className)}>
      {dot && <span className="size-1.5 rounded-full bg-current animate-pulse-soft" />}
      {children}
    </span>
  );
}

export const DemoBadge = () => <Badge tone="amber">Demo data</Badge>;

export function LiveDot({ live }: { live: boolean | null }) {
  if (live === null) return <span className="size-2 rounded-full bg-muted/40" title="Unknown" />;
  return (
    <span className="relative inline-flex size-2.5">
      {live && <span className="absolute inset-0 rounded-full bg-red animate-ping opacity-60" />}
      <span className={cx('relative inline-flex size-2.5 rounded-full', live ? 'bg-red' : 'bg-muted/50')} />
    </span>
  );
}

// ───────────────────────── Notice (honest status callouts)
export function Notice({ tone = 'info', title, children, action, icon }: { tone?: 'info' | 'warn' | 'error' | 'success'; title: ReactNode; children?: ReactNode; action?: ReactNode; icon?: IconName }) {
  const map = { info: ['border-blue/25 bg-blue/[.06]', 'text-blue', 'info'], warn: ['border-amber/25 bg-amber/[.06]', 'text-amber', 'alert'], error: ['border-red/25 bg-red/[.06]', 'text-red', 'alert'], success: ['border-green/25 bg-green/[.06]', 'text-green', 'check'] } as const;
  const [box, color, ic] = map[tone];
  return (
    <div className={cx('rounded-2xl border p-4 flex gap-3', box)}>
      <Icon name={icon ?? (ic as IconName)} size={18} className={cx('shrink-0 mt-0.5', color)} />
      <div className="flex-1 min-w-0 text-sm">
        <div className="font-semibold">{title}</div>
        {children && <div className="text-muted mt-1 leading-relaxed">{children}</div>}
        {action && <div className="mt-3 flex flex-wrap gap-2">{action}</div>}
      </div>
    </div>
  );
}

// ───────────────────────── Form controls
export function Field({ label, hint, children, className }: { label: ReactNode; hint?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <label className={cx('block', className)}>
      <span className="block text-[13px] font-medium text-text/90 mb-1.5">{label}</span>
      {children}
      {hint && <span className="block text-xs text-muted mt-1.5">{hint}</span>}
    </label>
  );
}

export const Input = (p: InputHTMLAttributes<HTMLInputElement>) => <input {...p} className={cx('field', p.className)} />;

export function Select<T extends string>({ value, onChange, options, className }: { value: T; onChange: (v: T) => void; options: { value: T; label: string }[]; className?: string }) {
  return (
    <div className={cx('relative', className)}>
      <select value={value} onChange={(e) => onChange(e.target.value as T)} className="field appearance-none pr-9">
        {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
      <Icon name="chevronDown" size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted pointer-events-none" />
    </div>
  );
}

export function Switch({ checked, onChange, label, disabled }: { checked: boolean; onChange: (v: boolean) => void; label?: string; disabled?: boolean }) {
  return (
    <button type="button" role="switch" aria-checked={checked} aria-label={label} disabled={disabled} onClick={() => onChange(!checked)}
      className={cx('relative inline-flex h-7 w-12 shrink-0 items-center rounded-full transition-colors duration-300 disabled:opacity-40', checked ? 'bg-gradient-to-r from-purple to-blue shadow-[0_0_16px_rgb(120_87_255/.55)]' : 'bg-white/10')}>
      <motion.span layout transition={{ type: 'spring', stiffness: 500, damping: 32 }} className={cx('inline-block size-5 rounded-full bg-white shadow', checked ? 'ml-6' : 'ml-1')} />
    </button>
  );
}

export function Slider({ value, min, max, step = 1, onChange, suffix = '' }: { value: number; min: number; max: number; step?: number; onChange: (v: number) => void; suffix?: string }) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div className="flex items-center gap-3">
      <input type="range" className="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))}
        style={{ background: `linear-gradient(90deg, #7857ff ${pct}%, #252a42 ${pct}%)` }} />
      <span className="font-mono text-sm w-16 text-right tabular-nums">{value}{suffix}</span>
    </div>
  );
}

export function Segmented<T extends string>({ value, onChange, options }: { value: T; onChange: (v: T) => void; options: { value: T; label: string }[] }) {
  return (
    <div className="inline-flex p-1 rounded-xl bg-black/30 border border-white/5 overflow-x-auto no-scrollbar max-w-full">
      {options.map((o) => (
        <button key={o.value} type="button" onClick={() => onChange(o.value)} className={cx('relative px-3.5 h-8 text-[13px] font-medium rounded-lg whitespace-nowrap transition-colors', value === o.value ? 'text-white' : 'text-muted hover:text-text')}>
          {value === o.value && <motion.span layoutId={`seg-${options.map((x) => x.value).join()}`} className="absolute inset-0 rounded-lg bg-white/10 border border-white/10" transition={{ type: 'spring', stiffness: 500, damping: 38 }} />}
          <span className="relative">{o.label}</span>
        </button>
      ))}
    </div>
  );
}

// ───────────────────────── Modal / sheet (bottom sheet on mobile)
export function Modal({ open, onClose, title, children, footer, wide }: { open: boolean; onClose: () => void; title: ReactNode; children: ReactNode; footer?: ReactNode; wide?: boolean }) {
  useEffect(() => {
    if (!open) return;
    const k = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, [open, onClose]);
  return (
    <AnimatePresence>
      {open && (
        <motion.div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-6" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
          <motion.div role="dialog" aria-modal="true"
            initial={{ y: 40, opacity: 0, scale: 0.98 }} animate={{ y: 0, opacity: 1, scale: 1 }} exit={{ y: 40, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 380, damping: 34 }}
            className={cx('glass relative w-full max-h-[92dvh] overflow-hidden flex flex-col rounded-t-3xl sm:rounded-3xl safe-bottom', wide ? 'sm:max-w-3xl' : 'sm:max-w-lg')}>
            <div className="sm:hidden mx-auto mt-2.5 h-1 w-10 rounded-full bg-white/20" />
            <div className="flex items-center justify-between px-5 pt-4 pb-3 border-b border-white/5">
              <h3 className="font-display font-semibold text-lg">{title}</h3>
              <button onClick={onClose} className="size-9 grid place-items-center rounded-xl hover:bg-white/10 text-muted" aria-label="Close"><Icon name="x" /></button>
            </div>
            <div className="overflow-y-auto px-5 py-4 flex-1">{children}</div>
            {footer && <div className="px-5 py-4 border-t border-white/5 flex flex-wrap justify-end gap-2">{footer}</div>}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// ───────────────────────── Empty state / progress / stat
export function EmptyState({ icon, title, children, action }: { icon: IconName; title: string; children?: ReactNode; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center text-center px-6 py-12">
      <div className="relative mb-4">
        <div className="absolute inset-0 rounded-2xl bg-purple/30 blur-xl" />
        <div className="relative grid place-items-center size-14 rounded-2xl bg-gradient-to-br from-purple/25 to-blue/20 border border-white/10 text-[#b3a2ff]"><Icon name={icon} size={24} /></div>
      </div>
      <h4 className="font-display font-semibold">{title}</h4>
      {children && <p className="text-sm text-muted mt-1.5 max-w-sm leading-relaxed">{children}</p>}
      {action && <div className="mt-5 flex flex-wrap justify-center gap-2">{action}</div>}
    </div>
  );
}

export function Progress({ value, className, tone = 'brand' }: { value: number; className?: string; tone?: 'brand' | 'green' | 'red' }) {
  const bg = tone === 'green' ? 'bg-green' : tone === 'red' ? 'bg-red' : 'bg-gradient-to-r from-purple to-blue';
  return (
    <div className={cx('h-1.5 w-full rounded-full bg-white/[.07] overflow-hidden', className)}>
      <motion.div className={cx('h-full rounded-full', bg)} initial={{ width: 0 }} animate={{ width: `${Math.max(0, Math.min(100, value))}%` }} transition={{ type: 'spring', stiffness: 120, damping: 22 }} />
    </div>
  );
}

export function AnimatedNumber({ value, decimals = 0 }: { value: number; decimals?: number }) {
  const [shown, setShown] = useState(value);
  const from = useRef(value);
  useEffect(() => {
    const start = performance.now(); const a = from.current; const d = 700;
    let raf = 0;
    const step = (t: number) => {
      const k = Math.min(1, (t - start) / d); const e = 1 - Math.pow(1 - k, 3);
      setShown(a + (value - a) * e);
      if (k < 1) raf = requestAnimationFrame(step); else from.current = value;
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [value]);
  return <>{shown.toFixed(decimals)}</>;
}

export function Stat({ label, value, icon, tone = 'purple', sub, unknown }: { label: string; value: number; icon: IconName; tone?: 'purple' | 'blue' | 'green' | 'amber'; sub?: ReactNode; unknown?: boolean }) {
  const c = { purple: 'text-[#b3a2ff] bg-purple/15', blue: 'text-blue bg-blue/15', green: 'text-green bg-green/12', amber: 'text-amber bg-amber/12' }[tone];
  return (
    <Card hover className="p-4 sm:p-5">
      <div className="flex items-center justify-between">
        <span className="text-[12px] sm:text-[13px] text-muted font-medium">{label}</span>
        <span className={cx('grid place-items-center size-8 rounded-lg', c)}><Icon name={icon} size={16} /></span>
      </div>
      <div className="mt-3 font-display text-2xl sm:text-3xl font-semibold tabular-nums">{unknown ? <span className="text-muted">—</span> : <AnimatedNumber value={value} />}</div>
      {sub && <div className="text-xs text-muted mt-1">{sub}</div>}
    </Card>
  );
}

export function PageHeader({ title, subtitle, actions, badge }: { title: string; subtitle?: ReactNode; actions?: ReactNode; badge?: ReactNode }) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-6">
      <div>
        <div className="flex items-center gap-2 flex-wrap">
          <h1 className="font-display text-[26px] sm:text-3xl font-semibold tracking-tight">{title}</h1>
          {badge}
        </div>
        {subtitle && <p className="text-muted text-sm mt-1.5 max-w-2xl">{subtitle}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}

export function Waveform({ active = true, bars = 18, className }: { active?: boolean; bars?: number; className?: string }) {
  return (
    <div className={cx('flex items-end gap-[3px] h-6', className)} aria-hidden>
      {Array.from({ length: bars }, (_, i) => (
        <span key={i} className={cx('w-[3px] rounded-full bg-gradient-to-t from-purple to-blue', active ? 'wave-bar' : 'opacity-30')}
          style={{ height: `${30 + ((i * 37) % 70)}%`, animationDelay: `${(i * 83) % 900}ms` }} />
      ))}
    </div>
  );
}
