import { AnimatePresence, motion } from 'framer-motion';
import { useEffect, useState, type ReactNode } from 'react';
import { Icon, type IconName } from './Icon.tsx';
import { Badge, Button } from './ui.tsx';
import { navigate, useRoute, type RouteId } from '../lib/router.ts';
import { db, dismissToast, isDemoActive, useStore } from '../lib/store.ts';
import { cx, timeAgo } from '../lib/format.ts';

export const NAV: { id: RouteId; label: string; icon: IconName; group: string }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: 'dashboard', group: 'Overview' },
  { id: 'monitor', label: 'Live Monitor', icon: 'monitor', group: 'Overview' },
  { id: 'manual', label: 'Manual Clipper', icon: 'scissors', group: 'Clipping' },
  { id: 'auto', label: 'Auto Clipper', icon: 'bolt', group: 'Clipping' },
  { id: 'streamers', label: 'Streamers', icon: 'users', group: 'Clipping' },
  { id: 'library', label: 'Clip Library', icon: 'library', group: 'Studio' },
  { id: 'editor', label: 'Video Editor', icon: 'film', group: 'Studio' },
  { id: 'subtitles', label: 'Subtitles', icon: 'captions', group: 'Studio' },
  { id: 'publisher', label: 'Social Publisher', icon: 'send', group: 'Growth' },
  { id: 'campaigns', label: 'Campaigns', icon: 'target', group: 'Growth' },
  { id: 'analytics', label: 'Analytics', icon: 'chart', group: 'Growth' },
  { id: 'settings', label: 'Settings', icon: 'settings', group: 'System' },
];
const MOBILE_TABS: RouteId[] = ['dashboard', 'monitor', 'manual', 'library'];

export function Logo({ compact }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-2.5">
      <div className="relative size-9 rounded-xl bg-gradient-to-br from-purple to-blue grid place-items-center shadow-[0_0_24px_rgb(120_87_255/.55)]">
        <svg viewBox="0 0 24 24" className="size-5 text-white" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round"><path d="M8 5l10 7-10 7z" fill="currentColor" stroke="none" /><path d="M4 4v16" /></svg>
      </div>
      {!compact && <div className="leading-none"><div className="font-display font-bold tracking-tight text-[15px]">CLIPPER <span className="text-gradient">AI</span></div><div className="text-[10px] tracking-[.22em] text-muted mt-1">STUDIO</div></div>}
    </div>
  );
}

function NavItem({ item, active, onClick }: { item: (typeof NAV)[number]; active: boolean; onClick: () => void }) {
  return (
    <button onClick={onClick} className={cx('relative w-full flex items-center gap-3 px-3 h-10 rounded-xl text-sm font-medium transition-colors', active ? 'text-white' : 'text-muted hover:text-text hover:bg-white/[.04]')}>
      {active && <motion.span layoutId="nav-active" className="absolute inset-0 rounded-xl bg-gradient-to-r from-purple/25 to-blue/10 border border-purple/30" transition={{ type: 'spring', stiffness: 450, damping: 36 }} />}
      {active && <motion.span layoutId="nav-bar" className="absolute -left-3 top-2 bottom-2 w-1 rounded-r bg-gradient-to-b from-purple to-blue" />}
      <Icon name={item.icon} size={18} className="relative" />
      <span className="relative">{item.label}</span>
    </button>
  );
}

function Notifications({ onClose }: { onClose: () => void }) {
  const items = useStore((s) => s.tables.notifications);
  const unread = items.filter((n) => !n.read_at);
  return (
    <motion.div initial={{ opacity: 0, y: -8, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -8 }}
      className="glass absolute right-0 top-12 z-40 w-[min(92vw,380px)] rounded-2xl overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3 border-b border-white/5">
        <span className="font-display font-semibold">Notifications</span>
        {unread.length > 0 && <button className="text-xs text-blue" onClick={() => unread.forEach((n) => void db.update('notifications', n.id, { read_at: new Date().toISOString() }))}>Mark all read</button>}
      </div>
      <div className="max-h-[60dvh] overflow-y-auto">
        {items.length === 0 && <div className="p-8 text-center text-sm text-muted">No notifications yet.</div>}
        <AnimatePresence initial={false}>
          {items.slice(0, 40).map((n) => (
            <motion.button layout key={n.id} initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0 }}
              onClick={() => { void db.update('notifications', n.id, { read_at: new Date().toISOString() }); if (n.link) { window.location.hash = n.link.replace(/^#/, ''); onClose(); } }}
              className="w-full text-left px-4 py-3 flex gap-3 hover:bg-white/[.03] border-b border-white/[.03]">
              <span className={cx('mt-1.5 size-2 rounded-full shrink-0', n.read_at ? 'bg-transparent' : 'bg-blue')} />
              <span className="min-w-0 flex-1">
                <span className="block text-sm font-medium">{n.title} {n.is_demo && <Badge tone="amber">Demo</Badge>}</span>
                {n.body && <span className="block text-xs text-muted mt-0.5 truncate">{n.body}</span>}
                <span className="block text-[11px] text-muted/70 mt-1">{timeAgo(n.created_at)}</span>
              </span>
            </motion.button>
          ))}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}

function Toasts() {
  const toasts = useStore((s) => s.toasts);
  return (
    <div className="fixed z-[60] top-3 inset-x-3 sm:inset-x-auto sm:right-5 sm:top-5 flex flex-col gap-2 sm:w-96 pointer-events-none">
      <AnimatePresence>
        {toasts.map((t) => (
          <motion.div key={t.id} layout initial={{ opacity: 0, y: -16, scale: 0.96 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, x: 40 }}
            className="glass pointer-events-auto rounded-2xl p-3.5 flex gap-3 items-start" onClick={() => dismissToast(t.id)}>
            <span className={cx('grid place-items-center size-7 rounded-lg shrink-0', t.kind === 'success' ? 'bg-green/15 text-green' : t.kind === 'error' ? 'bg-red/15 text-red' : 'bg-blue/15 text-blue')}>
              <Icon name={t.kind === 'success' ? 'check' : t.kind === 'error' ? 'alert' : 'info'} size={15} />
            </span>
            <div className="min-w-0 text-sm"><div className="font-semibold">{t.title}</div>{t.body && <div className="text-muted text-[13px] mt-0.5 break-words">{t.body}</div>}</div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}

export function Shell({ children }: { children: ReactNode }) {
  const { route } = useRoute();
  useEffect(() => { window.scrollTo({ top: 0 }); }, [route]);
  const [bell, setBell] = useState(false);
  const [more, setMore] = useState(false);
  const unread = useStore((s) => s.tables.notifications.filter((n) => !n.read_at).length);
  const mode = useStore((s) => s.mode);
  const demo = useStore(isDemoActive);
  const syncError = useStore((s) => s.syncError);
  const groups = [...new Set(NAV.map((n) => n.group))];
  const current = NAV.find((n) => n.id === route)!;

  return (
    <div className="bg-orbs relative min-h-dvh">
      <div className="fixed inset-0 grid-fade pointer-events-none" />
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex fixed inset-y-0 left-0 z-30 w-64 flex-col border-r border-white/5 bg-surface/70 backdrop-blur-xl">
        <div className="px-5 h-16 flex items-center"><Logo /></div>
        <nav className="flex-1 overflow-y-auto px-3 pb-4">
          {groups.map((g) => (
            <div key={g} className="mt-4">
              <div className="px-3 mb-1.5 text-[10px] font-semibold tracking-[.18em] text-muted/70 uppercase">{g}</div>
              <div className="space-y-0.5">{NAV.filter((n) => n.group === g).map((n) => <NavItem key={n.id} item={n} active={route === n.id} onClick={() => navigate(n.id)} />)}</div>
            </div>
          ))}
        </nav>
        <div className="m-3 p-3 rounded-xl bg-white/[.03] border border-white/5 text-xs">
          <div className="flex items-center gap-2"><span className={cx('size-2 rounded-full', mode === 'cloud' ? 'bg-green' : 'bg-amber')} />{mode === 'cloud' ? 'Cloud mode · synced' : 'Local mode · this device'}</div>
          <p className="text-muted mt-1 leading-relaxed">YOUR STREAM. YOUR CLIPS. AUTOMATICALLY.</p>
        </div>
      </aside>

      {/* Top bar */}
      <header className="sticky top-0 z-30 lg:pl-64">
        <div className="h-14 sm:h-16 px-4 sm:px-6 flex items-center justify-between gap-3 border-b border-white/5 bg-bg/70 backdrop-blur-xl" style={{ paddingTop: 'env(safe-area-inset-top)' }}>
          <div className="lg:hidden"><Logo compact /></div>
          <div className="hidden lg:flex items-center gap-2 text-sm text-muted"><Icon name={current.icon} size={16} />{current.group}<Icon name="chevronRight" size={14} /><span className="text-text">{current.label}</span></div>
          <div className="lg:hidden font-display font-semibold text-[15px] truncate">{current.label}</div>
          <div className="flex items-center gap-2 relative">
            {demo && <span className="hidden sm:inline-flex"><Badge tone="amber">Demo data</Badge></span>}
            <span className="hidden md:inline-flex"><Badge tone={mode === 'cloud' ? 'green' : 'amber'}>{mode === 'cloud' ? 'Cloud' : 'Local'}</Badge></span>
            {demo && <span className="sm:hidden size-2 rounded-full bg-amber" title="Demo data loaded" />}
            <button onClick={() => setBell((b) => !b)} className="relative size-10 grid place-items-center rounded-xl hover:bg-white/[.06] text-muted hover:text-text" aria-label="Notifications">
              <Icon name="bell" size={19} />
              {unread > 0 && <motion.span initial={{ scale: 0 }} animate={{ scale: 1 }} className="absolute top-1.5 right-1.5 min-w-4 h-4 px-1 rounded-full bg-gradient-to-r from-purple to-blue text-[10px] font-bold grid place-items-center text-white">{unread > 9 ? '9+' : unread}</motion.span>}
            </button>
            <AnimatePresence>{bell && <Notifications onClose={() => setBell(false)} />}</AnimatePresence>
          </div>
        </div>
        {syncError && <div className="px-4 py-2 text-xs bg-red/10 text-red border-b border-red/20">Sync problem: {syncError} <button className="underline ml-2" onClick={() => void db.boot()}>Retry</button></div>}
      </header>

      <main className="relative z-10 lg:pl-64">
        <div className="mx-auto max-w-[1400px] px-4 sm:px-6 lg:px-8 pt-5 sm:pt-8 pb-32 lg:pb-12">
          <AnimatePresence mode="wait">
            <motion.div key={route} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} transition={{ duration: 0.22, ease: 'easeOut' }}>
              {children}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* Mobile tab bar */}
      <nav className="lg:hidden fixed bottom-0 inset-x-0 z-40 border-t border-white/5 bg-surface/85 backdrop-blur-xl safe-bottom">
        <div className="grid grid-cols-5 h-16">
          {MOBILE_TABS.map((id) => {
            const n = NAV.find((x) => x.id === id)!; const active = route === id;
            return (
              <button key={id} onClick={() => navigate(id)} className={cx('relative flex flex-col items-center justify-center gap-1 text-[10px] font-medium', active ? 'text-white' : 'text-muted')}>
                {active && <motion.span layoutId="tab-glow" className="absolute top-0 h-0.5 w-8 rounded-full bg-gradient-to-r from-purple to-blue shadow-[0_0_12px_#7857ff]" />}
                <Icon name={n.icon} size={21} className={active ? 'text-[#b3a2ff]' : ''} />{n.label.split(' ')[0]}
              </button>
            );
          })}
          <button onClick={() => setMore(true)} className={cx('flex flex-col items-center justify-center gap-1 text-[10px] font-medium', !MOBILE_TABS.includes(route) ? 'text-white' : 'text-muted')}>
            <Icon name="menu" size={21} />More
          </button>
        </div>
      </nav>

      <AnimatePresence>
        {more && (
          <motion.div className="lg:hidden fixed inset-0 z-50" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setMore(false)} />
            <motion.div initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }} transition={{ type: 'spring', stiffness: 380, damping: 36 }}
              className="glass absolute bottom-0 inset-x-0 rounded-t-3xl p-4 safe-bottom">
              <div className="mx-auto mb-4 h-1 w-10 rounded-full bg-white/20" />
              <div className="grid grid-cols-3 gap-2">
                {NAV.map((n) => (
                  <button key={n.id} onClick={() => { navigate(n.id); setMore(false); }}
                    className={cx('flex flex-col items-center gap-2 rounded-2xl p-3.5 text-xs font-medium border transition-colors', route === n.id ? 'bg-purple/20 border-purple/40 text-white' : 'bg-white/[.03] border-white/5 text-muted')}>
                    <Icon name={n.icon} size={22} />{n.label}
                  </button>
                ))}
              </div>
              <Button variant="ghost" className="w-full mt-3" onClick={() => setMore(false)}>Close</Button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      <Toasts />
    </div>
  );
}
