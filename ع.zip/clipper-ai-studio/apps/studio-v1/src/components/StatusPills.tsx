import { Icon, type IconName } from './Icon.tsx';
import { navigate } from '../lib/router.ts';
import { useStore } from '../lib/store.ts';
import { useSystem } from '../lib/system.ts';
import { cx, timeAgo } from '../lib/format.ts';

type Tone = 'ok' | 'warn' | 'off';
function Pill({ icon, label, value, tone, onClick }: { icon: IconName; label: string; value: string; tone: Tone; onClick?: () => void }) {
  return (
    <button onClick={onClick} className="glass glass-hover rounded-xl px-3 py-2.5 flex items-center gap-2.5 text-left min-w-0">
      <span className={cx('grid place-items-center size-8 rounded-lg shrink-0', tone === 'ok' ? 'bg-green/12 text-green' : tone === 'warn' ? 'bg-amber/12 text-amber' : 'bg-white/5 text-muted')}><Icon name={icon} size={16} /></span>
      <span className="min-w-0">
        <span className="block text-[11px] text-muted">{label}</span>
        <span className="flex items-center gap-1.5 text-[13px] font-medium truncate">
          <span className={cx('size-1.5 rounded-full shrink-0', tone === 'ok' ? 'bg-green animate-pulse-soft' : tone === 'warn' ? 'bg-amber' : 'bg-muted/50')} />{value}
        </span>
      </span>
    </button>
  );
}

/** Real, polled status — never fake "online". */
export function StatusPills() {
  const s = useSystem();
  const mode = useStore((st) => st.mode);
  const auto = useStore((st) => st.settings.auto_clipping_enabled && !st.settings.auto_paused);
  const active = s.twitch.find((a) => a.status === 'active');
  const expired = s.twitch.find((a) => a.status !== 'active');
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5">
      <Pill icon="database" label="Data" value={mode === 'cloud' ? 'Cloud (Supabase)' : 'Local · this device'} tone={mode === 'cloud' ? 'ok' : 'warn'} onClick={() => navigate('settings')} />
      <Pill icon="cpu" label="Backend API" tone={s.api === 'online' ? 'ok' : s.api === 'not_configured' ? 'off' : 'warn'} onClick={() => navigate('settings')}
        value={{ online: 'Online', offline: 'Unreachable', misconfigured: 'Needs secrets', not_configured: 'Not configured' }[s.api]} />
      <Pill icon="twitch" label="Twitch" tone={active ? 'ok' : expired ? 'warn' : 'off'} onClick={() => navigate('settings')}
        value={active ? active.display_name || active.login : expired ? 'Reconnect needed' : 'Not connected'} />
      <Pill icon="bolt" label="Auto engine" onClick={() => navigate('auto')}
        tone={s.engine?.online ? (auto ? 'ok' : 'warn') : 'off'}
        value={!s.engine ? 'Not deployed' : s.engine.online ? (auto ? `Watching ${s.engine.channels}` : 'Online · auto off') : `Offline ${s.engine.lastSeen ? timeAgo(s.engine.lastSeen) : ''}`} />
    </div>
  );
}
