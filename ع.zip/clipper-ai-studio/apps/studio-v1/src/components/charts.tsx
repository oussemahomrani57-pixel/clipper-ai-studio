/** Lightweight interactive SVG charts (no chart library). */
import { motion } from 'framer-motion';
import { useId, useState } from 'react';

export function AreaChart({ data, height = 160, labels, color = '#7857ff', format = (v: number) => String(v) }: { data: number[]; height?: number; labels?: string[]; color?: string; format?: (v: number) => string }) {
  const id = useId().replace(/:/g, '');
  const [hover, setHover] = useState<number | null>(null);
  const W = 600; const H = height; const pad = 8;
  const max = Math.max(1, ...data);
  const x = (i: number) => pad + (i * (W - pad * 2)) / Math.max(1, data.length - 1);
  const y = (v: number) => H - pad - (v / max) * (H - pad * 2 - 14);
  const line = data.map((v, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(' ');
  const area = `${line} L${x(data.length - 1)},${H} L${x(0)},${H} Z`;
  return (
    <div className="relative">
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full touch-none" style={{ height }} preserveAspectRatio="none"
        onPointerMove={(e) => { const r = e.currentTarget.getBoundingClientRect(); const i = Math.round(((e.clientX - r.left) / r.width) * (data.length - 1)); setHover(Math.max(0, Math.min(data.length - 1, i))); }}
        onPointerLeave={() => setHover(null)}>
        <defs>
          <linearGradient id={`g${id}`} x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor={color} stopOpacity=".45" /><stop offset="1" stopColor={color} stopOpacity="0" /></linearGradient>
          <linearGradient id={`l${id}`} x1="0" x2="1"><stop offset="0" stopColor="#7857ff" /><stop offset="1" stopColor="#32a5ff" /></linearGradient>
        </defs>
        {[0.25, 0.5, 0.75].map((f) => <line key={f} x1="0" x2={W} y1={H * f} y2={H * f} stroke="rgba(255,255,255,.04)" />)}
        <motion.path d={area} fill={`url(#g${id})`} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.8 }} />
        <motion.path d={line} fill="none" stroke={`url(#l${id})`} strokeWidth="2.5" vectorEffect="non-scaling-stroke" initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 1.1, ease: 'easeOut' }} />
        {hover !== null && <>
          <line x1={x(hover)} x2={x(hover)} y1="0" y2={H} stroke="rgba(255,255,255,.15)" vectorEffect="non-scaling-stroke" />
          <circle cx={x(hover)} cy={y(data[hover])} r="4" fill="#fff" stroke={color} strokeWidth="2" vectorEffect="non-scaling-stroke" />
        </>}
      </svg>
      {hover !== null && (
        <div className="pointer-events-none absolute -top-2 glass rounded-lg px-2.5 py-1.5 text-xs" style={{ left: `clamp(0px, calc(${(x(hover) / W) * 100}% - 40px), calc(100% - 90px))` }}>
          <div className="text-muted">{labels?.[hover] ?? hover}</div>
          <div className="font-semibold tabular-nums">{format(data[hover])}</div>
        </div>
      )}
    </div>
  );
}

export function StackedBars({ series, labels, height = 170 }: { series: { name: string; color: string; data: number[] }[]; labels: string[]; height?: number }) {
  const [hover, setHover] = useState<number | null>(null);
  const n = labels.length;
  const totals = labels.map((_, i) => series.reduce((a, s) => a + (s.data[i] ?? 0), 0));
  const max = Math.max(1, ...totals);
  return (
    <div>
      <div className="relative flex items-end gap-[3px] sm:gap-1.5" style={{ height }} onPointerLeave={() => setHover(null)}>
        {labels.map((l, i) => (
          <div key={l} className="relative flex-1 h-full flex flex-col justify-end group" onPointerEnter={() => setHover(i)}>
            <div className="flex flex-col-reverse rounded-t-md overflow-hidden">
              {series.map((s) => (
                <motion.div key={s.name} initial={{ height: 0 }} animate={{ height: ((s.data[i] ?? 0) / max) * (height - 16) }} transition={{ delay: i * 0.015, type: 'spring', stiffness: 140, damping: 20 }}
                  style={{ background: s.color }} className={hover === i ? 'brightness-125' : 'opacity-90'} />
              ))}
            </div>
            {hover === i && (
              <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 z-10 glass rounded-lg px-2.5 py-1.5 text-xs whitespace-nowrap">
                <div className="text-muted">{l}</div>
                {series.map((s) => <div key={s.name} className="flex items-center gap-1.5"><span className="size-2 rounded-full" style={{ background: s.color }} />{s.name}: <b className="tabular-nums">{s.data[i] ?? 0}</b></div>)}
              </div>
            )}
          </div>
        ))}
      </div>
      <div className="flex justify-between text-[10px] text-muted mt-2 font-mono"><span>{labels[0]?.slice(5)}</span><span>{labels[Math.floor(n / 2)]?.slice(5)}</span><span>{labels[n - 1]?.slice(5)}</span></div>
      <div className="flex gap-4 mt-3">{series.map((s) => <span key={s.name} className="flex items-center gap-1.5 text-xs text-muted"><span className="size-2.5 rounded-sm" style={{ background: s.color }} />{s.name}</span>)}</div>
    </div>
  );
}

export function HBars({ items, format = (v: number) => String(v) }: { items: { label: string; value: number; color?: string }[]; format?: (v: number) => string }) {
  const max = Math.max(1, ...items.map((i) => i.value));
  return (
    <div className="space-y-3">
      {items.map((it, i) => (
        <div key={it.label}>
          <div className="flex justify-between text-sm mb-1.5"><span className="text-text/90">{it.label}</span><span className="tabular-nums text-muted">{format(it.value)}</span></div>
          <div className="h-2 rounded-full bg-white/[.06] overflow-hidden">
            <motion.div className="h-full rounded-full" style={{ background: it.color ?? 'linear-gradient(90deg,#7857ff,#32a5ff)' }} initial={{ width: 0 }} animate={{ width: `${(it.value / max) * 100}%` }} transition={{ delay: i * 0.06, type: 'spring', stiffness: 120, damping: 20 }} />
          </div>
        </div>
      ))}
    </div>
  );
}

export function ScoreGauge({ score, threshold, size = 150 }: { score: number; threshold: number; size?: number }) {
  const r = 52; const c = Math.PI * r; // half circle
  const pct = Math.max(0, Math.min(100, score)) / 100;
  const hot = score >= threshold;
  return (
    <div className="relative" style={{ width: size, height: size * 0.62 }}>
      <svg viewBox="0 0 120 70" className="w-full h-full">
        <defs><linearGradient id="gauge" x1="0" x2="1"><stop offset="0" stopColor="#7857ff" /><stop offset="1" stopColor={hot ? '#32e6a0' : '#32a5ff'} /></linearGradient></defs>
        <path d="M8 64 A52 52 0 0 1 112 64" fill="none" stroke="rgba(255,255,255,.07)" strokeWidth="10" strokeLinecap="round" />
        <motion.path d="M8 64 A52 52 0 0 1 112 64" fill="none" stroke="url(#gauge)" strokeWidth="10" strokeLinecap="round" strokeDasharray={c} animate={{ strokeDashoffset: c * (1 - pct) }} transition={{ type: 'spring', stiffness: 90, damping: 18 }} />
        {(() => { const a = Math.PI * (1 - threshold / 100); return <line x1={60 + 44 * Math.cos(a)} y1={64 - 44 * Math.sin(a)} x2={60 + 60 * Math.cos(a)} y2={64 - 60 * Math.sin(a)} stroke="#ffb547" strokeWidth="2" />; })()}
      </svg>
      <div className="absolute inset-x-0 bottom-0 text-center">
        <div className={`font-display text-3xl font-semibold tabular-nums ${hot ? 'text-green' : ''}`}>{Math.round(score)}</div>
      </div>
    </div>
  );
}

export function Sparkline({ data, className = 'h-10 w-full' }: { data: number[]; className?: string }) {
  const max = Math.max(1, ...data);
  const pts = data.map((v, i) => `${(i / Math.max(1, data.length - 1)) * 100},${30 - (v / max) * 28}`).join(' ');
  return <svg viewBox="0 0 100 30" preserveAspectRatio="none" className={className}><polyline points={pts} fill="none" stroke="#32a5ff" strokeWidth="1.6" vectorEffect="non-scaling-stroke" /></svg>;
}
