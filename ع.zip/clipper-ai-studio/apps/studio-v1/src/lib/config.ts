/**
 * Public configuration (safe to ship to the browser). Set in apps/web/.env.local
 * or in your hosting provider's environment variables. NEVER put secrets here:
 * anything prefixed VITE_ ends up in the JavaScript bundle.
 */
const env = ((import.meta as unknown as { env?: Record<string, string | undefined> }).env ?? {}) as Record<string, string | undefined>;

export const config = {
  supabaseUrl: (env.VITE_SUPABASE_URL ?? '').replace(/\/$/, ''),
  supabaseAnonKey: env.VITE_SUPABASE_ANON_KEY ?? '', // public "anon" key — protected by RLS
  apiUrl: (env.VITE_API_URL ?? '').replace(/\/$/, ''), // Cloudflare Worker URL
};

export const hasCloud = Boolean(config.supabaseUrl && config.supabaseAnonKey);
export const hasApi = Boolean(config.apiUrl);
