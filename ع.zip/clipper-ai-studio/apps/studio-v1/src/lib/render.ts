/** Canvas renderer for the 9:16 editor preview and on-device export. */
import type { Cue } from '@shared/subtitles.ts';
import type { SubtitleStyle } from './types.ts';

export interface Framing { zoom: number; panX: number; panY: number; background: 'blur' | 'black' | 'gradient' }
export interface Overlay { text: string; font: string; color: string; size: number; y: number }

const small = typeof document !== 'undefined' ? document.createElement('canvas') : null;

export function fgRect(vw: number, vh: number, W: number, H: number, f: Framing) {
  const fw = W * f.zoom; const fh = fw * (vh / vw);
  const fx = (W - fw) / 2 - f.panX * Math.max(0, (fw - W) / 2);
  const fy = (H - fh) / 2 - f.panY * Math.max(0, (fh - H) / 2);
  return { fx, fy, fw, fh };
}

/** Visible source region (normalized 0..1) — sent to the FFmpeg engine as a crop. */
export function cropFor(vw: number, vh: number, W: number, H: number, f: Framing) {
  const { fx, fy, fw, fh } = fgRect(vw, vh, W, H, f);
  const x0 = Math.max(0, -fx) / fw; const x1 = Math.min(fw, W - fx) / fw;
  const y0 = Math.max(0, -fy) / fh; const y1 = Math.min(fh, H - fy) / fh;
  return { x: x0, y: y0, w: Math.max(0.01, x1 - x0), h: Math.max(0.01, y1 - y0) };
}

export function drawFrame(ctx: CanvasRenderingContext2D, video: HTMLVideoElement, W: number, H: number, f: Framing) {
  const vw = video.videoWidth || 16; const vh = video.videoHeight || 9;
  if (f.background === 'black') { ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H); }
  else if (f.background === 'gradient') {
    const g = ctx.createLinearGradient(0, 0, W, H); g.addColorStop(0, '#1b1240'); g.addColorStop(0.5, '#08090f'); g.addColorStop(1, '#0b2a45');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  } else if (small) {
    // Cheap, Safari-compatible blur: downscale then upscale.
    small.width = Math.max(8, Math.round(W / 18)); small.height = Math.max(8, Math.round(H / 18));
    const s = small.getContext('2d')!;
    const cover = Math.max(small.width / vw, small.height / vh);
    s.drawImage(video, (small.width - vw * cover) / 2, (small.height - vh * cover) / 2, vw * cover, vh * cover);
    ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(small, 0, 0, W, H);
    ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.fillRect(0, 0, W, H);
  }
  const { fx, fy, fw, fh } = fgRect(vw, vh, W, H, f);
  ctx.drawImage(video, fx, fy, fw, fh);
}

export function drawOverlay(ctx: CanvasRenderingContext2D, o: Overlay, W: number, H: number) {
  if (!o.text.trim()) return;
  const size = (o.size / 1080) * W;
  ctx.font = `800 ${size}px ${o.font}, system-ui, sans-serif`;
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  const lines = wrap(ctx, o.text, W * 0.86);
  lines.forEach((l, i) => {
    const y = o.y * H + (i - (lines.length - 1) / 2) * size * 1.15;
    ctx.lineWidth = size * 0.16; ctx.strokeStyle = 'rgba(0,0,0,.85)'; ctx.lineJoin = 'round';
    ctx.strokeText(l, W / 2, y); ctx.fillStyle = o.color; ctx.fillText(l, W / 2, y);
  });
}

export function drawSubtitle(ctx: CanvasRenderingContext2D, cues: Cue[], t: number, st: SubtitleStyle, W: number, H: number) {
  const cue = cues.find((c) => t >= c.start && t < c.end);
  if (!cue) return;
  const size = (st.size / 1080) * W;
  const text = st.uppercase ? cue.text.toUpperCase() : cue.text;
  ctx.font = `${st.template === 'clean' ? 600 : 900} ${size}px ${st.font}, system-ui, sans-serif`;
  ctx.textBaseline = 'middle';
  const lines = wrap(ctx, text.replace(/\n/g, ' '), W * 0.84);
  const words = text.replace(/\n/g, ' ').split(/\s+/);
  const activeWord = Math.min(words.length - 1, Math.floor(((t - cue.start) / Math.max(0.01, cue.end - cue.start)) * words.length));
  let wi = 0;
  const pop = st.template === 'pop' ? 1 + 0.08 * Math.max(0, 1 - (t - cue.start) * 6) : 1;
  lines.forEach((line, li) => {
    const y = st.position * H + (li - (lines.length - 1) / 2) * size * 1.2;
    const lw = ctx.measureText(line).width;
    if (st.template === 'boxed') {
      ctx.fillStyle = 'rgba(0,0,0,.72)';
      const pad = size * 0.3; roundRect(ctx, W / 2 - lw / 2 - pad, y - size * 0.68, lw + pad * 2, size * 1.36, size * 0.25); ctx.fill();
    }
    let x = W / 2 - (lw * pop) / 2;
    ctx.save(); ctx.translate(W / 2, y); ctx.scale(pop, pop); ctx.translate(-W / 2, -y);
    x = W / 2 - lw / 2;
    for (const w of line.split(' ')) {
      const ww = ctx.measureText(`${w} `).width;
      const hl = st.template === 'karaoke' ? wi <= activeWord : st.template === 'pop' && wi === activeWord;
      if (st.template !== 'boxed') { ctx.lineWidth = size * 0.18; ctx.strokeStyle = '#000'; ctx.lineJoin = 'round'; ctx.textAlign = 'left'; ctx.strokeText(w, x, y); }
      ctx.textAlign = 'left'; ctx.fillStyle = hl ? st.highlight : st.color; ctx.fillText(w, x, y);
      x += ww; wi++;
    }
    ctx.restore();
  });
}

function wrap(ctx: CanvasRenderingContext2D, text: string, max: number): string[] {
  const out: string[] = []; let line = '';
  for (const w of text.split(/\s+/)) {
    const test = line ? `${line} ${w}` : w;
    if (ctx.measureText(test).width > max && line) { out.push(line); line = w; } else line = test;
  }
  if (line) out.push(line);
  return out.slice(0, 3);
}

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
}

export function pickRecorderMime(): string | null {
  if (typeof MediaRecorder === 'undefined') return null;
  for (const m of ['video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/mp4', 'video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm']) if (MediaRecorder.isTypeSupported(m)) return m;
  return null;
}
