/**
 * Browser chat monitor — reads PUBLIC Twitch chat anonymously (read-only "justinfan"
 * login over Twitch's official chat WebSocket). It needs no credentials, cannot post,
 * and STOPS when this tab is closed or the phone locks. 24/7 monitoring = the Engine.
 */
export type ChatState = 'idle' | 'connecting' | 'connected' | 'reconnecting' | 'error';
export interface ChatMsg { channel: string; userId: string; user: string; text: string; ts: number; }

export class BrowserChat {
  private ws: WebSocket | null = null;
  private channels = new Set<string>();
  private backoff = 1000;
  private stopped = true;
  private timer: ReturnType<typeof setTimeout> | null = null;
  state: ChatState = 'idle';
  onMessage: (m: ChatMsg) => void = () => {};
  onState: (s: ChatState, detail?: string) => void = () => {};

  setChannels(logins: string[]) {
    const next = new Set(logins.map((l) => l.toLowerCase()).filter((l) => /^[a-z0-9_]{2,25}$/.test(l)));
    if (this.ws?.readyState === WebSocket.OPEN) {
      for (const c of next) if (!this.channels.has(c)) this.ws.send(`JOIN #${c}`);
      for (const c of this.channels) if (!next.has(c)) this.ws.send(`PART #${c}`);
    }
    this.channels = next;
    if (next.size && this.stopped) this.start();
    if (!next.size) this.stop();
  }

  private set(s: ChatState, d?: string) { this.state = s; this.onState(s, d); }

  start() {
    this.stopped = false;
    this.set(this.backoff > 1000 ? 'reconnecting' : 'connecting');
    const ws = new WebSocket('wss://irc-ws.chat.twitch.tv:443');
    this.ws = ws;
    ws.onopen = () => {
      ws.send('CAP REQ :twitch.tv/tags');
      ws.send('PASS SCHMOOPIIE');
      ws.send(`NICK justinfan${Math.floor(10000 + Math.random() * 80000)}`);
      for (const c of this.channels) ws.send(`JOIN #${c}`);
      this.backoff = 1000;
      this.set('connected');
    };
    ws.onmessage = (ev) => {
      for (const line of String(ev.data).split('\r\n')) {
        if (!line) continue;
        if (line.startsWith('PING')) { ws.send(line.replace('PING', 'PONG')); continue; }
        const m = parsePrivmsg(line);
        if (m) this.onMessage(m);
      }
    };
    ws.onerror = () => this.set('error', 'Chat connection error');
    ws.onclose = () => {
      if (this.ws !== ws || this.stopped) return;
      this.set('reconnecting');
      this.timer = setTimeout(() => this.start(), this.backoff);
      this.backoff = Math.min(this.backoff * 2, 30_000);
    };
  }

  stop() {
    this.stopped = true;
    if (this.timer) clearTimeout(this.timer);
    this.ws?.close();
    this.ws = null;
    this.set('idle');
  }
}

export function parsePrivmsg(line: string): ChatMsg | null {
  // @tags :user!user@user.tmi.twitch.tv PRIVMSG #channel :message
  const m = line.match(/^(?:@([^ ]+) )?:([^!]+)![^ ]+ PRIVMSG #([^ ]+) :(.*)$/);
  if (!m) return null;
  const tags = new Map((m[1] ?? '').split(';').map((kv) => kv.split('=') as [string, string]));
  return { channel: m[3], user: tags.get('display-name') || m[2], userId: tags.get('user-id') || m[2], text: m[4], ts: Date.now() };
}
