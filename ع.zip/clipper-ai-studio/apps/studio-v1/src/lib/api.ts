/** Calls to the Cloudflare Worker API. Every call carries the Supabase session token. */
import { auth } from './auth.ts';
import { config, hasApi } from './config.ts';

export class ApiError extends Error {
  status: number; code: string; retryAfter?: number;
  constructor(status: number, code: string, message: string, retryAfter?: number) {
    super(message); this.status = status; this.code = code; this.retryAfter = retryAfter;
  }
}

export async function api<T>(path: string, init: RequestInit = {}): Promise<T> {
  if (!hasApi) throw new ApiError(0, 'not_configured', 'Backend API not configured (VITE_API_URL is empty).');
  const token = await auth.token();
  if (!token) throw new ApiError(401, 'unauthorized', 'Sign in to your Clipper account first.');
  let res: Response;
  try {
    res = await fetch(`${config.apiUrl}${path}`, {
      ...init,
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', ...(init.headers ?? {}) },
    });
  } catch {
    throw new ApiError(0, 'network', 'Cannot reach the backend. Check your connection or the Worker deployment.');
  }
  const body = (await res.json().catch(() => ({}))) as { data?: T; error?: { code: string; message: string; retry_after?: number } } & Record<string, unknown>;
  if (!res.ok) throw new ApiError(res.status, body.error?.code ?? 'error', body.error?.message ?? res.statusText, body.error?.retry_after);
  return (body.data ?? body) as T;
}

export async function apiHealth(): Promise<{ ok: boolean; missing: string[]; version: string } | null> {
  if (!hasApi) return null;
  try {
    const r = await fetch(`${config.apiUrl}/api/health`);
    return (await r.json()) as { ok: boolean; missing: string[]; version: string };
  } catch { return null; }
}

export interface TwitchAccount { id: string; twitch_user_id: string; login: string; display_name: string; profile_image_url: string; scopes: string[]; status: string; last_error: string | null; }
export interface ChannelResult { id: string; broadcaster_login: string; display_name: string; thumbnail_url: string; is_live: boolean; game_name: string; title: string; }
export interface StreamInfo { user_id: string; user_login: string; game_name: string; title: string; viewer_count: number; started_at: string; }
