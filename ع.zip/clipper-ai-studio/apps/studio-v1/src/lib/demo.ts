/** DEMO DATA — fictional sample records so you can explore the UI. Every row has is_demo: true
 *  and is labelled DEMO DATA everywhere. Never shown in Cloud mode; removable in one tap. */
import type { Tables } from './types.ts';

const ago = (h: number) => new Date(Date.now() - h * 3_600_000).toISOString();
const id = () => crypto.randomUUID();

export function buildDemo(): Partial<Tables> {
  const s1 = id(); const s2 = id(); const s3 = id();
  const names = [['demo_nova', 'DemoNova'], ['demo_pixelking', 'DemoPixelKing'], ['demo_luna', 'DemoLuna']];
  const streamers = [s1, s2, s3].map((sid, i) => ({
    id: sid, created_at: ago(200 + i), is_demo: true, twitch_user_id: null, login: names[i][0], display_name: names[i][1],
    profile_image_url: null, is_favorite: i === 0, monitor_enabled: i < 2, auto_clip_enabled: i === 0, preferences: {}, last_live_at: ago(i * 5 + 1),
  }));
  const clips = Array.from({ length: 14 }, (_, i) => {
    const s = streamers[i % 3];
    const auto = i % 3 !== 1;
    const status = i === 3 ? 'failed' : i === 0 ? 'processing' : 'ready';
    return {
      id: id(), created_at: ago(i * 9 + 1), is_demo: true, streamer_id: s.id, streamer_login: s.login, twitch_clip_id: null,
      title: ['Insane clutch 1v4', 'Chat goes wild', 'Unexpected jumpscare', 'Rage quit moment', 'Perfect timing', 'The comeback', 'Biggest laugh of the stream'][i % 7],
      url: null, edit_url: null, thumbnail_url: null, type: auto ? 'auto' : 'manual', detection_score: auto ? 62 + ((i * 7) % 35) : null,
      status, publish_status: i % 4 === 2 ? 'published' : 'unpublished', error: status === 'failed' ? 'DEMO: stream went offline before Twitch confirmed the clip' : null,
      storage_path: null, duration_sec: 30,
    } as Tables['clips'][number];
  });
  const detection_events = clips.filter((c) => c.type === 'auto').map((c) => ({
    id: id(), created_at: c.created_at, is_demo: true, streamer_id: c.streamer_id, streamer_login: c.streamer_login, score: c.detection_score ?? 70,
    components: { chatVelocity: 0.8, reactions: 0.6, keywords: 0.4, streamEvents: 0, other: 0.5 },
    reasons: ['Chat 3.4× faster than baseline', '58% of messages are reactions or repeats', 'Excitement keywords: "no way"×9'],
    action: 'clip_requested' as const, blocked_by: null, clip_id: c.id, source: 'engine' as const,
  }));
  const c1 = id();
  const campaigns = [{
    id: c1, created_at: ago(300), is_demo: true, name: 'DEMO — Example Content Rewards campaign', url: 'https://example.com/campaign',
    platforms: ['tiktok', 'youtube'], cpm: 1, currency: 'USD', max_payout: 100, max_payout_per_submission: null, min_views: 1000,
    requirements: 'DEMO: 9:16, streamer tag in caption, min 15 s.', status: 'active' as const, notes: null,
  }];
  const posts = clips.filter((c) => c.publish_status === 'published').map((c, i) => ({
    id: id(), created_at: c.created_at, is_demo: true, clip_id: c.id, platform: (['tiktok', 'youtube', 'instagram'] as const)[i % 3],
    caption: `${c.title} #demo`, hashtags: ['demo'], status: 'published' as const, method: 'manual' as const, scheduled_at: null,
    post_url: 'https://example.com/demo-post', error: null, views: [12400, 3800, 950, 22000][i % 4],
  }));
  const campaign_submissions = posts.slice(0, 2).map((p) => ({
    id: id(), created_at: p.created_at, is_demo: true, campaign_id: c1, post_id: p.id, platform: p.platform, post_url: `https://example.com/demo/${p.id.slice(0, 6)}`,
    eligible_views: p.views, status: 'approved' as const, confirmed_earnings: null,
  }));
  const notifications = [
    { id: id(), created_at: ago(0.2), is_demo: true, kind: 'clip_created', title: 'DEMO: Auto clip created', body: 'demo_nova — score 84', link: '#/library', read_at: null },
    { id: id(), created_at: ago(1), is_demo: true, kind: 'streamer_live', title: 'DEMO: demo_pixelking is live', body: null, link: '#/monitor', read_at: null },
  ];
  return { streamers, clips, detection_events, campaigns, posts, campaign_submissions, notifications };
}
