/**
 * Minimal Supabase Auth client (magic link) using the public REST API — no SDK needed.
 * The session is kept in localStorage and refreshed before expiry.
 */
import { config, hasCloud } from './config.ts';

export interface Session { access_token: string; refresh_token: string; expires_at: number; user: { id: string; email?: string } }

const KEY = 'clipper.session.v1';
let session: Session | null = load();
const listeners = new Set<() => void>();

function load(): Session | null {
  try { return JSON.parse(localStorage.getItem(KEY) ?? 'null'); } catch { return null; }
}
function save(s: Session | null) {
  session = s;
  if (s) localStorage.setItem(KEY, JSON.stringify(s)); else localStorage.removeItem(KEY);
  listeners.forEach((l) => l());
}

export const auth = {
  get session() { return session; },
  subscribe(cb: () => void) { listeners.add(cb); return () => { listeners.delete(cb); }; },

  /** Handle the magic-link redirect (#access_token=… in the URL). Call once at boot. */
  async consumeRedirect(): Promise<boolean> {
    if (!hasCloud) return false;
    const h = window.location.hash;
    if (!h.includes('access_token=')) return false;
    const p = new URLSearchParams(h.replace(/^#/, ''));
    const access = p.get('access_token'); const refresh = p.get('refresh_token');
    if (!access || !refresh) return false;
    const user = await fetchUser(access);
    if (user) save({ access_token: access, refresh_token: refresh, expires_at: Date.now() + Number(p.get('expires_in') ?? 3600) * 1000, user });
    history.replaceState(null, '', `${location.pathname}#/dashboard`);
    return Boolean(user);
  },

  async sendMagicLink(email: string) {
    const r = await fetch(`${config.supabaseUrl}/auth/v1/otp`, {
      method: 'POST',
      headers: { apikey: config.supabaseAnonKey, 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, create_user: true, options: { email_redirect_to: `${location.origin}${location.pathname}` } }),
    });
    if (!r.ok) throw new Error((await r.json().catch(() => ({})) as { msg?: string }).msg ?? 'Could not send the sign-in link');
  },

  /** Returns a valid access token, refreshing it when needed. */
  async token(): Promise<string | null> {
    if (!session) return null;
    if (session.expires_at - Date.now() > 60_000) return session.access_token;
    const r = await fetch(`${config.supabaseUrl}/auth/v1/token?grant_type=refresh_token`, {
      method: 'POST',
      headers: { apikey: config.supabaseAnonKey, 'Content-Type': 'application/json' },
      body: JSON.stringify({ refresh_token: session.refresh_token }),
    });
    if (!r.ok) { save(null); return null; }
    const j = (await r.json()) as { access_token: string; refresh_token: string; expires_in: number; user: Session['user'] };
    save({ access_token: j.access_token, refresh_token: j.refresh_token, expires_at: Date.now() + j.expires_in * 1000, user: j.user });
    return j.access_token;
  },

  async signOut() {
    const t = session?.access_token;
    save(null);
    if (t) await fetch(`${config.supabaseUrl}/auth/v1/logout`, { method: 'POST', headers: { apikey: config.supabaseAnonKey, Authorization: `Bearer ${t}` } }).catch(() => undefined);
  },
};

async function fetchUser(token: string) {
  const r = await fetch(`${config.supabaseUrl}/auth/v1/user`, { headers: { apikey: config.supabaseAnonKey, Authorization: `Bearer ${token}` } });
  return r.ok ? ((await r.json()) as Session['user']) : null;
}
