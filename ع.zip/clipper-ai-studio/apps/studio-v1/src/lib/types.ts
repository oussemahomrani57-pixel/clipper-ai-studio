import type { Cue, DetectorConfig, ScoreComponents } from '@shared/index.ts';

export type Platform = 'tiktok' | 'instagram' | 'youtube';

interface Row { id: string; user_id?: string; created_at: string; updated_at?: string; is_demo?: boolean; }

export interface Streamer extends Row {
  twitch_user_id: string | null;
  login: string;
  display_name: string | null;
  profile_image_url: string | null;
  is_favorite: boolean;
  monitor_enabled: boolean;
  auto_clip_enabled: boolean;
  preferences: Partial<Pick<DetectorConfig, 'minScore' | 'cooldownSec' | 'maxPerHour'>>;
  last_live_at: string | null;
}

export type ClipStatus = 'requested' | 'processing' | 'ready' | 'failed';
export type PublishStatus = 'unpublished' | 'scheduled' | 'published' | 'failed';

export interface Clip extends Row {
  streamer_id: string | null;
  streamer_login: string | null;
  twitch_clip_id: string | null;
  title: string | null;
  url: string | null;
  edit_url: string | null;
  thumbnail_url: string | null;
  type: 'manual' | 'auto' | 'upload';
  detection_score: number | null;
  status: ClipStatus;
  publish_status: PublishStatus;
  error: string | null;
  storage_path: string | null; // cloud storage path
  local_file?: boolean; // video blob stored in this device's IndexedDB
  duration_sec: number | null;
}

export interface DetectionEvent extends Row {
  streamer_id: string | null;
  streamer_login: string | null;
  score: number;
  components: Partial<ScoreComponents>;
  reasons: string[];
  action: 'clip_requested' | 'skipped' | 'dry_run';
  blocked_by: string | null;
  clip_id: string | null;
  source: 'engine' | 'browser' | 'simulation';
}

export interface Campaign extends Row {
  name: string;
  url: string | null;
  platforms: string[];
  cpm: number | null;
  currency: string;
  max_payout: number | null;
  max_payout_per_submission: number | null;
  min_views: number | null;
  requirements: string | null;
  status: 'active' | 'paused' | 'ended';
  notes: string | null;
}

export interface Submission extends Row {
  campaign_id: string;
  post_id: string | null;
  platform: Platform | 'other';
  post_url: string;
  eligible_views: number | null;
  status: 'submitted' | 'approved' | 'rejected' | 'paid';
  confirmed_earnings: number | null;
}

export interface Post extends Row {
  clip_id: string | null;
  platform: Platform;
  caption: string;
  hashtags: string[];
  status: 'draft' | 'ready' | 'scheduled' | 'uploading' | 'published' | 'failed';
  method: 'manual' | 'api';
  scheduled_at: string | null;
  post_url: string | null;
  error: string | null;
  views: number | null;
}

export interface Notification extends Row {
  kind: string;
  title: string;
  body: string | null;
  link: string | null;
  read_at: string | null;
}

export interface SubtitleDoc extends Row {
  clip_id: string | null;
  language: string;
  provider: string;
  cues: Cue[];
  style: SubtitleStyle;
}

export interface SubtitleStyle {
  template: 'pop' | 'clean' | 'karaoke' | 'boxed';
  font: string;
  size: number; // px at 1080 width
  color: string;
  highlight: string;
  position: number; // 0 (top) .. 1 (bottom)
  uppercase: boolean;
}

export interface Job extends Row {
  kind: 'clip_create' | 'render' | 'transcribe' | 'publish' | 'monitor';
  status: 'queued' | 'running' | 'succeeded' | 'failed' | 'cancelled';
  payload: Record<string, unknown>;
  result: Record<string, unknown> | null;
  attempts: number;
  error: string | null;
  completed_at: string | null;
}

export interface Settings {
  auto_clipping_enabled: boolean;
  auto_paused: boolean;
  detector: Partial<DetectorConfig>;
  video: { preset: '1080x1920' | '720x1280'; background: 'blur' | 'black' | 'gradient'; font: string };
  subtitles: { provider: 'manual' | 'whisper_cpp' | 'openai'; style: SubtitleStyle };
  notifications: Record<string, boolean>;
  currency: string;
  reduce_motion: boolean;
}

export interface Tables {
  streamers: Streamer[];
  clips: Clip[];
  detection_events: DetectionEvent[];
  campaigns: Campaign[];
  campaign_submissions: Submission[];
  posts: Post[];
  notifications: Notification[];
  subtitles: SubtitleDoc[];
  jobs: Job[];
}
export type TableName = keyof Tables;
export type RowOf<T extends TableName> = Tables[T][number];
