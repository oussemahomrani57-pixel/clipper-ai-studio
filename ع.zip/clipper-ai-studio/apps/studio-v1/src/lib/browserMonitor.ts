/**
 * In-browser live monitor (singleton). Keeps running while you navigate inside the app,
 * STOPS when the tab/app is closed or iOS suspends it. Feeds the shared MomentDetector.
 */
import { useSyncExternalStore } from 'react';
import { MomentDetector, type Evaluation, DEFAULT_CONFIG } from '@shared/scoring.ts';
import { BrowserChat, type ChatMsg, type ChatState } from './twitchChat.ts';
import { db, getState, notify, toast } from './store.ts';
import { api } from './api.ts';
import { getSystem, twitchReady } from './system.ts';

const BUCKET_MS = 10_000;
const BUCKETS = 60; // 10 minutes

export interface ChannelView {
  login: string;
  streamerId: string;
  buckets: number[];
  total: number;
  last: Evaluation | null;
  recent: ChatMsg[];
  peak: number;
}

interface Snapshot { state: ChatState; detail?: string; running: boolean; startedAt: number | null; channels: Record<string, ChannelView>; clipFromBrowser: boolean; }

const chat = new BrowserChat();
const detectors = new Map<string, MomentDetector>();
let snap: Snapshot = { state: 'idle', running: false, startedAt: null, channels: {}, clipFromBrowser: false };
let tick: ReturnType<typeof setInterval> | null = null;
let dirty = false;
const ls = new Set<() => void>();
const emit = () => { snap = { ...snap }; ls.forEach((l) => l()); };

chat.onState = (state, detail) => { snap.state = state; snap.detail = detail; emit(); };
chat.onMessage = (m) => {
  const v = snap.channels[m.channel];
  if (!v) return;
  detectors.get(m.channel)?.addMessage({ ts: m.ts, userId: m.userId, text: m.text });
  v.buckets[v.buckets.length - 1]++;
  v.total++;
  v.recent = [m, ...v.recent.slice(0, 5)];
  dirty = true;
};

function configFor(streamerId: string) {
  const s = getState();
  const st = s.tables.streamers.find((x) => x.id === streamerId);
  return { ...DEFAULT_CONFIG, ...s.settings.detector, ...(st?.preferences ?? {}) };
}

async function onTrigger(v: ChannelView, e: Evaluation) {
  const s = getState();
  const st = s.tables.streamers.find((x) => x.id === v.streamerId);
  const canClip = snap.clipFromBrowser && s.settings.auto_clipping_enabled && !s.settings.auto_paused && twitchReady(getSystem()) && st?.auto_clip_enabled && st.twitch_user_id;
  const ev = await db.insert('detection_events', {
    streamer_id: v.streamerId, streamer_login: v.login, score: e.score, components: e.components, reasons: e.reasons,
    action: canClip ? 'clip_requested' : 'dry_run', blocked_by: null, clip_id: null, source: 'browser',
  }).catch(() => null);
  void notify('moment_detected', `Moment detected on ${v.login} (${e.score})`, e.reasons[0], '#/monitor');
  if (!canClip) { toast('info', `Moment detected · ${v.login}`, `Score ${e.score} — logged (no clip requested)`); return; }
  try {
    await api('/api/clips', { method: 'POST', body: JSON.stringify({ broadcaster_id: st!.twitch_user_id, streamer_id: st!.id, type: 'auto', score: e.score, detection_event_id: ev?.id, title: `${v.login} — auto clip (${e.score})` }) });
    toast('success', `Auto clip requested · ${v.login}`, `Score ${e.score}`);
    await db.refresh('clips');
  } catch (err) { toast('error', 'Auto clip failed', (err as Error).message); }
}

function loop() {
  const now = Date.now();
  const bucketIndex = Math.floor(now / BUCKET_MS);
  for (const v of Object.values(snap.channels)) {
    const anyV = v as ChannelView & { _bi?: number };
    if (anyV._bi === undefined) anyV._bi = bucketIndex;
    while (anyV._bi < bucketIndex) { v.buckets = [...v.buckets.slice(1), 0]; anyV._bi++; }
    const d = detectors.get(v.login)!;
    Object.assign(d.config, configFor(v.streamerId));
    const e = d.evaluate(now);
    v.last = e; v.peak = Math.max(v.peak, e.score);
    if (e.shouldTrigger) { d.markTriggered(now); void onTrigger(v, e); }
  }
  dirty = false;
  emit(); // 1 Hz UI refresh keeps the gauge and chart live even when chat is quiet
}

export const browserMonitor = {
  use: () => useSyncExternalStore((cb) => { ls.add(cb); return () => ls.delete(cb); }, () => snap),
  start(streamers: { id: string; login: string }[]) {
    const channels: Record<string, ChannelView> = {};
    for (const s of streamers.slice(0, 8)) {
      const login = s.login.toLowerCase();
      channels[login] = snap.channels[login] ?? { login, streamerId: s.id, buckets: Array(BUCKETS).fill(0), total: 0, last: null, recent: [], peak: 0 };
      if (!detectors.has(login)) detectors.set(login, new MomentDetector(configFor(s.id)));
    }
    snap.channels = channels;
    snap.running = true;
    snap.startedAt = snap.startedAt ?? Date.now();
    chat.setChannels(Object.keys(channels));
    if (!tick) tick = setInterval(loop, 1000);
    emit();
  },
  stop() {
    chat.stop();
    if (tick) clearInterval(tick);
    tick = null;
    snap.running = false; snap.startedAt = null;
    emit();
  },
  setClipFromBrowser(v: boolean) { snap.clipFromBrowser = v; emit(); },
};
