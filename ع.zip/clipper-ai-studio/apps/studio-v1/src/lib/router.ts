import { useSyncExternalStore } from 'react';

/** Hash router: works on any static host (Cloudflare Pages, GitHub Pages) with no rewrites. */
export type RouteId =
  | 'dashboard' | 'monitor' | 'manual' | 'auto' | 'streamers' | 'library'
  | 'editor' | 'subtitles' | 'publisher' | 'campaigns' | 'analytics' | 'settings';

const ROUTES: RouteId[] = ['dashboard', 'monitor', 'manual', 'auto', 'streamers', 'library', 'editor', 'subtitles', 'publisher', 'campaigns', 'analytics', 'settings'];

function parse(): { route: RouteId; params: URLSearchParams } {
  const h = window.location.hash.replace(/^#\/?/, '');
  const [path, query = ''] = h.split('?');
  const route = (ROUTES as string[]).includes(path) ? (path as RouteId) : 'dashboard';
  return { route, params: new URLSearchParams(query) };
}

let current = parse();
const listeners = new Set<() => void>();
window.addEventListener('hashchange', () => { current = parse(); listeners.forEach((l) => l()); });

export function useRoute() {
  return useSyncExternalStore((cb) => { listeners.add(cb); return () => listeners.delete(cb); }, () => current);
}

export function navigate(route: RouteId, params?: Record<string, string>) {
  const q = params ? `?${new URLSearchParams(params)}` : '';
  window.location.hash = `/${route}${q}`;
}
