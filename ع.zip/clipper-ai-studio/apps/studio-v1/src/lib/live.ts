/** Live status from Twitch Helix (via the Worker). Unknown (null) when the backend isn't available. */
import { useSyncExternalStore } from 'react';
import { api, type StreamInfo } from './api.ts';
import { getState } from './store.ts';
import { getSystem } from './system.ts';

let live: { known: boolean; at: number; streams: Record<string, StreamInfo> } = { known: false, at: 0, streams: {} };
const ls = new Set<() => void>();

export const useLive = () => useSyncExternalStore((cb) => { ls.add(cb); return () => ls.delete(cb); }, () => live);

export async function refreshLive(force = false) {
  if (getSystem().api !== 'online' || getState().mode !== 'cloud') return;
  if (!force && Date.now() - live.at < 60_000) return; // avoid unnecessary requests
  const ids = getState().tables.streamers.map((s) => s.twitch_user_id).filter(Boolean) as string[];
  if (!ids.length) { live = { known: true, at: Date.now(), streams: {} }; ls.forEach((l) => l()); return; }
  const data = await api<StreamInfo[]>(`/api/twitch/streams?ids=${ids.slice(0, 100).join(',')}`);
  live = { known: true, at: Date.now(), streams: Object.fromEntries(data.map((s) => [s.user_id, s])) };
  ls.forEach((l) => l());
}

export function isLive(twitchId: string | null): boolean | null {
  if (!live.known || !twitchId) return null;
  return Boolean(live.streams[twitchId]);
}
