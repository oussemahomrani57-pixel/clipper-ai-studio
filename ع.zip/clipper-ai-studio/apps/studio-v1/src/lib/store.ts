/**
 * Data layer with two honest modes:
 *  - LOCAL: no account/backend. Data lives in this browser's localStorage (+ IndexedDB for video).
 *  - CLOUD: signed in to Supabase. Data is read/written through PostgREST, protected by RLS.
 * Pages use the same API for both: useStore(selector) + db.insert/update/remove.
 */
import { useSyncExternalStore } from 'react';
import { DEFAULT_CONFIG } from '@shared/scoring.ts';
import { auth } from './auth.ts';
import { config, hasCloud } from './config.ts';
import type { RowOf, Settings, TableName, Tables } from './types.ts';

export const TABLES: TableName[] = ['streamers', 'clips', 'detection_events', 'campaigns', 'campaign_submissions', 'posts', 'notifications', 'subtitles', 'jobs'];
const LOCAL_ONLY_FIELDS = new Set(['local_file']);

export const DEFAULT_SETTINGS: Settings = {
  auto_clipping_enabled: false,
  auto_paused: false,
  detector: { ...DEFAULT_CONFIG },
  video: { preset: '1080x1920', background: 'blur', font: 'Inter' },
  subtitles: {
    provider: 'manual',
    style: { template: 'pop', font: 'Inter', size: 64, color: '#FFFFFF', highlight: '#32E6A0', position: 0.72, uppercase: true },
  },
  notifications: { streamer_live: true, moment: true, clip_created: true, clip_failed: true, render: true, publish: true, connection: true },
  currency: 'USD',
  reduce_motion: false,
};

export interface State {
  mode: 'local' | 'cloud';
  loading: boolean;
  syncError: string | null;
  tables: Tables;
  settings: Settings;
  toasts: { id: string; kind: 'success' | 'error' | 'info'; title: string; body?: string }[];
}

const LS_KEY = 'clipper.local.v1';
const emptyTables = (): Tables => ({ streamers: [], clips: [], detection_events: [], campaigns: [], campaign_submissions: [], posts: [], notifications: [], subtitles: [], jobs: [] });

function loadLocal(): Pick<State, 'tables' | 'settings'> {
  try {
    const raw = JSON.parse(localStorage.getItem(LS_KEY) ?? 'null');
    if (raw) return { tables: { ...emptyTables(), ...raw.tables }, settings: deepMerge(DEFAULT_SETTINGS, raw.settings ?? {}) };
  } catch { /* corrupted storage → start fresh */ }
  return { tables: emptyTables(), settings: DEFAULT_SETTINGS };
}

function deepMerge<T>(base: T, over: Partial<T>): T {
  const out: Record<string, unknown> = { ...(base as Record<string, unknown>) };
  for (const [k, v] of Object.entries(over ?? {})) {
    const b = (base as Record<string, unknown>)[k];
    out[k] = v && typeof v === 'object' && !Array.isArray(v) && b && typeof b === 'object' ? deepMerge(b, v as object) : v;
  }
  return out as T;
}

let state: State = { mode: hasCloud && auth.session ? 'cloud' : 'local', loading: false, syncError: null, toasts: [], ...loadLocal() };
const listeners = new Set<() => void>();

function set(patch: Partial<State> | ((s: State) => Partial<State>)) {
  state = { ...state, ...(typeof patch === 'function' ? patch(state) : patch) };
  if (state.mode === 'local') localStorage.setItem(LS_KEY, JSON.stringify({ tables: state.tables, settings: state.settings }));
  listeners.forEach((l) => l());
}

export function useStore<T>(sel: (s: State) => T): T {
  return useSyncExternalStore((cb) => { listeners.add(cb); return () => listeners.delete(cb); }, () => sel(state));
}
export const getState = () => state;

// ───────────────────────── cloud REST
async function rest<T>(path: string, init: RequestInit = {}): Promise<T> {
  const token = await auth.token();
  if (!token) throw new Error('Session expired — sign in again');
  const r = await fetch(`${config.supabaseUrl}/rest/v1/${path}`, {
    ...init,
    headers: { apikey: config.supabaseAnonKey, Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', Prefer: 'return=representation', ...(init.headers ?? {}) },
  });
  if (!r.ok) {
    const j = (await r.json().catch(() => ({}))) as { message?: string; code?: string };
    throw new Error(j.code === '23505' ? 'Duplicate: this record already exists' : j.message ?? `Request failed (${r.status})`);
  }
  return r.status === 204 ? (undefined as T) : r.json() as Promise<T>;
}

const stripLocal = (row: Record<string, unknown>) => Object.fromEntries(Object.entries(row).filter(([k]) => !LOCAL_ONLY_FIELDS.has(k)));

// ───────────────────────── public API
export const db = {
  async boot() {
    if (state.mode !== 'cloud') return;
    set({ loading: true, syncError: null });
    try {
      const results = await Promise.all(TABLES.map((t) => rest<unknown[]>(`${t}?select=*&order=created_at.desc&limit=500`)));
      const tables = emptyTables();
      TABLES.forEach((t, i) => { (tables[t] as unknown[]) = results[i]; });
      const [s] = await rest<Partial<Settings>[]>(`user_settings?select=*`);
      set({ tables, settings: deepMerge(DEFAULT_SETTINGS, s ?? {}), loading: false });
    } catch (e) {
      set({ loading: false, syncError: (e as Error).message });
    }
  },

  setMode(mode: State['mode']) {
    set({ mode, ...(mode === 'local' ? loadLocal() : { tables: emptyTables() }) });
    if (mode === 'cloud') void db.boot();
  },

  async insert<T extends TableName>(table: T, row: Partial<RowOf<T>>): Promise<RowOf<T>> {
    const full = { id: crypto.randomUUID(), created_at: new Date().toISOString(), ...row } as RowOf<T>;
    if (state.mode === 'cloud') {
      const [saved] = await rest<RowOf<T>[]>(table, { method: 'POST', body: JSON.stringify({ ...stripLocal(full as unknown as Record<string, unknown>), user_id: auth.session!.user.id }) });
      const merged = { ...saved, ...(row as object) } as RowOf<T>;
      set((s) => ({ tables: { ...s.tables, [table]: [merged, ...s.tables[table]] } }));
      return merged;
    }
    set((s) => ({ tables: { ...s.tables, [table]: [full, ...s.tables[table]] } }));
    return full;
  },

  async update<T extends TableName>(table: T, id: string, patch: Partial<RowOf<T>>) {
    const prev = state.tables[table];
    const upd = { ...patch, updated_at: new Date().toISOString() };
    set((s) => ({ tables: { ...s.tables, [table]: (s.tables[table] as RowOf<T>[]).map((r) => (r.id === id ? { ...r, ...upd } : r)) } }));
    if (state.mode === 'cloud') {
      try { await rest(`${table}?id=eq.${id}`, { method: 'PATCH', body: JSON.stringify(stripLocal(patch as unknown as Record<string, unknown>)) }); }
      catch (e) { set((s) => ({ tables: { ...s.tables, [table]: prev } })); throw e; }
    }
  },

  async remove<T extends TableName>(table: T, id: string) {
    const prev = state.tables[table];
    set((s) => ({ tables: { ...s.tables, [table]: (s.tables[table] as RowOf<T>[]).filter((r) => r.id !== id) } }));
    if (state.mode === 'cloud') {
      try { await rest(`${table}?id=eq.${id}`, { method: 'DELETE' }); }
      catch (e) { set((s) => ({ tables: { ...s.tables, [table]: prev } })); throw e; }
    }
  },

  /** Replace a table locally (used after refreshing from the API). */
  replace<T extends TableName>(table: T, rows: Tables[T]) {
    set((s) => ({ tables: { ...s.tables, [table]: rows } }));
  },

  async refresh<T extends TableName>(table: T) {
    if (state.mode !== 'cloud') return;
    db.replace(table, await rest<Tables[T]>(`${table}?select=*&order=created_at.desc&limit=500`));
  },

  async saveSettings(patch: Partial<Settings>) {
    const next = deepMerge(state.settings, patch);
    set({ settings: next });
    if (state.mode === 'cloud') {
      const { auto_clipping_enabled, auto_paused, detector, video, subtitles, notifications } = next;
      await rest(`user_settings?user_id=eq.${auth.session!.user.id}`, { method: 'PATCH', body: JSON.stringify({ auto_clipping_enabled, auto_paused, detector, video, subtitles, notifications }) });
    }
  },

  exportAll() {
    return JSON.stringify({ exported_at: new Date().toISOString(), app: 'clipper-ai-studio', mode: state.mode, settings: state.settings, tables: state.tables }, null, 2);
  },

  importLocal(json: string) {
    const j = JSON.parse(json) as { tables?: Partial<Tables>; settings?: Partial<Settings> };
    if (state.mode !== 'local') throw new Error('Import is available in Local mode only');
    set({ tables: { ...emptyTables(), ...j.tables }, settings: deepMerge(DEFAULT_SETTINGS, j.settings ?? {}) });
  },

  clearLocal() {
    localStorage.removeItem(LS_KEY);
    set({ tables: emptyTables(), settings: DEFAULT_SETTINGS });
  },

  removeDemo() {
    set((s) => {
      const t = emptyTables();
      for (const k of TABLES) (t[k] as unknown[]) = (s.tables[k] as { is_demo?: boolean }[]).filter((r) => !r.is_demo);
      return { tables: t };
    });
  },

  loadDemo(tables: Partial<Tables>) {
    if (state.mode !== 'local') throw new Error('Demo data is only available in Local mode');
    set((s) => {
      const t = { ...s.tables };
      for (const k of TABLES) if (tables[k]) (t[k] as unknown[]) = [...(tables[k] as unknown[]), ...(s.tables[k] as unknown[])];
      return { tables: t };
    });
  },
};

// ───────────────────────── toasts + notifications
export function toast(kind: State['toasts'][number]['kind'], title: string, body?: string) {
  const id = crypto.randomUUID();
  set((s) => ({ toasts: [...s.toasts.slice(-3), { id, kind, title, body }] }));
  setTimeout(() => set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })), kind === 'error' ? 7000 : 4200);
}
export const dismissToast = (id: string) => set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) }));

export async function notify(kind: string, title: string, body?: string, link?: string) {
  const prefs = state.settings.notifications;
  const group = kind.startsWith('clip_') ? kind : kind.split('_')[0];
  if (prefs[group] === false || prefs[kind] === false) return;
  await db.insert('notifications', { kind, title, body: body ?? null, link: link ?? null, read_at: null }).catch(() => undefined);
}

export const isDemoActive = (s: State) => TABLES.some((t) => (s.tables[t] as { is_demo?: boolean }[]).some((r) => r.is_demo));
