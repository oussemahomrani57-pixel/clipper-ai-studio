/** System status: backend health, Twitch connection, engine heartbeat. Polled, never assumed. */
import { useSyncExternalStore } from 'react';
import { api, apiHealth, type TwitchAccount } from './api.ts';
import { auth } from './auth.ts';
import { config, hasApi, hasCloud } from './config.ts';
import { getState } from './store.ts';

export interface SystemState {
  checked: boolean;
  api: 'not_configured' | 'offline' | 'misconfigured' | 'online';
  apiMissing: string[];
  twitch: TwitchAccount[];
  twitchError: string | null;
  engine: { online: boolean; lastSeen: string | null; channels: number; eventsub: boolean } | null;
}

let sys: SystemState = { checked: false, api: hasApi ? 'offline' : 'not_configured', apiMissing: [], twitch: [], twitchError: null, engine: null };
const ls = new Set<() => void>();
const set = (p: Partial<SystemState>) => { sys = { ...sys, ...p }; ls.forEach((l) => l()); };

export const useSystem = () => useSyncExternalStore((cb) => { ls.add(cb); return () => ls.delete(cb); }, () => sys);
export const getSystem = () => sys;

export async function refreshSystem() {
  const h = await apiHealth();
  const apiState: SystemState['api'] = !hasApi ? 'not_configured' : !h ? 'offline' : h.ok ? 'online' : 'misconfigured';
  set({ api: apiState, apiMissing: h?.missing ?? [] });

  if (apiState === 'online' && getState().mode === 'cloud') {
    try { set({ twitch: await api<TwitchAccount[]>('/api/twitch/accounts'), twitchError: null }); }
    catch (e) { set({ twitchError: (e as Error).message }); }
  } else set({ twitch: [] });

  if (hasCloud && getState().mode === 'cloud') {
    try {
      const token = await auth.token();
      const r = await fetch(`${config.supabaseUrl}/rest/v1/engine_heartbeats?select=*&order=last_seen.desc&limit=1`, { headers: { apikey: config.supabaseAnonKey, Authorization: `Bearer ${token}` } });
      const [hb] = (await r.json()) as { last_seen: string; monitored_channels: number; eventsub_connected: boolean }[];
      set({ engine: hb ? { online: Date.now() - new Date(hb.last_seen).getTime() < 90_000, lastSeen: hb.last_seen, channels: hb.monitored_channels, eventsub: hb.eventsub_connected } : { online: false, lastSeen: null, channels: 0, eventsub: false } });
    } catch { set({ engine: null }); }
  }
  set({ checked: true });
}

export const twitchReady = (s: SystemState) => s.api === 'online' && s.twitch.some((a) => a.status === 'active');
