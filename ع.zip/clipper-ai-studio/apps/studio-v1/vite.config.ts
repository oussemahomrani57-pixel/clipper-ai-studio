import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import { fileURLToPath } from 'node:url';

export default defineConfig({
  plugins: [react(), tailwindcss()],
  base: './', // works on Cloudflare Pages, GitHub Pages sub-paths, or any static host
  resolve: { alias: { '@shared': fileURLToPath(new URL('../../packages/shared/src', import.meta.url)) } },
  server: { fs: { allow: ['../..'] } },
  build: { target: 'es2022', sourcemap: false },
});
