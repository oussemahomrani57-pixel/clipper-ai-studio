/**
 * CLIPPER AI STUDIO — API Worker (Cloudflare Workers, free plan friendly).
 *
 * Responsibilities: Twitch OAuth (server-side secret), encrypted token storage,
 * token refresh, Helix proxy (search / live status), Create Clip + confirmation.
 * Long-running work (24/7 chat monitoring, FFmpeg, transcription) is NOT done here —
 * that belongs to apps/engine, because Workers are request-scoped and CPU-limited.
 */
import { Supa } from '../../../packages/shared/src/supa.ts';
import { decryptToken, encryptToken, hmac, timingSafeEqual } from '../../../packages/shared/src/crypto.ts';
import {
  TWITCH_SCOPES, TwitchError, createClip, exchangeCode, getAppToken, getClip, helix, refreshUserToken, revokeToken,
  type TwitchChannelSearch, type TwitchStream, type TwitchUser,
} from '../../../packages/shared/src/twitch.ts';

export interface Env {
  APP_URL: string; // e.g. https://clipper.pages.dev  (exact origin, used for CORS + redirects)
  TWITCH_CLIENT_ID: string;
  TWITCH_CLIENT_SECRET: string; // secret
  TWITCH_REDIRECT_URI: string; // e.g. https://api.example.workers.dev/api/twitch/callback
  SUPABASE_URL: string;
  SUPABASE_SERVICE_ROLE_KEY: string; // secret
  TOKEN_ENCRYPTION_KEY: string; // secret, 32 bytes base64
  OAUTH_STATE_SECRET: string; // secret, random string
}

const VERSION = '0.1.0';
let appToken: { token: string; exp: number } | null = null; // per-isolate cache

// ───────────────────────────────────────── helpers
function cors(env: Env): Record<string, string> {
  return {
    'Access-Control-Allow-Origin': env.APP_URL,
    'Access-Control-Allow-Methods': 'GET,POST,DELETE,OPTIONS',
    'Access-Control-Allow-Headers': 'Authorization,Content-Type',
    'Access-Control-Max-Age': '86400',
    Vary: 'Origin',
  };
}
function json(env: Env, body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json', ...cors(env) } });
}
function fail(env: Env, status: number, code: string, message: string, extra: Record<string, unknown> = {}) {
  return json(env, { error: { code, message, ...extra } }, status);
}
const LOGIN_RE = /^[a-zA-Z0-9_]{2,25}$/;
const ID_RE = /^\d{1,20}$/;

async function requireUser(req: Request, db: Supa) {
  const h = req.headers.get('Authorization') ?? '';
  const jwt = h.startsWith('Bearer ') ? h.slice(7) : '';
  if (!jwt) return null;
  return db.userFromJwt(jwt);
}

async function app(env: Env): Promise<string> {
  if (appToken && appToken.exp > Date.now() + 60_000) return appToken.token;
  const t = await getAppToken(env.TWITCH_CLIENT_ID, env.TWITCH_CLIENT_SECRET);
  appToken = { token: t.access_token, exp: Date.now() + t.expires_in * 1000 };
  return appToken.token;
}

interface AccountRow { id: string; user_id: string; twitch_user_id: string; login: string; status: string; }
interface TokenRow { twitch_account_id: string; access_token_enc: string; refresh_token_enc: string; expires_at: string; }

/** Returns a valid user access token, refreshing it if it expires within 5 minutes. */
async function userToken(env: Env, db: Supa, userId: string): Promise<{ token: string; account: AccountRow }> {
  const [account] = await db.select<AccountRow>('twitch_accounts', `user_id=eq.${userId}&status=eq.active&order=created_at.asc&limit=1`);
  if (!account) throw new TwitchError(409, 'No active Twitch account connected');
  const [tok] = await db.select<TokenRow>('twitch_tokens', `twitch_account_id=eq.${account.id}`);
  if (!tok) throw new TwitchError(409, 'Twitch token missing — reconnect Twitch');
  if (new Date(tok.expires_at).getTime() - Date.now() > 5 * 60_000) {
    return { token: await decryptToken(tok.access_token_enc, env.TOKEN_ENCRYPTION_KEY), account };
  }
  try {
    const fresh = await refreshUserToken(env.TWITCH_CLIENT_ID, env.TWITCH_CLIENT_SECRET, await decryptToken(tok.refresh_token_enc, env.TOKEN_ENCRYPTION_KEY));
    await db.update('twitch_tokens', `twitch_account_id=eq.${account.id}`, {
      access_token_enc: await encryptToken(fresh.access_token, env.TOKEN_ENCRYPTION_KEY),
      refresh_token_enc: await encryptToken(fresh.refresh_token, env.TOKEN_ENCRYPTION_KEY),
      expires_at: new Date(Date.now() + fresh.expires_in * 1000).toISOString(),
    });
    return { token: fresh.access_token, account };
  } catch (e) {
    await db.update('twitch_accounts', `id=eq.${account.id}`, { status: 'expired', last_error: String((e as Error).message) });
    await db.insert('notifications', { user_id: userId, kind: 'connection_expired', title: 'Twitch connection expired', body: 'Reconnect Twitch in Settings to keep clipping.', link: '#/settings' });
    throw new TwitchError(401, 'Twitch connection expired — reconnect in Settings');
  }
}

// ───────────────────────────────────────── routes
export default {
  async fetch(req: Request, env: Env): Promise<Response> {
    const url = new URL(req.url);
    if (req.method === 'OPTIONS') return new Response(null, { headers: cors(env) });
    const db = new Supa(env);

    try {
      // Health (public)
      if (url.pathname === '/api/health') {
        const missing = (['TWITCH_CLIENT_ID', 'TWITCH_CLIENT_SECRET', 'TWITCH_REDIRECT_URI', 'SUPABASE_URL', 'SUPABASE_SERVICE_ROLE_KEY', 'TOKEN_ENCRYPTION_KEY', 'OAUTH_STATE_SECRET', 'APP_URL'] as const)
          .filter((k) => !env[k]);
        return json(env, { ok: missing.length === 0, version: VERSION, missing });
      }

      // OAuth callback — Twitch redirects the browser here (no JWT; identity comes from signed state)
      if (url.pathname === '/api/twitch/callback') return twitchCallback(url, env, db);

      // Everything below requires a logged-in Supabase user
      const user = await requireUser(req, db);
      if (!user) return fail(env, 401, 'unauthorized', 'Sign in first');

      if (url.pathname === '/api/twitch/connect' && req.method === 'GET') {
        const ts = Date.now().toString();
        const nonce = crypto.randomUUID();
        const payload = `${user.id}.${ts}.${nonce}`;
        const state = `${payload}.${await hmac(payload, env.OAUTH_STATE_SECRET)}`;
        const auth = new URL('https://id.twitch.tv/oauth2/authorize');
        auth.search = new URLSearchParams({
          client_id: env.TWITCH_CLIENT_ID,
          redirect_uri: env.TWITCH_REDIRECT_URI,
          response_type: 'code',
          scope: [TWITCH_SCOPES.createClips, TWITCH_SCOPES.readChat].join(' '),
          state,
          force_verify: 'true',
        }).toString();
        return json(env, { url: auth.toString() });
      }

      if (url.pathname === '/api/twitch/accounts' && req.method === 'GET') {
        const rows = await db.select('twitch_accounts', `user_id=eq.${user.id}&select=id,twitch_user_id,login,display_name,profile_image_url,scopes,status,last_error,created_at`);
        return json(env, { data: rows });
      }

      const del = url.pathname.match(/^\/api\/twitch\/accounts\/([0-9a-f-]{36})$/);
      if (del && req.method === 'DELETE') {
        const [acc] = await db.select<AccountRow>('twitch_accounts', `id=eq.${del[1]}&user_id=eq.${user.id}`);
        if (!acc) return fail(env, 404, 'not_found', 'Account not found');
        const [tok] = await db.select<TokenRow>('twitch_tokens', `twitch_account_id=eq.${acc.id}`);
        if (tok) { try { await revokeToken(env.TWITCH_CLIENT_ID, await decryptToken(tok.access_token_enc, env.TOKEN_ENCRYPTION_KEY)); } catch { /* best effort */ } }
        await db.remove('twitch_accounts', `id=eq.${acc.id}&user_id=eq.${user.id}`);
        return json(env, { ok: true });
      }

      if (url.pathname === '/api/twitch/search' && req.method === 'GET') {
        const q = (url.searchParams.get('q') ?? '').trim();
        if (q.length < 2 || q.length > 50) return fail(env, 400, 'bad_query', 'Search needs 2–50 characters');
        const r = await helix<{ data: TwitchChannelSearch[] }>({ clientId: env.TWITCH_CLIENT_ID, token: await app(env) }, `/search/channels?first=12&query=${encodeURIComponent(q)}`);
        return json(env, { data: r.data });
      }

      if (url.pathname === '/api/twitch/users' && req.method === 'GET') {
        const logins = (url.searchParams.get('logins') ?? '').split(',').filter((l) => LOGIN_RE.test(l)).slice(0, 100);
        if (!logins.length) return json(env, { data: [] });
        const r = await helix<{ data: TwitchUser[] }>({ clientId: env.TWITCH_CLIENT_ID, token: await app(env) }, `/users?${logins.map((l) => `login=${l}`).join('&')}`);
        return json(env, { data: r.data });
      }

      if (url.pathname === '/api/twitch/streams' && req.method === 'GET') {
        const ids = (url.searchParams.get('ids') ?? '').split(',').filter((i) => ID_RE.test(i)).slice(0, 100);
        if (!ids.length) return json(env, { data: [] });
        const r = await helix<{ data: TwitchStream[] }>({ clientId: env.TWITCH_CLIENT_ID, token: await app(env) }, `/streams?${ids.map((i) => `user_id=${i}`).join('&')}`);
        return json(env, { data: r.data });
      }

      // Create a native Twitch clip
      if (url.pathname === '/api/clips' && req.method === 'POST') {
        const body = (await req.json().catch(() => ({}))) as { broadcaster_id?: string; streamer_id?: string; title?: string; duration?: number; type?: 'manual' | 'auto'; detection_event_id?: string; score?: number };
        if (!body.broadcaster_id || !ID_RE.test(body.broadcaster_id)) return fail(env, 400, 'bad_request', 'broadcaster_id required');
        const title = body.title?.trim().slice(0, 100) || undefined;
        const duration = body.duration && Number.isFinite(body.duration) ? Math.round(body.duration) : undefined;
        const { token } = await userToken(env, db, user.id);
        const created = await createClip({ clientId: env.TWITCH_CLIENT_ID, token }, body.broadcaster_id, { title, duration });
        const [row] = await db.insert<{ id: string }>('clips', {
          user_id: user.id,
          streamer_id: body.streamer_id ?? null,
          twitch_clip_id: created.id,
          edit_url: created.edit_url,
          title: title ?? null,
          type: body.type === 'auto' ? 'auto' : 'manual',
          detection_score: body.score ?? null,
          detection_event_id: body.detection_event_id ?? null,
          status: 'processing',
        }, { upsertOn: 'user_id,twitch_clip_id' });
        return json(env, { data: { clip_id: row.id, twitch_clip_id: created.id, edit_url: created.edit_url } }, 202);
      }

      // Confirm a clip (call ~15 s after creation, poll a few times)
      const chk = url.pathname.match(/^\/api\/clips\/([0-9a-f-]{36})\/confirm$/);
      if (chk && req.method === 'POST') {
        const [row] = await db.select<{ id: string; twitch_clip_id: string; created_at: string; streamer_login: string | null }>('clips', `id=eq.${chk[1]}&user_id=eq.${user.id}`);
        if (!row?.twitch_clip_id) return fail(env, 404, 'not_found', 'Clip not found');
        const clip = await getClip({ clientId: env.TWITCH_CLIENT_ID, token: await app(env) }, row.twitch_clip_id);
        if (clip) {
          await db.update('clips', `id=eq.${row.id}`, { status: 'ready', url: clip.url, thumbnail_url: clip.thumbnail_url, duration_sec: clip.duration, streamer_login: clip.broadcaster_name, title: clip.title });
          await db.insert('notifications', { user_id: user.id, kind: 'clip_created', title: 'Clip created', body: clip.title, link: '#/library' });
          return json(env, { data: { status: 'ready', clip } });
        }
        const age = Date.now() - new Date(row.created_at).getTime();
        if (age > 60_000) {
          await db.update('clips', `id=eq.${row.id}`, { status: 'failed', error: 'Twitch did not confirm the clip within 60 s (stream offline, clipping disabled, or processing failed).' });
          await db.insert('notifications', { user_id: user.id, kind: 'clip_failed', title: 'Clip creation failed', body: 'Twitch did not confirm the clip.', link: '#/library' });
          return json(env, { data: { status: 'failed' } });
        }
        return json(env, { data: { status: 'processing' } });
      }

      return fail(env, 404, 'not_found', 'Unknown endpoint');
    } catch (e) {
      if (e instanceof TwitchError) return fail(env, e.status === 429 ? 429 : e.status >= 500 ? 502 : e.status, 'twitch_error', e.message, { retry_after: e.retryAfterSec });
      console.error('worker error', e);
      return fail(env, 500, 'internal', 'Unexpected server error');
    }
  },
};

async function twitchCallback(url: URL, env: Env, db: Supa): Promise<Response> {
  const back = (status: string) => Response.redirect(`${env.APP_URL}/#/settings?twitch=${status}`, 302);
  if (url.searchParams.get('error')) return back('denied');
  const code = url.searchParams.get('code');
  const state = url.searchParams.get('state') ?? '';
  const parts = state.split('.');
  if (!code || parts.length !== 4) return back('invalid');
  const [userId, ts, nonce, sig] = parts;
  const expected = await hmac(`${userId}.${ts}.${nonce}`, env.OAUTH_STATE_SECRET);
  if (!timingSafeEqual(sig, expected) || Date.now() - Number(ts) > 10 * 60_000) return back('expired');

  const tok = await exchangeCode(env.TWITCH_CLIENT_ID, env.TWITCH_CLIENT_SECRET, code, env.TWITCH_REDIRECT_URI);
  const me = await helix<{ data: TwitchUser[] }>({ clientId: env.TWITCH_CLIENT_ID, token: tok.access_token }, '/users');
  const tu = me.data[0];
  const [acc] = await db.insert<{ id: string }>('twitch_accounts', {
    user_id: userId, twitch_user_id: tu.id, login: tu.login, display_name: tu.display_name,
    profile_image_url: tu.profile_image_url, scopes: tok.scope, status: 'active', last_error: null,
  }, { upsertOn: 'user_id,twitch_user_id' });
  await db.insert('twitch_tokens', {
    twitch_account_id: acc.id,
    access_token_enc: await encryptToken(tok.access_token, env.TOKEN_ENCRYPTION_KEY),
    refresh_token_enc: await encryptToken(tok.refresh_token, env.TOKEN_ENCRYPTION_KEY),
    expires_at: new Date(Date.now() + tok.expires_in * 1000).toISOString(),
  }, { upsertOn: 'twitch_account_id' });
  return back('connected');
}
