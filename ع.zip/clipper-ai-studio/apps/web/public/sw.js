// WESS service worker — notification taps open the live stream on Twitch.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const url = (event.notification.data && event.notification.data.url) || 'https://www.twitch.tv/';
  if (!/^https:\/\/www\.twitch\.tv\/[a-z0-9_]{3,25}$/.test(url)) return;
  event.waitUntil(self.clients.openWindow(url));
});
