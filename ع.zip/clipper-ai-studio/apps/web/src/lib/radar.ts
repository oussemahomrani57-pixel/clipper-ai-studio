/**
 * WESS Radar — watches up to 30 Twitch chats at once (one anonymous read-only connection),
 * scores each channel every second with the shared MomentDetector, and fires a "CLIP IT!"
 * alert (sound + impact screen + phone notification) when chat explodes.
 */
import { useSyncExternalStore } from 'react';
import { MomentDetector, type Evaluation } from '@shared/scoring.ts';
import { BrowserChat, type ChatState } from './chat.ts';
import { actions, getApp, type Moment } from './store.ts';
import { playImpact } from './sound.ts';
import { showMomentNotification } from './notify.ts';
import { fetchAvatar, fetchLive } from './twitch.ts';

const BUCKET_MS = 5_000;
const BUCKETS = 36; // 3 minutes of history

export interface Channel {
  login: string;
  buckets: number[];
  bi: number;
  mpm: number; // messages in the last minute
  score: number;
  heat: number; // smoothed 0..1 for visuals
  reasons: string[];
  blocked: Evaluation['blockedBy'];
  lastMsgAt: number;
  lastAlertAt: number;
  live: boolean | null;
  avatar: string | null;
}

export interface RadarSnap {
  running: boolean;
  chat: ChatState;
  channels: Record<string, Channel>;
  totalMpm: number;
  impact: Moment | null; // moment currently shown full-screen
  pausedGapSec: number; // >0 when the phone suspended WESS
}

const chat = new BrowserChat();
const detectors = new Map<string, MomentDetector>();
let snap: RadarSnap = { running: false, chat: 'idle', channels: {}, totalMpm: 0, impact: null, pausedGapSec: 0 };
let timer: ReturnType<typeof setInterval> | null = null;
let liveTimer: ReturnType<typeof setInterval> | null = null;
let lastTick = 0;
let wake: { release: () => Promise<void> } | null = null;
const ls = new Set<() => void>();
const emit = () => { snap = { ...snap }; ls.forEach((l) => l()); };

export const useRadar = () => useSyncExternalStore((cb) => { ls.add(cb); return () => ls.delete(cb); }, () => snap);

chat.onState = (s) => { snap.chat = s; emit(); };
chat.onMessage = (m) => {
  const c = snap.channels[m.channel];
  if (!c) return;
  detectors.get(m.channel)?.addMessage({ ts: m.ts, userId: m.userId, text: m.text });
  c.buckets[c.buckets.length - 1]++;
  c.lastMsgAt = m.ts;
};

function detectorConfig() {
  const s = getApp().settings;
  return { minScore: s.threshold, sensitivity: s.sensitivity, cooldownSec: s.cooldownSec, maxPerHour: 60, maxPerDay: 1000, minMessagesInWindow: 5 };
}

function newChannel(login: string): Channel {
  return { login, buckets: Array(BUCKETS).fill(0), bi: Math.floor(Date.now() / BUCKET_MS), mpm: 0, score: 0, heat: 0, reasons: [], blocked: null, lastMsgAt: 0, lastAlertAt: 0, live: null, avatar: null };
}

function fire(c: Channel, e: Evaluation) {
  const s = getApp().settings;
  const m: Moment = { id: crypto.randomUUID(), login: c.login, score: e.score, reasons: e.reasons, ts: Date.now(), opened: false };
  c.lastAlertAt = m.ts;
  actions.addMoment(m);
  snap.impact = m;
  if (s.sound) playImpact(s.volume);
  try { navigator.vibrate?.([60, 40, 120]); } catch { /* iOS: no vibration API */ }
  if (s.systemNotifications) void showMomentNotification(c.login, e.score, e.reasons[0]);
}

function tick() {
  const now = Date.now();
  if (lastTick && now - lastTick > 15_000) snap.pausedGapSec = Math.round((now - lastTick) / 1000);
  lastTick = now;
  const bi = Math.floor(now / BUCKET_MS);
  const cfg = detectorConfig();
  let total = 0;
  for (const c of Object.values(snap.channels)) {
    if (c.bi < bi) { const shift = Math.min(BUCKETS, bi - c.bi); c.buckets = [...c.buckets.slice(shift), ...Array(shift).fill(0)]; c.bi = bi; }
    c.mpm = c.buckets.slice(-12).reduce((a, b) => a + b, 0);
    total += c.mpm;
    const d = detectors.get(c.login)!;
    Object.assign(d.config, cfg);
    const e = d.evaluate(now);
    c.score = e.score; c.reasons = e.reasons; c.blocked = e.blockedBy;
    c.heat = c.heat * 0.7 + (e.score / 100) * 0.3;
    if (e.shouldTrigger) { d.markTriggered(now); fire(c, e); }
  }
  snap.totalMpm = total;
  emit();
}

async function refreshInfo() {
  for (const c of Object.values(snap.channels)) {
    if (!c.avatar) c.avatar = await fetchAvatar(c.login);
    const live = await fetchLive(c.login);
    if (live !== null) c.live = live;
    await new Promise((r) => setTimeout(r, 250)); // be gentle with the free service
  }
  emit();
}

async function keepAwake(on: boolean) {
  try {
    if (on && !wake && document.visibilityState === 'visible') {
      const nav = navigator as unknown as { wakeLock?: { request: (t: 'screen') => Promise<{ release: () => Promise<void>; addEventListener: (e: string, f: () => void) => void }> } };
      const w = await nav.wakeLock?.request('screen');
      if (w) { wake = w; w.addEventListener('release', () => { wake = null; }); }
    } else if (!on && wake) { await wake.release(); wake = null; }
  } catch { /* not supported / denied */ }
}

document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible' && snap.running) {
    void keepAwake(getApp().settings.keepAwake);
    if (snap.chat !== 'connected') chat.start();
  }
});

export const radar = {
  /** Sync watched channels with the saved streamer list. */
  sync() {
    const logins = getApp().streamers;
    const next: Record<string, Channel> = {};
    for (const l of logins) {
      next[l] = snap.channels[l] ?? newChannel(l);
      if (!detectors.has(l)) detectors.set(l, new MomentDetector(detectorConfig()));
    }
    for (const l of detectors.keys()) if (!logins.includes(l)) detectors.delete(l);
    snap.channels = next;
    if (snap.running) { chat.setChannels(logins); void refreshInfo(); }
    emit();
  },
  start() {
    if (!getApp().streamers.length) return;
    snap.running = true; snap.pausedGapSec = 0; lastTick = 0;
    radar.sync();
    chat.setChannels(getApp().streamers);
    timer ??= setInterval(tick, 1000);
    liveTimer ??= setInterval(() => void refreshInfo(), 180_000);
    void refreshInfo();
    void keepAwake(getApp().settings.keepAwake);
    emit();
  },
  stop() {
    snap.running = false;
    chat.stop();
    if (timer) clearInterval(timer); timer = null;
    if (liveTimer) clearInterval(liveTimer); liveTimer = null;
    void keepAwake(false);
    emit();
  },
  dismissImpact() { snap.impact = null; emit(); },
  clearGap() { snap.pausedGapSec = 0; emit(); },
  /** Test the full alert chain without waiting for a real moment. */
  test(login?: string) {
    const c = snap.channels[login ?? getApp().streamers[0]] ?? newChannel(login ?? getApp().streamers[0] ?? 'twitch');
    fire(c, { score: 88, reasons: ['TEST — this is how a real alert looks'], ts: Date.now() } as Evaluation);
    emit();
  },
  keepAwake,
};
