/** Synthesized anime-style sounds (no audio files). iOS requires unlock() inside a tap. */
let ctx: AudioContext | null = null;

export function unlockAudio() {
  try {
    ctx ??= new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    if (ctx.state === 'suspended') void ctx.resume();
    // play a silent buffer: required by iOS to fully unlock
    const b = ctx.createBuffer(1, 1, 22050); const s = ctx.createBufferSource(); s.buffer = b; s.connect(ctx.destination); s.start(0);
  } catch { /* audio unsupported */ }
}

function noise(c: AudioContext, dur: number) {
  const b = c.createBuffer(1, Math.floor(c.sampleRate * dur), c.sampleRate);
  const d = b.getChannelData(0);
  for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / d.length);
  const s = c.createBufferSource(); s.buffer = b; return s;
}

/** Katana slash: filtered noise sweep. */
export function playSlash(volume = 0.6) {
  if (!ctx) return;
  const c = ctx; const t = c.currentTime;
  const n = noise(c, 0.35); const f = c.createBiquadFilter(); f.type = 'bandpass'; f.Q.value = 3;
  f.frequency.setValueAtTime(800, t); f.frequency.exponentialRampToValueAtTime(7000, t + 0.25);
  const g = c.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(volume * 0.5, t + 0.03); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.33);
  n.connect(f).connect(g).connect(c.destination); n.start(t);
}

/** Impact for a clip moment: sub boom + slash + icy shimmer. */
export function playImpact(volume = 0.8) {
  if (!ctx) return;
  const c = ctx; const t = c.currentTime;
  const o = c.createOscillator(); o.type = 'sine';
  o.frequency.setValueAtTime(140, t); o.frequency.exponentialRampToValueAtTime(38, t + 0.45);
  const g = c.createGain(); g.gain.setValueAtTime(volume, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.6);
  o.connect(g).connect(c.destination); o.start(t); o.stop(t + 0.62);
  playSlash(volume);
  [1318.5, 1975.5, 2637].forEach((fr, i) => {
    const p = c.createOscillator(); p.type = 'triangle'; p.frequency.value = fr;
    const pg = c.createGain(); const st = t + 0.12 + i * 0.07;
    pg.gain.setValueAtTime(0.0001, st); pg.gain.exponentialRampToValueAtTime(volume * 0.18, st + 0.01); pg.gain.exponentialRampToValueAtTime(0.0001, st + 0.5);
    p.connect(pg).connect(c.destination); p.start(st); p.stop(st + 0.52);
  });
}

/** Soft UI blip on taps. */
export function playTap(volume = 0.25) {
  if (!ctx) return;
  const c = ctx; const t = c.currentTime;
  const o = c.createOscillator(); o.type = 'sine'; o.frequency.setValueAtTime(880, t); o.frequency.exponentialRampToValueAtTime(1500, t + 0.06);
  const g = c.createGain(); g.gain.setValueAtTime(volume * 0.15, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.09);
  o.connect(g).connect(c.destination); o.start(t); o.stop(t + 0.1);
}
