/** Open a stream in the Twitch app (falls back to the website) + light public channel info. */

export const twitchUrl = (login: string) => `https://www.twitch.tv/${login}`;

const isMobile = () => /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);

/**
 * Opens the live stream. On a phone we try the Twitch app first (twitch:// link);
 * if the app isn't installed we fall back to twitch.tv, which also hands off to the app
 * through universal links when possible.
 */
export function openTwitch(login: string) {
  const web = twitchUrl(login);
  if (!isMobile()) { window.open(web, '_blank', 'noopener'); return; }
  const started = Date.now();
  window.location.href = `twitch://stream/${login}`;
  setTimeout(() => {
    if (document.visibilityState === 'visible' && Date.now() - started < 2500) window.location.href = web;
  }, 1200);
}

// ── Public channel info via decapi.me (free, no key). Optional: failures are silent.
const AVATAR_KEY = 'wess.avatars';
let avatars: Record<string, string> = {};
try { avatars = JSON.parse(localStorage.getItem(AVATAR_KEY) ?? '{}'); } catch { /* ignore */ }

export async function fetchAvatar(login: string): Promise<string | null> {
  if (avatars[login]) return avatars[login];
  try {
    const r = await fetch(`https://decapi.me/twitch/avatar/${login}`);
    const t = (await r.text()).trim();
    if (!r.ok || !/^https:\/\/static-cdn\.jtvnw\.net\//.test(t)) return null;
    avatars[login] = t;
    try { localStorage.setItem(AVATAR_KEY, JSON.stringify(avatars)); } catch { /* ignore */ }
    return t;
  } catch { return null; }
}

/** true = live, false = offline, null = unknown (service unreachable). */
export async function fetchLive(login: string): Promise<boolean | null> {
  try {
    const r = await fetch(`https://decapi.me/twitch/uptime/${login}`);
    if (!r.ok) return null;
    const t = (await r.text()).toLowerCase();
    if (t.includes('offline')) return false;
    if (/\d+\s*(second|minute|hour)/.test(t)) return true;
    return null;
  } catch { return null; }
}
