/**
 * Phone / system notifications. Tapping one opens the stream on Twitch (handled in public/sw.js).
 * iPhone: works for WESS added to the Home Screen (iOS 16.4+), and only while WESS is running —
 * without a 24/7 server, iOS pauses web apps in the background.
 */
export const notifySupported = () => 'Notification' in window && 'serviceWorker' in navigator;
export const notifyPermission = () => (notifySupported() ? Notification.permission : 'unsupported');
export const isStandalone = () => window.matchMedia('(display-mode: standalone)').matches || (navigator as unknown as { standalone?: boolean }).standalone === true;
export const isIOS = () => /iPhone|iPad|iPod/i.test(navigator.userAgent);

export async function registerSW() {
  if (!('serviceWorker' in navigator)) return;
  try { await navigator.serviceWorker.register('./sw.js', { scope: './' }); } catch { /* not available (e.g. preview) */ }
}

export async function requestNotifications(): Promise<NotificationPermission | 'unsupported'> {
  if (!notifySupported()) return 'unsupported';
  try { return await Notification.requestPermission(); } catch { return 'denied'; }
}

export async function showMomentNotification(login: string, score: number, reason?: string) {
  if (notifyPermission() !== 'granted') return false;
  try {
    const reg = await navigator.serviceWorker.ready;
    await reg.showNotification(`🔥 CLIP IT! — ${login}`, {
      body: `Score ${score}${reason ? ` · ${reason}` : ''}\nTap to open the live on Twitch`,
      tag: `wess-${login}`,
      icon: './icon-192.png',
      badge: './icon-192.png',
      data: { url: `https://www.twitch.tv/${login}` },
    } as NotificationOptions);
    return true;
  } catch { return false; }
}
