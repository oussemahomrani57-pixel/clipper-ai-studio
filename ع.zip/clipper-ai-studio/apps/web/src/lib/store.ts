/** WESS app state: streamers, settings, moments. Persisted on this device (localStorage). */
import { useSyncExternalStore } from 'react';
import type { Sensitivity } from '@shared/scoring.ts';

export const MAX_CHANNELS = 30;

export interface Settings {
  threshold: number; // alert when the viral score reaches this (0-100)
  sensitivity: Sensitivity;
  cooldownSec: number; // per streamer
  sound: boolean;
  volume: number; // 0..1
  systemNotifications: boolean;
  keepAwake: boolean;
  reduceMotion: boolean;
}

export interface Moment {
  id: string;
  login: string;
  score: number;
  reasons: string[];
  ts: number;
  opened: boolean;
}

export interface State {
  streamers: string[]; // twitch logins
  settings: Settings;
  moments: Moment[];
}

const KEY = 'wess.v1';
export const DEFAULT_SETTINGS: Settings = {
  threshold: 60,
  sensitivity: 'medium',
  cooldownSec: 90,
  sound: true,
  volume: 0.8,
  systemNotifications: false,
  keepAwake: true,
  reduceMotion: false,
};

function load(): State {
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) ?? 'null') as Partial<State> | null;
    if (raw) return { streamers: raw.streamers ?? [], settings: { ...DEFAULT_SETTINGS, ...raw.settings }, moments: raw.moments ?? [] };
  } catch { /* storage unavailable or corrupted */ }
  return { streamers: [], settings: DEFAULT_SETTINGS, moments: [] };
}

let state: State = load();
const ls = new Set<() => void>();

function set(next: Partial<State>) {
  state = { ...state, ...next };
  try { localStorage.setItem(KEY, JSON.stringify(state)); } catch { /* private mode */ }
  ls.forEach((l) => l());
}

export const useApp = <T,>(sel: (s: State) => T) => useSyncExternalStore((cb) => { ls.add(cb); return () => ls.delete(cb); }, () => sel(state));
export const getApp = () => state;

export const LOGIN_RE = /^[a-z0-9_]{3,25}$/;

export const actions = {
  /** Add one or many logins ("a, b c" or twitch.tv/x links). Returns {added, invalid, full}. */
  addStreamers(input: string) {
    const parts = input.split(/[\s,;]+/).map((p) => p.trim().toLowerCase().replace(/^@/, '').replace(/^(https?:\/\/)?(www\.|m\.)?twitch\.tv\//, '').split(/[/?#]/)[0]).filter(Boolean);
    const added: string[] = []; const invalid: string[] = []; let full = false;
    const list = [...state.streamers];
    for (const p of parts) {
      if (!LOGIN_RE.test(p)) { invalid.push(p); continue; }
      if (list.includes(p)) continue;
      if (list.length >= MAX_CHANNELS) { full = true; break; }
      list.push(p); added.push(p);
    }
    set({ streamers: list });
    return { added, invalid, full };
  },
  removeStreamer(login: string) { set({ streamers: state.streamers.filter((s) => s !== login) }); },
  saveSettings(p: Partial<Settings>) { set({ settings: { ...state.settings, ...p } }); },
  addMoment(m: Moment) { set({ moments: [m, ...state.moments].slice(0, 100) }); },
  markOpened(id: string) { set({ moments: state.moments.map((m) => (m.id === id ? { ...m, opened: true } : m)) }); },
  clearMoments() { set({ moments: [] }); },
};
