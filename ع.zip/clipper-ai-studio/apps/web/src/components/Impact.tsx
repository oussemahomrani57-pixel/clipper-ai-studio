import { useEffect } from 'react';
import type { Moment } from '../lib/store.ts';
import { actions } from '../lib/store.ts';
import { openTwitch } from '../lib/twitch.ts';

/** Full-screen manga impact frame: flash, speed lines, "CLIP IT!", one big button to the live. */
export function Impact({ m, onClose }: { m: Moment; onClose: () => void }) {
  useEffect(() => {
    document.getElementById('root')?.animate([
      { transform: 'translate(0,0)' }, { transform: 'translate(-8px,5px)' }, { transform: 'translate(7px,-6px)' }, { transform: 'translate(-5px,-3px)' }, { transform: 'translate(0,0)' },
    ], { duration: 420 });
    const t = setTimeout(onClose, 12_000);
    return () => clearTimeout(t);
  }, [m.id, onClose]);

  const go = () => { actions.markOpened(m.id); onClose(); openTwitch(m.login); };

  return (
    <div className="fixed inset-0 z-[90] grid place-items-center overflow-hidden" role="alertdialog" aria-label={`Clip moment on ${m.login}`}>
      <div className="absolute inset-0 bg-void/80 backdrop-blur-sm" onClick={onClose} />
      <div className="absolute inset-[-20%] speedlines pointer-events-none" />
      <div className="absolute inset-0 bg-white pointer-events-none" style={{ animation: 'flash .35s ease-out forwards' }} />
      <div className="absolute left-1/2 top-1/2 h-1 w-[200vmax] -translate-x-1/2 -translate-y-1/2 pointer-events-none" style={{ animation: 'slash-cut .5s cubic-bezier(.6,0,.2,1) both', background: 'linear-gradient(90deg,transparent,#d4f8ff 45%,#fff 50%,#b9a0ff 55%,transparent)', boxShadow: '0 0 24px #7ee8ff' }} />

      <div className="relative flex flex-col items-center text-center px-6">
        <div className="jp text-ice text-sm tracking-[.8em] mb-2" style={{ animation: 'letter-in .4s .15s both' }}>今だ！</div>
        <div className="clip-it text-[24vw] sm:text-[150px] leading-none">CLIP IT!</div>
        <div className="mt-5 flex items-center gap-3" style={{ animation: 'letter-in .45s .3s both' }}>
          <span className="text-2xl font-bold">{m.login}</span>
          <span className="px-2.5 py-1 rounded-lg bg-ice/15 border border-ice/40 text-ice-soft font-bold tabular-nums">⚡ {m.score}</span>
        </div>
        {m.reasons[0] && <p className="mt-2 text-mist text-sm max-w-xs" style={{ animation: 'letter-in .45s .38s both' }}>{m.reasons[0]}</p>}
        <button onClick={go} className="btn-ice mt-8 h-16 px-9 rounded-2xl text-lg tracking-wider flex items-center gap-3" style={{ animation: 'letter-in .45s .45s both' }}>
          <svg viewBox="0 0 24 24" className="size-6" fill="currentColor"><path d="M4 3 3 7v12h4v3h3l3-3h4l5-5V3zm16 10-3 3h-4l-3 3v-3H6V5h14zM11 7h2v5h-2zm5 0h2v5h-2z" /></svg>
          OPEN IN TWITCH
        </button>
        <button onClick={onClose} className="mt-4 text-mist text-sm tracking-widest uppercase" style={{ animation: 'letter-in .45s .5s both' }}>Later</button>
      </div>
    </div>
  );
}
