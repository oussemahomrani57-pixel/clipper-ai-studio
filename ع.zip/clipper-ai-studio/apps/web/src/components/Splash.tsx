import { useEffect, useState } from 'react';
import { playSlash, unlockAudio } from '../lib/sound.ts';

/** Opening scene: a katana slash cuts the screen, WESS ignites. The tap also unlocks sound on iPhone. */
export function Splash({ onEnter }: { onEnter: () => void }) {
  const [ready, setReady] = useState(false);
  const [leaving, setLeaving] = useState(false);
  useEffect(() => { const t = setTimeout(() => setReady(true), 1500); return () => clearTimeout(t); }, []);

  const enter = () => {
    if (leaving) return;
    unlockAudio(); playSlash(0.7);
    setLeaving(true);
    setTimeout(onEnter, 650);
  };

  return (
    <div className="fixed inset-0 z-[100] overflow-hidden select-none" onClick={enter} role="button" aria-label="Enter WESS">
      {/* two halves split apart after the slash */}
      <div className="absolute inset-0 bg-void" style={{ clipPath: 'polygon(0 0, 100% 0, 100% 38%, 0 72%)', animation: leaving ? 'split-top .65s cubic-bezier(.7,0,.3,1) forwards' : undefined }}>
        <div className="absolute inset-0" style={{ background: 'radial-gradient(80% 60% at 30% 20%, rgba(139,92,255,.35), transparent 60%)' }} />
      </div>
      <div className="absolute inset-0 bg-void" style={{ clipPath: 'polygon(0 72%, 100% 38%, 100% 100%, 0 100%)', animation: leaving ? 'split-bottom .65s cubic-bezier(.7,0,.3,1) forwards' : undefined }}>
        <div className="absolute inset-0" style={{ background: 'radial-gradient(80% 60% at 70% 90%, rgba(126,232,255,.22), transparent 60%)' }} />
      </div>

      {/* katana slash */}
      <div className="absolute left-1/2 top-1/2 h-[3px] w-[160vmax] -translate-x-1/2 -translate-y-1/2" style={{ animation: 'slash-cut .7s .25s cubic-bezier(.6,0,.2,1) both' }}>
        <div className="h-full w-full" style={{ background: 'linear-gradient(90deg, transparent, #d4f8ff 40%, #fff 50%, #b9a0ff 60%, transparent)', boxShadow: '0 0 20px #7ee8ff, 0 0 60px #8b5cff' }} />
      </div>

      <div className={`absolute inset-0 flex flex-col items-center justify-center transition-opacity duration-300 ${leaving ? 'opacity-0' : ''}`}>
        <div className="jp text-ice/60 text-sm tracking-[1em] mb-4" style={{ animation: 'letter-in .6s .9s both' }}>瞬間を斬れ</div>
        <h1 className="flex text-[22vw] sm:text-[150px] leading-none">
          {'WESS'.split('').map((l, i) => (
            <span key={i} className="brand" style={{ animation: `letter-in .55s ${0.75 + i * 0.09}s cubic-bezier(.2,1.2,.4,1) both, shimmer-sweep 4.5s linear infinite` }}>{l}</span>
          ))}
        </h1>
        <div className="mt-3 text-mist text-[13px] tracking-[.5em] uppercase" style={{ animation: 'letter-in .6s 1.2s both' }}>Stream radar · Clip moments</div>
        <div className={`mt-16 text-ice-soft text-sm tracking-[.4em] uppercase transition-opacity duration-500 ${ready ? 'opacity-100' : 'opacity-0'}`} style={{ animation: ready ? 'pulse-glow 1.6s ease-in-out infinite' : undefined }}>
          ▸ Tap to enter
        </div>
      </div>
    </div>
  );
}
