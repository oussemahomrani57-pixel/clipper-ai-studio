import { useEffect, type ReactNode } from 'react';

/** Bottom sheet (phone) / centered panel (desktop) with a slide-in animation. */
export function Sheet({ open, onClose, title, children }: { open: boolean; onClose: () => void; title: string; children: ReactNode }) {
  useEffect(() => {
    if (!open) return;
    const k = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center">
      <div className="absolute inset-0 bg-void/75 backdrop-blur-sm" onClick={onClose} style={{ animation: 'float-up .25s both' }} />
      <div className="glass relative w-full sm:max-w-lg max-h-[88dvh] overflow-y-auto rounded-t-3xl sm:rounded-3xl p-5 safe-b" style={{ animation: 'float-up .35s cubic-bezier(.2,.9,.2,1) both' }} role="dialog" aria-modal="true">
        <div className="sm:hidden mx-auto -mt-1 mb-3 h-1 w-10 rounded-full bg-white/20" />
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-bold text-xl tracking-wide">{title}</h2>
          <button onClick={onClose} className="size-10 grid place-items-center rounded-xl btn-ghost text-mist" aria-label="Close">✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}
