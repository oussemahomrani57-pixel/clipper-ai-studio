import { useEffect, useRef } from 'react';

/** Living backdrop: violet/ice aurora + drifting ice shards (canvas) + occasional lightning. */
export function Background({ energy, reduce }: { energy: number; reduce: boolean }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const energyRef = useRef(energy);
  energyRef.current = energy;

  useEffect(() => {
    const c = ref.current!; const ctx = c.getContext('2d')!;
    let w = 0, h = 0, raf = 0;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const resize = () => { w = c.clientWidth; h = c.clientHeight; c.width = w * dpr; c.height = h * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0); };
    resize(); window.addEventListener('resize', resize);
    const N = reduce ? 18 : window.innerWidth < 700 ? 42 : 70;
    const parts = Array.from({ length: N }, () => ({ x: Math.random(), y: Math.random(), s: 0.6 + Math.random() * 2.2, v: 0.15 + Math.random() * 0.5, r: Math.random() * Math.PI, ice: Math.random() > 0.45 }));
    const draw = () => {
      ctx.clearRect(0, 0, w, h);
      const e = energyRef.current;
      for (const p of parts) {
        p.y -= (p.v * (1 + e * 3)) / h * 2.2; p.r += 0.01 + e * 0.04;
        if (p.y < -0.02) { p.y = 1.02; p.x = Math.random(); }
        const x = p.x * w + Math.sin(p.r * 2 + p.y * 6) * 8; const y = p.y * h; const s = p.s * (1 + e);
        ctx.save(); ctx.translate(x, y); ctx.rotate(p.r);
        ctx.fillStyle = p.ice ? `rgba(212,248,255,${0.35 + e * 0.5})` : `rgba(185,160,255,${0.3 + e * 0.4})`;
        ctx.shadowColor = p.ice ? '#7ee8ff' : '#8b5cff'; ctx.shadowBlur = 8 + e * 14;
        ctx.beginPath(); ctx.moveTo(0, -s * 2); ctx.lineTo(s * 0.7, 0); ctx.lineTo(0, s * 2); ctx.lineTo(-s * 0.7, 0); ctx.closePath(); ctx.fill();
        ctx.restore();
      }
      if (!reduce) raf = requestAnimationFrame(draw);
    };
    draw();
    return () => { cancelAnimationFrame(raf); window.removeEventListener('resize', resize); };
  }, [reduce]);

  return (
    <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none" aria-hidden>
      <div className="absolute inset-0" style={{ background: 'radial-gradient(120% 80% at 10% -10%, rgba(139,92,255,.38), transparent 55%), radial-gradient(90% 70% at 100% 110%, rgba(126,232,255,.22), transparent 60%), linear-gradient(180deg, #0d0920, #06040d 60%)' }} />
      <div className="absolute -top-1/3 left-1/2 h-[80vh] w-[80vh] -translate-x-1/2 rounded-full opacity-40" style={{ background: 'conic-gradient(from 0deg, transparent, rgba(139,92,255,.35), transparent 40%, rgba(126,232,255,.25), transparent 75%)', filter: 'blur(60px)', animation: reduce ? undefined : 'spin 40s linear infinite' }} />
      <canvas ref={ref} className="absolute inset-0 h-full w-full" />
      <div className="absolute inset-0 opacity-[.07]" style={{ backgroundImage: 'linear-gradient(rgba(212,248,255,.6) 1px, transparent 1px), linear-gradient(90deg, rgba(212,248,255,.6) 1px, transparent 1px)', backgroundSize: '48px 48px', maskImage: 'radial-gradient(ellipse at 50% 0%, #000, transparent 70%)', WebkitMaskImage: 'radial-gradient(ellipse at 50% 0%, #000, transparent 70%)' }} />
      {!reduce && <div className="bolt" />}
    </div>
  );
}
