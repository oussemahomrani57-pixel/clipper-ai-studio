import { useEffect, useRef, useState } from 'react';
import type { Channel } from '../lib/radar.ts';

/** One watched stream. Its aura, border speed and avatar ring all react to chat heat. */
export function StreamerCard({ c, threshold, running, onOpen }: { c: Channel; threshold: number; running: boolean; onOpen: () => void }) {
  const [hot, setHot] = useState(false);
  const last = useRef(c.lastAlertAt);
  useEffect(() => {
    if (c.lastAlertAt && c.lastAlertAt !== last.current) { last.current = c.lastAlertAt; setHot(true); const t = setTimeout(() => setHot(false), 500); return () => clearTimeout(t); }
  }, [c.lastAlertAt]);

  const heat = Math.min(1, c.heat * 1.15);
  const max = Math.max(4, ...c.buckets);
  const near = c.score >= threshold * 0.75;
  const active = running && Date.now() - c.lastMsgAt < 60_000;

  return (
    <button onClick={onOpen} className={`card glass text-left p-3 sm:p-4 w-full ${hot ? 'hot' : ''}`} style={{ ['--heat' as string]: heat }}>
      <div className="flex items-center gap-3">
        <div className="relative shrink-0">
          <div className="avatar-ring" />
          {c.avatar
            ? <img src={c.avatar} alt="" className="size-11 rounded-full object-cover" />
            : <div className="size-11 rounded-full grid place-items-center font-bold text-lg" style={{ background: 'linear-gradient(135deg,#8b5cff,#7ee8ff)' }}>{c.login[0].toUpperCase()}</div>}
          {c.live && <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 px-1.5 rounded bg-[#ff3b6b] text-[9px] font-bold tracking-wider">LIVE</span>}
        </div>
        <div className="min-w-0 flex-1">
          <div className="font-bold text-[15px] truncate leading-tight">{c.login}</div>
          <div className="text-[11px] text-mist tracking-wide">
            {!running ? 'radar off' : c.live === false ? 'offline' : active ? `${c.mpm} msg/min` : 'waiting for chat…'}
          </div>
        </div>
        <div className={`font-bold text-2xl tabular-nums leading-none ${near ? 'text-ice-soft' : 'text-violet-soft'}`} style={{ textShadow: near ? '0 0 14px #7ee8ff' : undefined }}>{running ? c.score : '–'}</div>
      </div>

      {/* chat activity bars (last 3 min) */}
      <div className="mt-3 flex items-end gap-[2px] h-9">
        {c.buckets.map((b, i) => (
          <span key={i} className="flex-1 rounded-sm" style={{ height: `${Math.max(6, (b / max) * 100)}%`, background: i > c.buckets.length - 4 ? 'linear-gradient(#d4f8ff,#7ee8ff)' : 'linear-gradient(#b9a0ff,#8b5cff)', opacity: 0.35 + (i / c.buckets.length) * 0.65, transition: 'height .4s' }} />
        ))}
      </div>

      {/* heat meter with threshold marker */}
      <div className="relative mt-2 h-1.5 rounded-full bg-white/10 overflow-hidden">
        <div className="h-full rounded-full transition-[width] duration-700" style={{ width: `${running ? c.score : 0}%`, background: 'linear-gradient(90deg,#8b5cff,#7ee8ff)', boxShadow: '0 0 10px #7ee8ff' }} />
        <span className="absolute top-0 h-full w-0.5 bg-ice-soft/80" style={{ left: `${threshold}%` }} />
      </div>
    </button>
  );
}
