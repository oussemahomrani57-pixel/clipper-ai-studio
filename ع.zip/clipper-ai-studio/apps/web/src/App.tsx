import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { Background } from './components/Background.tsx';
import { Splash } from './components/Splash.tsx';
import { StreamerCard } from './components/StreamerCard.tsx';
import { Impact } from './components/Impact.tsx';
import { Sheet } from './components/Sheet.tsx';
import { radar, useRadar } from './lib/radar.ts';
import { actions, MAX_CHANNELS, useApp } from './lib/store.ts';
import { playTap } from './lib/sound.ts';
import { isIOS, isStandalone, notifyPermission, notifySupported, registerSW, requestNotifications } from './lib/notify.ts';
import { openTwitch } from './lib/twitch.ts';

const ago = (ts: number) => { const s = (Date.now() - ts) / 1000; return s < 60 ? 'now' : s < 3600 ? `${Math.floor(s / 60)}m` : s < 86400 ? `${Math.floor(s / 3600)}h` : `${Math.floor(s / 86400)}d`; };

export default function App() {
  const [entered, setEntered] = useState(false);
  const [sheet, setSheet] = useState<null | 'add' | 'settings' | { login: string }>(null);
  const r = useRadar();
  const streamers = useApp((s) => s.streamers);
  const settings = useApp((s) => s.settings);
  const moments = useApp((s) => s.moments);
  const channels = streamers.map((l) => r.channels[l]).filter(Boolean);
  const energy = Math.min(1, Math.max(0, ...channels.map((c) => c.heat), 0) * 1.2);
  const closeImpact = useCallback(() => radar.dismissImpact(), []);

  useEffect(() => { void registerSW(); radar.sync(); }, []);
  useEffect(() => { radar.sync(); }, [streamers]);

  // energy ripple on every tap
  useEffect(() => {
    const down = (e: PointerEvent) => {
      const d = document.createElement('div'); d.className = 'ripple'; d.style.left = `${e.clientX}px`; d.style.top = `${e.clientY}px`;
      document.body.appendChild(d); setTimeout(() => d.remove(), 650);
      if (settings.sound && (e.target as HTMLElement).closest('button')) playTap(settings.volume);
    };
    window.addEventListener('pointerdown', down);
    return () => window.removeEventListener('pointerdown', down);
  }, [settings.sound, settings.volume]);

  const sorted = [...channels].sort((a, b) => b.score - a.score || b.mpm - a.mpm);
  const today = moments.filter((m) => Date.now() - m.ts < 86_400_000).length;

  return (
    <div className={settings.reduceMotion ? 'reduce-motion' : ''}>
      <Background energy={r.running ? energy : 0} reduce={settings.reduceMotion} />
      {!entered && <Splash onEnter={() => setEntered(true)} />}

      {/* header */}
      <header className="sticky top-0 z-40 safe-t bg-void/60 backdrop-blur-xl border-b border-violet/15">
        <div className="mx-auto max-w-6xl h-16 px-4 flex items-center gap-3">
          <div className="brand text-2xl">WESS</div>
          <div className={`ml-1 flex items-center gap-1.5 px-2.5 h-7 rounded-full text-[11px] font-bold tracking-widest ${r.running ? 'bg-ice/10 text-ice-soft border border-ice/30' : 'bg-white/5 text-mist border border-white/10'}`}>
            <span className={`size-1.5 rounded-full ${r.running ? 'bg-ice' : 'bg-mist'}`} style={{ animation: r.running ? 'pulse-glow 1.2s infinite' : undefined }} />
            {r.running ? 'RADAR ON' : 'RADAR OFF'}
          </div>
          <div className="ml-auto flex gap-2">
            <button onClick={() => actions.saveSettings({ sound: !settings.sound })} className="size-11 rounded-xl btn-ghost grid place-items-center text-lg" aria-label="Sound">{settings.sound ? '🔊' : '🔇'}</button>
            <button onClick={() => setSheet('settings')} className="size-11 rounded-xl btn-ghost grid place-items-center text-lg" aria-label="Settings">⚙️</button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 pb-16 pt-5">
        {r.pausedGapSec > 0 && (
          <div className="glass rounded-2xl p-3.5 mb-4 text-sm flex items-start gap-3 enter border-ice/30">
            <span>⏸️</span>
            <div className="flex-1">WESS was paused for {Math.round(r.pausedGapSec / 60) || 1} min (screen locked or app in background). Moments during that time were not detected. <span className="text-mist">24/7 detection needs the server (phase 2).</span></div>
            <button className="text-mist" onClick={() => radar.clearGap()} aria-label="Dismiss">✕</button>
          </div>
        )}

        {/* radar hero */}
        <section className="glass rounded-3xl p-5 sm:p-7 relative overflow-hidden enter">
          <div className="absolute -right-10 -top-10 jp text-[120px] leading-none text-violet/10 select-none pointer-events-none">配信</div>
          <div className="relative flex flex-col sm:flex-row items-center gap-6">
            <button onClick={() => (r.running ? radar.stop() : radar.start())} disabled={!streamers.length}
              className="relative size-40 shrink-0 rounded-full btn-power grid place-items-center disabled:opacity-40" aria-label={r.running ? 'Stop radar' : 'Start radar'}>
              {r.running && <span className="absolute inset-0 rounded-full overflow-hidden"><span className="absolute inset-0" style={{ background: 'conic-gradient(from 0deg, transparent 0 300deg, rgba(212,248,255,.55) 360deg)', animation: 'sweep 2.4s linear infinite' }} /></span>}
              <span className="absolute inset-3 rounded-full border border-ice/30" />
              <span className="absolute inset-8 rounded-full border border-ice/20" />
              <span className="relative text-center">
                <span className="block text-3xl">{r.running ? '⚡' : '⏻'}</span>
                <span className="block mt-1 text-xs font-bold tracking-[.3em]">{r.running ? 'STOP' : 'START'}</span>
              </span>
            </button>
            <div className="flex-1 w-full">
              <div className="text-[11px] tracking-[.35em] text-mist uppercase">Live radar</div>
              <div className="text-3xl sm:text-4xl font-bold leading-tight mt-1">{r.running ? 'Hunting for moments' : streamers.length ? 'Ready to hunt' : 'Add your streamers'}</div>
              <div className="grid grid-cols-3 gap-2 mt-4">
                {[['Streams', `${streamers.length}/${MAX_CHANNELS}`], ['Msg / min', r.running ? String(r.totalMpm) : '–'], ['Moments 24h', String(today)]].map(([k, v]) => (
                  <div key={k} className="rounded-2xl bg-void/50 border border-violet/15 p-3">
                    <div className="text-2xl font-bold tabular-nums text-ice-soft">{v}</div>
                    <div className="text-[11px] text-mist tracking-wider uppercase">{k}</div>
                  </div>
                ))}
              </div>
              {r.running && r.chat !== 'connected' && <div className="mt-3 text-sm text-ice">Connecting to Twitch chat… ({r.chat})</div>}
              {r.running && settings.keepAwake && <div className="mt-2 text-xs text-mist">Screen stays on while the radar runs — keep WESS open for alerts.</div>}
            </div>
          </div>
        </section>

        {/* streamers */}
        <div className="flex items-center justify-between mt-8 mb-3">
          <h2 className="text-lg font-bold tracking-[.2em] uppercase">Streams <span className="text-mist text-sm">{streamers.length}</span></h2>
          <button onClick={() => setSheet('add')} className="btn-ice h-11 px-5 rounded-xl tracking-wider">+ ADD</button>
        </div>
        {streamers.length === 0 ? (
          <button onClick={() => setSheet('add')} className="glass w-full rounded-3xl p-10 text-center enter">
            <div className="text-5xl mb-3">🎯</div>
            <div className="text-xl font-bold">Add up to {MAX_CHANNELS} streamers</div>
            <div className="text-mist text-sm mt-1">Paste names or twitch.tv links — WESS watches all their chats at once.</div>
          </button>
        ) : (
          <div className="grid grid-cols-1 min-[420px]:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
            {sorted.map((c, i) => <div key={c.login} className="enter" style={{ animationDelay: `${Math.min(i, 12) * 40}ms` }}><StreamerCard c={c} threshold={settings.threshold} running={r.running} onOpen={() => setSheet({ login: c.login })} /></div>)}
          </div>
        )}

        {/* moments feed */}
        <div className="flex items-center justify-between mt-10 mb-3">
          <h2 className="text-lg font-bold tracking-[.2em] uppercase">Moments ⚡</h2>
          {moments.length > 0 && <button onClick={() => actions.clearMoments()} className="text-mist text-sm">Clear</button>}
        </div>
        {moments.length === 0 ? (
          <div className="glass rounded-2xl p-6 text-center text-mist text-sm">No moments yet. When a chat explodes you'll get a <b className="text-ice-soft">CLIP IT!</b> alert — tap it to jump straight into the live on Twitch.</div>
        ) : (
          <div className="space-y-2">
            {moments.slice(0, 30).map((m) => (
              <div key={m.id} className="glass rounded-2xl p-3 flex items-center gap-3 enter">
                <div className={`size-12 shrink-0 rounded-xl grid place-items-center font-bold text-lg tabular-nums ${m.opened ? 'bg-white/5 text-mist' : 'bg-ice/15 text-ice-soft border border-ice/40'}`}>{m.score}</div>
                <div className="min-w-0 flex-1">
                  <div className="font-bold truncate">{m.login} <span className="text-mist font-normal text-xs">· {ago(m.ts)}</span></div>
                  <div className="text-xs text-mist truncate">{m.reasons[0] ?? 'Chat spike'}</div>
                </div>
                <button onClick={() => { actions.markOpened(m.id); openTwitch(m.login); }} className="btn-ice h-11 px-4 rounded-xl text-sm tracking-wider shrink-0">OPEN ▸</button>
              </div>
            ))}
          </div>
        )}

        {/* phase 2 */}
        <h2 className="mt-10 mb-3 text-lg font-bold tracking-[.2em] uppercase">Server powers <span className="text-mist text-sm normal-case tracking-normal">· phase 2</span></h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {[['📲', 'Phone alerts 24/7', 'Notifications even when your phone is locked'], ['✂️', 'Auto clip', 'Creates the Twitch clip by itself'], ['🚀', 'Auto publish', 'Posts to TikTok, Reels and Shorts']].map(([i, t, d]) => (
            <div key={t} className="glass rounded-2xl p-4 opacity-80">
              <div className="flex items-center gap-2"><span className="text-xl">{i}</span><span className="font-bold">{t}</span><span className="ml-auto text-[10px] px-2 py-0.5 rounded-full bg-white/5 border border-white/10 text-mist tracking-wider">🔒 SERVER</span></div>
              <div className="text-xs text-mist mt-1.5">{d}. Unlocks when WESS is connected to a 24/7 server.</div>
            </div>
          ))}
        </div>
        <div className="text-center text-xs text-mist mt-10 tracking-[.3em]">WESS · 瞬間を斬れ</div>
      </main>

      {r.impact && <Impact m={r.impact} onClose={closeImpact} />}
      <AddSheet open={sheet === 'add'} onClose={() => setSheet(null)} />
      <SettingsSheet open={sheet === 'settings'} onClose={() => setSheet(null)} />
      <ChannelSheet login={typeof sheet === 'object' && sheet ? sheet.login : null} onClose={() => setSheet(null)} />
    </div>
  );
}

function AddSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [text, setText] = useState('');
  const [msg, setMsg] = useState<string | null>(null);
  const count = useApp((s) => s.streamers.length);
  const add = () => {
    const res = actions.addStreamers(text);
    const parts = [res.added.length ? `✅ Added ${res.added.length}` : '', res.invalid.length ? `⚠️ Invalid: ${res.invalid.join(', ')}` : '', res.full ? `Max ${MAX_CHANNELS} streams reached` : ''].filter(Boolean);
    setMsg(parts.join(' · ') || 'Already in your list');
    if (res.added.length && !res.invalid.length) { setText(''); setTimeout(onClose, 700); }
    else if (res.added.length) setText(res.invalid.join(' '));
  };
  return (
    <Sheet open={open} onClose={onClose} title="Add streamers">
      <p className="text-sm text-mist mb-3">Type names or paste twitch.tv links, separated by spaces or commas. {count}/{MAX_CHANNELS} used.</p>
      <textarea value={text} onChange={(e) => setText(e.target.value)} rows={3} className="field resize-none" placeholder="kaicenat, xqc twitch.tv/ibai …" autoCapitalize="off" autoCorrect="off" spellCheck={false} />
      {msg && <div className="text-sm mt-2">{msg}</div>}
      <button onClick={add} disabled={!text.trim()} className="btn-ice w-full h-14 rounded-2xl mt-4 tracking-wider disabled:opacity-40">ADD TO RADAR</button>
    </Sheet>
  );
}

function ChannelSheet({ login, onClose }: { login: string | null; onClose: () => void }) {
  const r = useRadar();
  const c = login ? r.channels[login] : null;
  return (
    <Sheet open={!!login} onClose={onClose} title={login ?? ''}>
      {c && (
        <div className="space-y-3">
          <div className="grid grid-cols-3 gap-2 text-center">
            {[['Score', r.running ? c.score : '–'], ['Msg/min', r.running ? c.mpm : '–'], ['Status', c.live === null ? '?' : c.live ? 'LIVE' : 'offline']].map(([k, v]) => (
              <div key={String(k)} className="rounded-2xl bg-void/50 border border-violet/15 p-3"><div className="text-xl font-bold text-ice-soft">{v}</div><div className="text-[11px] text-mist uppercase tracking-wider">{k}</div></div>
            ))}
          </div>
          {c.reasons.length > 0 && <ul className="text-sm text-mist space-y-1">{c.reasons.map((x) => <li key={x}>⚡ {x}</li>)}</ul>}
          <button onClick={() => { onClose(); openTwitch(c.login); }} className="btn-ice w-full h-14 rounded-2xl tracking-wider">OPEN IN TWITCH ▸</button>
          <button onClick={() => { radar.test(c.login); onClose(); }} className="btn-ghost w-full h-12 rounded-2xl">Test alert for this stream</button>
          <button onClick={() => { actions.removeStreamer(c.login); onClose(); }} className="w-full h-12 rounded-2xl text-[#ff7a9a] border border-[#ff7a9a]/30">Remove from radar</button>
        </div>
      )}
    </Sheet>
  );
}

function SettingsSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const s = useApp((st) => st.settings);
  const [perm, setPerm] = useState(notifyPermission());
  useEffect(() => { if (open) setPerm(notifyPermission()); }, [open]);
  const Row = ({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) => (
    <div className="py-3 border-b border-white/5"><div className="flex items-center justify-between gap-3"><div><div className="font-bold">{label}</div>{hint && <div className="text-xs text-mist mt-0.5">{hint}</div>}</div>{children}</div></div>
  );
  const Toggle = ({ on, set }: { on: boolean; set: (v: boolean) => void }) => (
    <button onClick={() => set(!on)} role="switch" aria-checked={on} className={`relative h-8 w-14 shrink-0 rounded-full transition-colors ${on ? 'bg-gradient-to-r from-violet to-ice' : 'bg-white/10'}`}>
      <span className={`absolute top-1 size-6 rounded-full bg-white shadow transition-all ${on ? 'left-7' : 'left-1'}`} />
    </button>
  );
  return (
    <Sheet open={open} onClose={onClose} title="Settings">
      <Row label={`Alert at score ${s.threshold}`} hint="Lower = more alerts, higher = only big moments">
        <span className="text-ice-soft font-bold text-xl tabular-nums">{s.threshold}</span>
      </Row>
      <input type="range" className="range my-2" min={30} max={95} value={s.threshold} onChange={(e) => actions.saveSettings({ threshold: Number(e.target.value) })} />
      <Row label="Sensitivity" hint="How big a chat speed-up counts: Low 3×, Medium 2×, High 1.5×">
        <div className="flex gap-1 p-1 rounded-xl bg-void/60">
          {(['low', 'medium', 'high'] as const).map((v) => <button key={v} onClick={() => actions.saveSettings({ sensitivity: v })} className={`px-3 h-9 rounded-lg text-sm capitalize ${s.sensitivity === v ? 'bg-violet text-white' : 'text-mist'}`}>{v}</button>)}
        </div>
      </Row>
      <Row label={`Cooldown ${s.cooldownSec}s`} hint="Minimum time between two alerts for the same stream" ><span /></Row>
      <input type="range" className="range my-2" min={30} max={300} step={15} value={s.cooldownSec} onChange={(e) => actions.saveSettings({ cooldownSec: Number(e.target.value) })} />
      <Row label="Sound" hint="Impact sound on every moment"><Toggle on={s.sound} set={(v) => actions.saveSettings({ sound: v })} /></Row>
      <Row label="Keep screen on" hint="Stops the iPhone from locking while the radar runs"><Toggle on={s.keepAwake} set={(v) => { actions.saveSettings({ keepAwake: v }); void radar.keepAwake(v); }} /></Row>
      <Row label="Phone notifications" hint={perm === 'granted' ? 'Allowed — tap a notification to open the live' : perm === 'denied' ? 'Blocked — allow WESS in your phone settings' : 'Banner notifications, tap → Twitch'}>
        {perm === 'granted' ? <Toggle on={s.systemNotifications} set={(v) => actions.saveSettings({ systemNotifications: v })} />
          : <button disabled={perm === 'denied' || perm === 'unsupported'} onClick={async () => { const p = await requestNotifications(); setPerm(p); if (p === 'granted') actions.saveSettings({ systemNotifications: true }); }} className="btn-ice h-10 px-4 rounded-xl text-sm disabled:opacity-40">Enable</button>}
      </Row>
      {(perm === 'unsupported' || (isIOS() && !isStandalone())) && (
        <div className="text-xs text-mist mt-2 rounded-xl bg-void/50 p-3 leading-relaxed">
          📱 iPhone: notifications need WESS on your Home Screen. In Safari tap <b>Share → Add to Home Screen</b>, open WESS from there, then tap Enable.
          {!notifySupported() && ' (Not available in this browser.)'}
        </div>
      )}
      <Row label="Reduce motion" hint="Fewer animations, saves battery"><Toggle on={s.reduceMotion} set={(v) => actions.saveSettings({ reduceMotion: v })} /></Row>
      <button onClick={() => { onClose(); radar.test(); }} className="btn-ice w-full h-14 rounded-2xl mt-5 tracking-wider">⚡ TEST ALERT</button>
      <p className="text-xs text-mist mt-4 leading-relaxed">Phase 1 runs on your phone: alerts work while WESS is open. Twitch chat is read anonymously (read-only); live status and avatars come from the free decapi.me service.</p>
    </Sheet>
  );
}
