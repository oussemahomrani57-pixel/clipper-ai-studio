import { motion } from 'framer-motion';
import { useMemo, useState } from 'react';
import { BLOCK_LABEL, DEFAULT_CONFIG, DEFAULT_WEIGHTS, MomentDetector, normalizeWeights, type ScoreWeights, type Sensitivity } from '@shared/scoring.ts';
import { Badge, Button, Card, CardHeader, Field, Input, Notice, PageHeader, Segmented, Slider, Switch } from '../components/ui.tsx';
import { ScoreGauge } from '../components/charts.tsx';
import { Icon } from '../components/Icon.tsx';
import { Avatar } from './Streamers.tsx';
import { db, toast, useStore } from '../lib/store.ts';
import { twitchReady, useSystem } from '../lib/system.ts';
import { navigate } from '../lib/router.ts';
import { cx, timeAgo } from '../lib/format.ts';

const W_LABELS: [keyof ScoreWeights, string, string][] = [
  ['chatVelocity', 'Chat velocity', 'Sudden increase in messages/sec vs. the channel baseline'],
  ['reactions', 'Repeated reactions', 'KEKW, LUL, 😂, repeated identical messages'],
  ['keywords', 'Keywords', '"clip it", "no way", "insane"…'],
  ['streamEvents', 'Stream events', 'Go-live, category change'],
  ['other', 'Chatter breadth', 'Many different people reacting (anti-spam)'],
];
const COLORS = ['#7857ff', '#32a5ff', '#32e6a0', '#ffb547', '#ff5c7a'];

export default function AutoClipper() {
  const settings = useStore((s) => s.settings);
  const streamers = useStore((s) => s.tables.streamers);
  const events = useStore((s) => s.tables.detection_events);
  const mode = useStore((s) => s.mode);
  const sys = useSystem();
  const d = { ...DEFAULT_CONFIG, ...settings.detector };
  const w = normalizeWeights(d.weights);
  const [kw, setKw] = useState('');
  const save = (p: Partial<typeof d>) => db.saveSettings({ detector: { ...settings.detector, ...p } }).catch((e) => toast('error', 'Save failed', (e as Error).message));

  const on = settings.auto_clipping_enabled;
  const paused = settings.auto_paused;
  const engineOk = Boolean(sys.engine?.online);
  const selected = streamers.filter((s) => s.auto_clip_enabled);
  const today = events.filter((e) => e.action === 'clip_requested' && Date.now() - new Date(e.created_at).getTime() < 86_400_000).length;

  return (
    <div>
      <PageHeader title="Auto Clipper" subtitle="Detect hype moments from chat and request real Twitch clips automatically — with cooldowns and limits." />

      <Card className={cx('relative overflow-hidden p-5 sm:p-6 mb-5', on && !paused && engineOk && 'border-green/30')}>
        {on && !paused && <div className="absolute -right-16 -top-16 size-56 rounded-full bg-green/15 blur-3xl" />}
        <div className="relative flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <motion.div animate={{ rotate: on && !paused ? [0, -8, 8, 0] : 0 }} transition={{ repeat: on && !paused ? Infinity : 0, duration: 2.4 }}
              className={cx('grid place-items-center size-14 rounded-2xl', on ? 'bg-gradient-to-br from-purple to-blue text-white shadow-[0_0_30px_rgb(120_87_255/.5)]' : 'bg-white/5 text-muted')}><Icon name="bolt" size={26} /></motion.div>
            <div>
              <div className="font-display text-xl font-semibold">AUTO CLIPPING: <span className={on ? (paused ? 'text-amber' : 'text-green') : 'text-muted'}>{on ? (paused ? 'PAUSED' : 'ON') : 'OFF'}</span></div>
              <div className="text-sm text-muted mt-0.5">{selected.length} streamer(s) selected · {today} clip requests in last 24h (limit {d.maxPerDay}/day per streamer)</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {on && <Button size="sm" icon={paused ? 'play' : 'pause'} onClick={() => db.saveSettings({ auto_paused: !paused })}>{paused ? 'Resume' : 'Pause'}</Button>}
            <Switch checked={on} onChange={(v) => db.saveSettings({ auto_clipping_enabled: v, auto_paused: false })} label="Auto clipping" />
          </div>
        </div>
      </Card>

      {on && (
        <div className="mb-5">
          {mode !== 'cloud' ? <Notice tone="warn" title="Saved, but nothing will be clipped automatically yet" action={<Button size="sm" onClick={() => navigate('settings')}>Set up cloud</Button>}>In Local mode settings stay on this device. The 24/7 Engine reads them from your cloud account.</Notice>
            : !engineOk ? <Notice tone="warn" title="Engine offline — automatic clipping is NOT running">Your settings are saved in the cloud. Deploy/start the Engine (see DEPLOYMENT.md) — when its heartbeat appears, monitoring starts. You can also use the browser monitor on the Live Monitor page while the app is open.</Notice>
              : !twitchReady(sys) ? <Notice tone="error" title="Twitch not connected">The engine needs your Twitch connection (scopes clips:edit + user:read:chat).</Notice>
                : <Notice tone="success" title="Engine is monitoring">{sys.engine?.channels} channel(s) watched via EventSub. Detected moments appear in the event log below.</Notice>}
        </div>
      )}

      <div className="grid lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 space-y-4">
          <Card>
            <CardHeader title="Trigger rules" icon="target" />
            <div className="px-5 pb-5 grid sm:grid-cols-2 gap-5">
              <Field label="Minimum viral score" hint="0–100. Higher = fewer, stronger clips."><Slider value={d.minScore} min={30} max={100} onChange={(v) => save({ minScore: v })} /></Field>
              <Field label="Cooldown between clips" hint="Per streamer."><Slider value={d.cooldownSec} min={30} max={900} step={15} suffix="s" onChange={(v) => save({ cooldownSec: v })} /></Field>
              <Field label="Max clips per hour"><Slider value={d.maxPerHour} min={1} max={30} onChange={(v) => save({ maxPerHour: v })} /></Field>
              <Field label="Max clips per day"><Slider value={d.maxPerDay} min={1} max={200} onChange={(v) => save({ maxPerDay: v })} /></Field>
              <Field label="Sensitivity" hint="How big a chat spike must be (Low 5×, Medium 3.5×, High 2.2× baseline)." className="sm:col-span-2">
                <Segmented<Sensitivity> value={d.sensitivity} onChange={(v) => save({ sensitivity: v })} options={[{ value: 'low', label: 'Low' }, { value: 'medium', label: 'Medium' }, { value: 'high', label: 'High' }]} />
              </Field>
            </div>
          </Card>

          <Card>
            <CardHeader title="Score weights" subtitle="Normalized to 100%" icon="layers" action={<Button size="sm" variant="ghost" onClick={() => save({ weights: DEFAULT_WEIGHTS })}>Reset</Button>} />
            <div className="px-5 pb-5">
              <div className="flex h-3 rounded-full overflow-hidden mb-5">
                {W_LABELS.map(([k], i) => <motion.div key={k} animate={{ width: `${w[k]}%` }} style={{ background: COLORS[i] }} />)}
              </div>
              <div className="space-y-4">
                {W_LABELS.map(([k, label, hint], i) => (
                  <div key={k}>
                    <div className="flex items-center justify-between text-sm mb-1"><span className="flex items-center gap-2"><span className="size-2.5 rounded-sm" style={{ background: COLORS[i] }} />{label}</span><span className="tabular-nums text-muted">{Math.round(w[k])}%</span></div>
                    <Slider value={d.weights[k]} min={0} max={100} onChange={(v) => save({ weights: { ...d.weights, [k]: v } })} />
                    <p className="text-xs text-muted mt-1">{hint}</p>
                  </div>
                ))}
              </div>
            </div>
          </Card>

          <Card>
            <CardHeader title="Excitement keywords" subtitle="Matched as whole words in chat" icon="type" />
            <div className="px-5 pb-5">
              <div className="flex gap-2 mb-3">
                <Input value={kw} onChange={(e) => setKw(e.target.value)} placeholder="Add keyword" onKeyDown={(e) => { if (e.key === 'Enter' && kw.trim()) { save({ keywords: [...new Set([...d.keywords, kw.trim().toLowerCase()])] }); setKw(''); } }} />
                <Button icon="plus" onClick={() => { if (kw.trim()) { save({ keywords: [...new Set([...d.keywords, kw.trim().toLowerCase()])] }); setKw(''); } }}>Add</Button>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {d.keywords.map((k) => <button key={k} onClick={() => save({ keywords: d.keywords.filter((x) => x !== k) })} className="group flex items-center gap-1 px-2.5 h-7 rounded-lg bg-white/[.05] border border-white/5 text-xs hover:border-red/40">{k}<Icon name="x" size={12} className="text-muted group-hover:text-red" /></button>)}
              </div>
            </div>
          </Card>
        </div>

        <div className="space-y-4">
          <Card>
            <CardHeader title="Streamers" subtitle="Auto clip enabled per channel" icon="users" />
            <div className="px-5 pb-5 space-y-2">
              {streamers.length === 0 && <Button className="w-full" onClick={() => navigate('streamers')}>Add streamers</Button>}
              {streamers.map((s) => (
                <div key={s.id} className="flex items-center gap-3">
                  <Avatar s={s} size={34} />
                  <div className="flex-1 min-w-0 text-sm truncate">{s.display_name ?? s.login}{!s.twitch_user_id && !s.is_demo && <div className="text-[11px] text-amber">needs Twitch ID</div>}</div>
                  <Switch checked={s.auto_clip_enabled} disabled={!s.twitch_user_id && !s.is_demo} onChange={(v) => db.update('streamers', s.id, { auto_clip_enabled: v })} />
                </div>
              ))}
            </div>
          </Card>
          <Simulator />
        </div>
      </div>

      <Card className="mt-4">
        <CardHeader title="Event log" subtitle="Why each moment was detected" icon="layers" />
        <div className="px-5 pb-5 divide-y divide-white/5">
          {events.length === 0 && <p className="text-sm text-muted py-4">No events yet.</p>}
          {events.slice(0, 30).map((e) => (
            <div key={e.id} className="py-3 flex gap-3">
              <span className={cx('font-display font-semibold w-10 text-center rounded-lg py-1 text-sm h-fit', e.score >= d.minScore ? 'bg-green/12 text-green' : 'bg-white/5')}>{e.score}</span>
              <div className="flex-1 min-w-0 text-sm">
                <div className="flex flex-wrap items-center gap-2"><b>{e.streamer_login}</b><Badge tone={e.action === 'clip_requested' ? 'purple' : 'muted'}>{e.action.replace('_', ' ')}</Badge><Badge>{e.source}</Badge>{e.is_demo && <Badge tone="amber">Demo</Badge>}<span className="text-xs text-muted ml-auto">{timeAgo(e.created_at)}</span></div>
                <ul className="mt-1.5 text-xs text-muted space-y-0.5">{e.reasons.map((r) => <li key={r}>• {r}</li>)}{e.blocked_by && <li className="text-red">• {e.blocked_by}</li>}</ul>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

/** Lets you see how the current settings react to a simulated chat burst. Clearly labelled; creates nothing. */
function Simulator() {
  const det = useStore((s) => s.settings.detector);
  const [intensity, setIntensity] = useState(60);
  const result = useMemo(() => {
    const m = new MomentDetector({ ...det });
    const t0 = 1_000_000_000_000;
    for (let s = 0; s < 240; s++) for (let i = 0; i < 2; i++) m.addMessage({ ts: t0 + s * 1000 + i * 300, userId: `b${(s + i) % 30}`, text: `normal message ${s}` });
    const start = t0 + 240_000; const n = Math.round(intensity * 1.4);
    for (let i = 0; i < n; i++) m.addMessage({ ts: start + (i * 9500) / Math.max(1, n), userId: `x${i % Math.max(3, Math.round(intensity / 2))}`, text: i % 3 === 0 ? 'KEKW' : i % 3 === 1 ? 'no way' : 'clip it' });
    return m.evaluate(start + 9_900);
  }, [det, intensity]);
  return (
    <Card>
      <CardHeader title="Settings simulator" subtitle="Simulated chat burst — nothing is clipped" icon="sparkles" action={<Badge tone="amber">Simulation</Badge>} />
      <div className="px-5 pb-5">
        <Field label="Burst intensity"><Slider value={intensity} min={0} max={100} onChange={setIntensity} /></Field>
        <div className="flex flex-col items-center mt-3">
          <ScoreGauge score={result.score} threshold={det.minScore ?? 70} size={140} />
          <div className={cx('text-sm mt-2 font-medium', result.shouldTrigger ? 'text-green' : 'text-muted')}>{result.shouldTrigger ? 'Would request a clip' : result.blockedBy ? BLOCK_LABEL[result.blockedBy] : ''}</div>
          <div className="text-xs text-muted mt-1">{result.msgPerSec.toFixed(1)} msg/s vs baseline {result.baselineMsgPerSec.toFixed(1)}</div>
        </div>
      </div>
    </Card>
  );
}
