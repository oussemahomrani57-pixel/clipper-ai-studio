import { test } from 'node:test';
import assert from 'node:assert/strict';
import { buildRenderArgs } from '../src/jobs.ts';

test('render args: trim, crop, vertical pad, no shell injection', () => {
  const a = buildRenderArgs({ input: '/tmp/in', output: '/tmp/out.mp4', preset: '720x1280', start: 2, end: 12, crop: { x: 0.25, y: 0, w: 0.5, h: 1 } });
  assert.deepEqual(a.slice(a.indexOf('-ss'), a.indexOf('-ss') + 2), ['-ss', '2.000']);
  assert.equal(a[a.indexOf('-t') + 1], '10.000');
  const vf = a[a.indexOf('-vf') + 1];
  assert.match(vf, /^crop=iw\*0\.5000:ih\*1\.0000:iw\*0\.2500:ih\*0\.0000,scale=720:1280/);
  assert.ok(a.includes('+faststart'));
});

test('render args: unknown preset falls back to 1080x1920', () => {
  const a = buildRenderArgs({ input: 'i', output: 'o', preset: 'evil;rm -rf /' });
  assert.match(a[a.indexOf('-vf') + 1], /scale=1080:1920/);
});
