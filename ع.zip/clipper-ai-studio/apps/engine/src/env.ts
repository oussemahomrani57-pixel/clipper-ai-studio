export interface EngineEnv {
  SUPABASE_URL: string;
  SUPABASE_SERVICE_ROLE_KEY: string;
  TWITCH_CLIENT_ID: string;
  TWITCH_CLIENT_SECRET: string;
  TOKEN_ENCRYPTION_KEY: string;
  WORKER_ID: string;
  FFMPEG_PATH: string;
  /** Optional: command for local whisper.cpp, e.g. "/opt/whisper/main -m /opt/whisper/ggml-base.bin" */
  WHISPER_CMD: string;
  /** "whisper_cpp" (free, local) | "openai" (paid, needs OPENAI_API_KEY) | "none" */
  TRANSCRIBE_PROVIDER: string;
  OPENAI_API_KEY: string;
}

const REQUIRED = ['SUPABASE_URL', 'SUPABASE_SERVICE_ROLE_KEY', 'TWITCH_CLIENT_ID', 'TWITCH_CLIENT_SECRET', 'TOKEN_ENCRYPTION_KEY'] as const;

export function loadEnv(): EngineEnv {
  const e = process.env;
  const missing = REQUIRED.filter((k) => !e[k]);
  if (missing.length) {
    console.error(`Missing environment variables: ${missing.join(', ')} — see .env.example`);
    process.exit(1);
  }
  return {
    SUPABASE_URL: e.SUPABASE_URL!,
    SUPABASE_SERVICE_ROLE_KEY: e.SUPABASE_SERVICE_ROLE_KEY!,
    TWITCH_CLIENT_ID: e.TWITCH_CLIENT_ID!,
    TWITCH_CLIENT_SECRET: e.TWITCH_CLIENT_SECRET!,
    TOKEN_ENCRYPTION_KEY: e.TOKEN_ENCRYPTION_KEY!,
    WORKER_ID: e.WORKER_ID ?? `engine-${Math.random().toString(36).slice(2, 8)}`,
    FFMPEG_PATH: e.FFMPEG_PATH ?? 'ffmpeg',
    WHISPER_CMD: e.WHISPER_CMD ?? '',
    TRANSCRIBE_PROVIDER: e.TRANSCRIBE_PROVIDER ?? 'none',
    OPENAI_API_KEY: e.OPENAI_API_KEY ?? '',
  };
}
