/**
 * Auto Clipping monitor: one EventSub session per connected Twitch account,
 * one MomentDetector per monitored streamer. Requests real Twitch clips when the
 * detector fires and all guards (cooldown, hourly/daily caps, re-arm) pass.
 */
import { Supa } from '../../../packages/shared/src/supa.ts';
import { decryptToken, encryptToken } from '../../../packages/shared/src/crypto.ts';
import { MomentDetector, type DetectorConfig, DEFAULT_CONFIG } from '../../../packages/shared/src/scoring.ts';
import { TWITCH_SCOPES, TwitchError, createClip, getClip, refreshUserToken, getAppToken, helix, type TwitchStream } from '../../../packages/shared/src/twitch.ts';
import { EventSubSession, type SubSpec } from './eventsub.ts';
import type { EngineEnv } from './env.ts';
import { log } from './log.ts';

interface Settings { user_id: string; auto_clipping_enabled: boolean; auto_paused: boolean; detector: Partial<DetectorConfig>; }
interface Streamer { id: string; user_id: string; twitch_user_id: string | null; login: string; auto_clip_enabled: boolean; preferences: Partial<DetectorConfig>; }
interface Account { id: string; user_id: string; twitch_user_id: string; login: string; scopes: string[]; }
interface TokenRow { access_token_enc: string; refresh_token_enc: string; expires_at: string; }

interface Watch { streamer: Streamer; detector: MomentDetector; live: boolean; minute: { start: number; count: number; users: Set<string>; peak: number }; }

export class Monitor {
  private sessions = new Map<string, { session: EventSubSession; account: Account; watches: Map<string, Watch> }>();
  private tokens = new Map<string, { token: string; exp: number }>();
  private appTok: { token: string; exp: number } | null = null;
  private clipBackoffUntil = 0;

  private env: EngineEnv;
  private db: Supa;
  constructor(env: EngineEnv, db: Supa) { this.env = env; this.db = db; }

  get stats() {
    let channels = 0; let connected = 0;
    for (const s of this.sessions.values()) { channels += s.watches.size; if (s.session.connected) connected++; }
    return { channels, sessions: this.sessions.size, connected };
  }

  /** Re-read configuration from the DB; start/stop sessions accordingly. Called every minute. */
  async reconcile() {
    const settings = await this.db.select<Settings>('user_settings', 'auto_clipping_enabled=eq.true&auto_paused=eq.false&select=user_id,auto_clipping_enabled,auto_paused,detector');
    const wantedAccounts = new Set<string>();
    for (const s of settings) {
      const [account] = await this.db.select<Account>('twitch_accounts', `user_id=eq.${s.user_id}&status=eq.active&order=created_at.asc&limit=1`);
      if (!account) continue;
      if (!account.scopes.includes(TWITCH_SCOPES.readChat)) { log.warn(`account ${account.login} lacks ${TWITCH_SCOPES.readChat}`); continue; }
      const streamers = await this.db.select<Streamer>('streamers', `user_id=eq.${s.user_id}&auto_clip_enabled=eq.true&twitch_user_id=not.is.null`);
      wantedAccounts.add(account.id);
      let entry = this.sessions.get(account.id);
      if (!entry) {
        const watches = new Map<string, Watch>();
        const session = new EventSubSession(
          this.env.TWITCH_CLIENT_ID,
          () => this.userToken(account),
          () => [...watches.values()].flatMap((w) => this.specsFor(account, w.streamer)),
          (type, ev) => this.onEvent(account, watches, type, ev),
          account.login,
        );
        entry = { session, account, watches };
        this.sessions.set(account.id, entry);
        session.start();
      }
      // sync watches
      const wanted = new Set(streamers.map((x) => x.id));
      let added = false;
      for (const st of streamers) {
        const cfg: Partial<DetectorConfig> = { ...DEFAULT_CONFIG, ...s.detector, ...st.preferences };
        const existing = entry.watches.get(st.twitch_user_id!);
        if (existing) { existing.streamer = st; Object.assign(existing.detector.config, cfg); continue; }
        const det = new MomentDetector(cfg);
        const prior = await this.db.select<{ created_at: string }>('detection_events', `streamer_id=eq.${st.id}&action=eq.clip_requested&created_at=gte.${new Date(Date.now() - 86_400_000).toISOString()}&select=created_at`);
        det.loadTriggerHistory(prior.map((p) => new Date(p.created_at).getTime()));
        entry.watches.set(st.twitch_user_id!, { streamer: st, detector: det, live: false, minute: { start: Date.now(), count: 0, users: new Set(), peak: 0 } });
        added = true;
      }
      for (const [bid, w] of entry.watches) if (!wanted.has(w.streamer.id)) entry.watches.delete(bid);
      if (added) await entry.session.subscribeAll();
      await this.refreshLive(entry.watches);
    }
    for (const [id, e] of this.sessions) if (!wantedAccounts.has(id)) { e.session.stop(); this.sessions.delete(id); log.info(`stopped monitoring for ${e.account.login}`); }
  }

  private specsFor(account: Account, s: Streamer): SubSpec[] {
    const b = s.twitch_user_id!;
    return [
      { type: 'channel.chat.message', version: '1', condition: { broadcaster_user_id: b, user_id: account.twitch_user_id } },
      { type: 'stream.online', version: '1', condition: { broadcaster_user_id: b } },
      { type: 'stream.offline', version: '1', condition: { broadcaster_user_id: b } },
      { type: 'channel.update', version: '2', condition: { broadcaster_user_id: b } },
    ];
  }

  private async refreshLive(watches: Map<string, Watch>) {
    const ids = [...watches.keys()];
    if (!ids.length) return;
    const r = await helix<{ data: TwitchStream[] }>({ clientId: this.env.TWITCH_CLIENT_ID, token: await this.app() }, `/streams?${ids.map((i) => `user_id=${i}`).join('&')}`);
    const live = new Set(r.data.map((s) => s.user_id));
    for (const [id, w] of watches) w.live = live.has(id);
  }

  private onEvent(account: Account, watches: Map<string, Watch>, type: string, ev: Record<string, unknown>) {
    const w = watches.get(String(ev.broadcaster_user_id));
    if (!w) return;
    const now = Date.now();
    if (type === 'channel.chat.message') {
      const text = String((ev.message as { text?: string })?.text ?? '');
      const uid = String(ev.chatter_user_id ?? '');
      w.detector.addMessage({ ts: now, userId: uid, text });
      w.minute.count++; w.minute.users.add(uid);
    } else if (type === 'stream.online') {
      w.live = true;
      w.detector.addEvent({ ts: now, type: 'online', label: 'Stream went live' });
      void this.notify(account.user_id, 'streamer_live', `${w.streamer.login} is live`, 'Auto clipping is watching chat.');
    } else if (type === 'stream.offline') {
      w.live = false;
    } else if (type === 'channel.update') {
      w.detector.addEvent({ ts: now, type: 'game_change', label: `Category: ${String(ev.category_name ?? '')}` });
    }
  }

  /** Evaluate all live channels. Called every 2 s. */
  async tick() {
    const now = Date.now();
    for (const { account, watches } of this.sessions.values()) {
      for (const [bid, w] of watches) {
        if (!w.live) continue;
        const e = w.detector.evaluate(now);
        w.minute.peak = Math.max(w.minute.peak, e.score);
        if (now - w.minute.start >= 60_000) void this.flushMinute(account.user_id, w);
        if (!e.shouldTrigger) continue;
        if (now < this.clipBackoffUntil) continue;
        w.detector.markTriggered(now); // mark first: prevents duplicate triggers while the request is in flight
        void this.requestClip(account, bid, w, e.score, e.components, e.reasons);
      }
    }
  }

  private async flushMinute(userId: string, w: Watch) {
    const m = w.minute;
    w.minute = { start: Date.now(), count: 0, users: new Set(), peak: 0 };
    try {
      await this.db.insert('chat_activity', { user_id: userId, streamer_id: w.streamer.id, minute: new Date(Math.floor(m.start / 60_000) * 60_000).toISOString(), messages: m.count, unique_chatters: m.users.size, peak_score: m.peak }, { upsertOn: 'streamer_id,minute' });
    } catch (e) { log.warn(`chat_activity: ${(e as Error).message}`); }
  }

  private async requestClip(account: Account, broadcasterId: string, w: Watch, score: number, components: unknown, reasons: string[]) {
    const [det] = await this.db.insert<{ id: string }>('detection_events', {
      user_id: account.user_id, streamer_id: w.streamer.id, streamer_login: w.streamer.login, score, components, reasons, action: 'clip_requested', source: 'engine',
    });
    try {
      const token = await this.userToken(account);
      const c = await createClip({ clientId: this.env.TWITCH_CLIENT_ID, token }, broadcasterId, { title: `${w.streamer.login} — auto clip (${score})` });
      const [clip] = await this.db.insert<{ id: string }>('clips', {
        user_id: account.user_id, streamer_id: w.streamer.id, streamer_login: w.streamer.login, twitch_clip_id: c.id, edit_url: c.edit_url,
        type: 'auto', detection_score: score, detection_event_id: det.id, status: 'processing',
      }, { upsertOn: 'user_id,twitch_clip_id' });
      await this.db.update('detection_events', `id=eq.${det.id}`, { clip_id: clip.id });
      log.info(`auto clip requested for ${w.streamer.login} (score ${score})`);
      setTimeout(() => void this.confirm(account.user_id, clip.id, c.id, 0), 15_000);
    } catch (e) {
      const msg = (e as Error).message;
      if (e instanceof TwitchError && e.status === 429) this.clipBackoffUntil = Date.now() + (e.retryAfterSec ?? 30) * 1000;
      await this.db.update('detection_events', `id=eq.${det.id}`, { action: 'skipped', blocked_by: `twitch: ${msg}`.slice(0, 200) });
      await this.notify(account.user_id, 'clip_failed', `Auto clip failed for ${w.streamer.login}`, msg);
    }
  }

  private async confirm(userId: string, clipId: string, twitchId: string, attempt: number) {
    try {
      const c = await getClip({ clientId: this.env.TWITCH_CLIENT_ID, token: await this.app() }, twitchId);
      if (c) {
        await this.db.update('clips', `id=eq.${clipId}`, { status: 'ready', url: c.url, thumbnail_url: c.thumbnail_url, duration_sec: c.duration, title: c.title });
        await this.notify(userId, 'clip_created', 'Auto clip created', c.title, '#/library');
        return;
      }
    } catch (e) { log.warn(`confirm: ${(e as Error).message}`); }
    if (attempt < 3) { setTimeout(() => void this.confirm(userId, clipId, twitchId, attempt + 1), 15_000); return; }
    await this.db.update('clips', `id=eq.${clipId}`, { status: 'failed', error: 'Twitch did not confirm the clip.' });
    await this.notify(userId, 'clip_failed', 'Auto clip failed', 'Twitch did not confirm the clip.', '#/library');
  }

  private async notify(userId: string, kind: string, title: string, body?: string, link?: string) {
    try { await this.db.insert('notifications', { user_id: userId, kind, title, body, link }); } catch { /* non-fatal */ }
  }

  private async app(): Promise<string> {
    if (this.appTok && this.appTok.exp > Date.now() + 60_000) return this.appTok.token;
    const t = await getAppToken(this.env.TWITCH_CLIENT_ID, this.env.TWITCH_CLIENT_SECRET);
    this.appTok = { token: t.access_token, exp: Date.now() + t.expires_in * 1000 };
    return this.appTok.token;
  }

  private async userToken(account: Account): Promise<string> {
    const cached = this.tokens.get(account.id);
    if (cached && cached.exp > Date.now() + 5 * 60_000) return cached.token;
    const [row] = await this.db.select<TokenRow>('twitch_tokens', `twitch_account_id=eq.${account.id}`);
    if (!row) throw new TwitchError(409, 'Missing Twitch token');
    const key = this.env.TOKEN_ENCRYPTION_KEY;
    let token = await decryptToken(row.access_token_enc, key);
    let exp = new Date(row.expires_at).getTime();
    if (exp - Date.now() < 5 * 60_000) {
      try {
        const f = await refreshUserToken(this.env.TWITCH_CLIENT_ID, this.env.TWITCH_CLIENT_SECRET, await decryptToken(row.refresh_token_enc, key));
        token = f.access_token; exp = Date.now() + f.expires_in * 1000;
        await this.db.update('twitch_tokens', `twitch_account_id=eq.${account.id}`, {
          access_token_enc: await encryptToken(f.access_token, key), refresh_token_enc: await encryptToken(f.refresh_token, key), expires_at: new Date(exp).toISOString(),
        });
      } catch (e) {
        await this.db.update('twitch_accounts', `id=eq.${account.id}`, { status: 'expired', last_error: (e as Error).message });
        await this.notify(account.user_id, 'connection_expired', 'Twitch connection expired', 'Reconnect Twitch in Settings.', '#/settings');
        throw e;
      }
    }
    this.tokens.set(account.id, { token, exp });
    return token;
  }

  stop() { for (const s of this.sessions.values()) s.session.stop(); }
}
