/**
 * Twitch EventSub WebSocket session with reconnect + keepalive watchdog.
 * Docs: https://dev.twitch.tv/docs/eventsub/handling-websocket-events
 * Uses Node 22's built-in WebSocket (no dependency).
 */
import { helix } from '../../../packages/shared/src/twitch.ts';
import { log } from './log.ts';

export interface SubSpec { type: string; version: string; condition: Record<string, string>; }
export type Handler = (type: string, event: Record<string, unknown>, messageId: string) => void;

const URL_DEFAULT = 'wss://eventsub.wss.twitch.tv/ws';

export class EventSubSession {
  private ws: WebSocket | null = null;
  private sessionId: string | null = null;
  private keepaliveMs = 15_000;
  private lastMsg = Date.now();
  private watchdog: ReturnType<typeof setInterval> | null = null;
  private seen = new Map<string, number>(); // message-id de-duplication
  private backoff = 1_000;
  private closed = false;
  connected = false;

  private clientId: string;
  private getToken: () => Promise<string>;
  private subs: () => SubSpec[];
  private onEvent: Handler;
  private label: string;

  constructor(clientId: string, getToken: () => Promise<string>, subs: () => SubSpec[], onEvent: Handler, label: string) {
    this.clientId = clientId; this.getToken = getToken; this.subs = subs; this.onEvent = onEvent; this.label = label;
  }

  start(url = URL_DEFAULT) {
    this.closed = false;
    const ws = new WebSocket(url);
    const isReconnect = url !== URL_DEFAULT;
    ws.onmessage = (ev) => this.handle(ws, JSON.parse(String(ev.data)), isReconnect);
    ws.onclose = () => {
      if (this.ws !== ws) return; // superseded by a reconnect
      this.connected = false;
      if (this.closed) return;
      log.warn(`[${this.label}] EventSub closed, retrying in ${this.backoff} ms`);
      setTimeout(() => this.start(), this.backoff);
      this.backoff = Math.min(this.backoff * 2, 60_000);
    };
    ws.onerror = () => log.warn(`[${this.label}] EventSub socket error`);
    if (!this.watchdog) {
      this.watchdog = setInterval(() => {
        if (this.connected && Date.now() - this.lastMsg > this.keepaliveMs + 10_000) {
          log.warn(`[${this.label}] keepalive missed — reconnecting`);
          this.ws?.close();
        }
        for (const [id, t] of this.seen) if (Date.now() - t > 600_000) this.seen.delete(id);
      }, 5_000);
    }
    if (!isReconnect) this.ws = ws;
    else this.pending = ws;
  }

  private pending: WebSocket | null = null;

  private async handle(ws: WebSocket, msg: { metadata: { message_id: string; message_type: string; subscription_type?: string }; payload: any }, isReconnect: boolean) {
    this.lastMsg = Date.now();
    const { message_type, message_id } = msg.metadata;
    if (this.seen.has(message_id)) return; // duplicate delivery
    this.seen.set(message_id, Date.now());

    switch (message_type) {
      case 'session_welcome': {
        this.sessionId = msg.payload.session.id;
        this.keepaliveMs = (msg.payload.session.keepalive_timeout_seconds ?? 10) * 1000;
        this.connected = true;
        this.backoff = 1_000;
        if (isReconnect) {
          // Twitch migrates existing subscriptions to the new socket.
          const old = this.ws; this.ws = ws; this.pending = null; old?.close();
        } else {
          await this.subscribeAll();
        }
        log.info(`[${this.label}] EventSub connected (${this.sessionId})`);
        break;
      }
      case 'session_reconnect':
        this.start(msg.payload.session.reconnect_url);
        break;
      case 'notification':
        this.onEvent(msg.metadata.subscription_type ?? '', msg.payload.event, message_id);
        break;
      case 'revocation':
        log.warn(`[${this.label}] subscription revoked: ${msg.payload.subscription.type} (${msg.payload.subscription.status})`);
        break;
    }
  }

  async subscribeAll() {
    if (!this.sessionId) return;
    const token = await this.getToken();
    for (const s of this.subs()) {
      try {
        await helix({ clientId: this.clientId, token }, '/eventsub/subscriptions', {
          method: 'POST',
          body: JSON.stringify({ ...s, transport: { method: 'websocket', session_id: this.sessionId } }),
        });
      } catch (e) {
        log.warn(`[${this.label}] subscribe ${s.type} failed: ${(e as Error).message}`);
      }
    }
  }

  stop() {
    this.closed = true;
    this.connected = false;
    if (this.watchdog) clearInterval(this.watchdog);
    this.watchdog = null;
    this.ws?.close();
    this.pending?.close();
  }
}
