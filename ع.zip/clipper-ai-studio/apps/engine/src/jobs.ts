/**
 * Job runner: render (FFmpeg) and transcribe (whisper.cpp / OpenAI).
 * Jobs are claimed atomically with the SQL function claim_job (FOR UPDATE SKIP LOCKED),
 * retried with exponential backoff, and never run twice concurrently.
 */
import { spawn } from 'node:child_process';
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { Supa } from '../../../packages/shared/src/supa.ts';
import { parseSubtitles, toSRT, type Cue } from '../../../packages/shared/src/subtitles.ts';
import type { EngineEnv } from './env.ts';
import { log } from './log.ts';

interface Job { id: string; user_id: string; kind: 'render' | 'transcribe'; payload: any; attempts: number; max_attempts: number; }

export const PRESETS: Record<string, { w: number; h: number }> = { '1080x1920': { w: 1080, h: 1920 }, '720x1280': { w: 720, h: 1280 } };

/** Build a safe FFmpeg argument list (no shell!) for a vertical 9:16 export. */
export function buildRenderArgs(p: {
  input: string; output: string; preset: string; start?: number; end?: number;
  crop?: { x: number; y: number; w: number; h: number } | null; // normalized 0..1 of source
  srtPath?: string | null; ffmpegFontsDir?: string;
}): string[] {
  const { w, h } = PRESETS[p.preset] ?? PRESETS['1080x1920'];
  const vf: string[] = [];
  if (p.crop) {
    const c = p.crop;
    vf.push(`crop=iw*${c.w.toFixed(4)}:ih*${c.h.toFixed(4)}:iw*${c.x.toFixed(4)}:ih*${c.y.toFixed(4)}`);
  }
  vf.push(`scale=${w}:${h}:force_original_aspect_ratio=decrease`, `pad=${w}:${h}:(ow-iw)/2:(oh-ih)/2:color=black`, 'setsar=1');
  if (p.srtPath) vf.push(`subtitles=${p.srtPath.replace(/[:\\']/g, '\\$&')}:force_style='Fontsize=14,Bold=1,Outline=2,Alignment=2,MarginV=60'`);
  const args = ['-y', '-hide_banner', '-loglevel', 'error'];
  if (p.start && p.start > 0) args.push('-ss', p.start.toFixed(3));
  args.push('-i', p.input);
  if (p.end && p.end > (p.start ?? 0)) args.push('-t', (p.end - (p.start ?? 0)).toFixed(3));
  args.push('-vf', vf.join(','), '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '21', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '128k', '-movflags', '+faststart', p.output);
  return args;
}

function run(cmd: string, args: string[], timeoutMs = 15 * 60_000): Promise<string> {
  return new Promise((resolve, reject) => {
    const proc = spawn(cmd, args, { stdio: ['ignore', 'pipe', 'pipe'] });
    let out = ''; let err = '';
    const t = setTimeout(() => { proc.kill('SIGKILL'); reject(new Error(`${cmd} timed out`)); }, timeoutMs);
    proc.stdout.on('data', (d) => (out += d));
    proc.stderr.on('data', (d) => (err += d));
    proc.on('error', (e) => { clearTimeout(t); reject(e); });
    proc.on('close', (code) => { clearTimeout(t); code === 0 ? resolve(out) : reject(new Error(`${cmd} exited ${code}: ${err.slice(-500)}`)); });
  });
}

export class JobRunner {
  private busy = false;
  private env: EngineEnv;
  private db: Supa;
  constructor(env: EngineEnv, db: Supa) { this.env = env; this.db = db; }

  async tick() {
    if (this.busy) return; // one heavy job at a time on a small VM
    const [job] = await this.db.rpc<Job[]>('claim_job', { worker: this.env.WORKER_ID, kinds: ['render', 'transcribe'] });
    if (!job) return;
    this.busy = true;
    const dir = await mkdtemp(join(tmpdir(), 'clipper-'));
    try {
      const result = job.kind === 'render' ? await this.render(job, dir) : await this.transcribe(job, dir);
      await this.db.update('jobs', `id=eq.${job.id}`, { status: 'succeeded', result, completed_at: new Date().toISOString(), error: null });
      await this.db.insert('notifications', { user_id: job.user_id, kind: `${job.kind}_completed`, title: job.kind === 'render' ? 'Video export ready' : 'Transcript ready', link: job.kind === 'render' ? '#/library' : '#/subtitles' });
    } catch (e) {
      const msg = (e as Error).message.slice(0, 1000);
      const retry = job.attempts < job.max_attempts && !/not configured|invalid/i.test(msg);
      await this.db.update('jobs', `id=eq.${job.id}`, retry
        ? { status: 'queued', error: msg, run_after: new Date(Date.now() + 2 ** job.attempts * 30_000).toISOString(), locked_by: null }
        : { status: 'failed', error: msg, completed_at: new Date().toISOString() });
      if (!retry) await this.db.insert('notifications', { user_id: job.user_id, kind: `${job.kind}_failed`, title: `${job.kind === 'render' ? 'Export' : 'Transcription'} failed`, body: msg.slice(0, 200) });
      log.warn(`job ${job.id} failed: ${msg}`);
    } finally {
      await rm(dir, { recursive: true, force: true });
      this.busy = false;
    }
  }

  private async render(job: Job, dir: string) {
    const p = job.payload as { input_path: string; preset: string; start?: number; end?: number; crop?: any; cues?: Cue[]; clip_id?: string };
    if (!p.input_path?.startsWith(`${job.user_id}/`)) throw new Error('invalid input path');
    const input = join(dir, 'in');
    await writeFile(input, new Uint8Array(await this.db.download('videos', p.input_path)));
    let srtPath: string | null = null;
    if (p.cues?.length) { srtPath = join(dir, 'subs.srt'); await writeFile(srtPath, toSRT(p.cues)); }
    const output = join(dir, 'out.mp4');
    await run(this.env.FFMPEG_PATH, buildRenderArgs({ input, output, preset: p.preset, start: p.start, end: p.end, crop: p.crop, srtPath }));
    const outPath = `${job.user_id}/exports/${job.id}.mp4`;
    await this.db.upload('videos', outPath, new Uint8Array(await readFile(output)), 'video/mp4');
    if (p.clip_id) await this.db.update('clips', `id=eq.${p.clip_id}&user_id=eq.${job.user_id}`, { storage_path: outPath, status: 'ready' });
    return { output_path: outPath };
  }

  private async transcribe(job: Job, dir: string) {
    const p = job.payload as { input_path: string; language?: string; clip_id?: string };
    if (!p.input_path?.startsWith(`${job.user_id}/`)) throw new Error('invalid input path');
    const input = join(dir, 'in');
    await writeFile(input, new Uint8Array(await this.db.download('videos', p.input_path)));
    const wav = join(dir, 'audio.wav');
    await run(this.env.FFMPEG_PATH, ['-y', '-i', input, '-vn', '-ac', '1', '-ar', '16000', wav]);
    let cues: Cue[];
    if (this.env.TRANSCRIBE_PROVIDER === 'whisper_cpp' && this.env.WHISPER_CMD) {
      const [bin, ...base] = this.env.WHISPER_CMD.split(' ').filter(Boolean);
      await run(bin, [...base, '-f', wav, '-osrt', '-of', join(dir, 'out'), '-l', p.language ?? 'auto']);
      cues = parseSubtitles(await readFile(join(dir, 'out.srt'), 'utf8'));
    } else if (this.env.TRANSCRIBE_PROVIDER === 'openai' && this.env.OPENAI_API_KEY) {
      const fd = new FormData();
      fd.append('file', new Blob([new Uint8Array(await readFile(wav))]), 'audio.wav');
      fd.append('model', 'whisper-1');
      fd.append('response_format', 'srt');
      const r = await fetch('https://api.openai.com/v1/audio/transcriptions', { method: 'POST', headers: { Authorization: `Bearer ${this.env.OPENAI_API_KEY}` }, body: fd });
      if (!r.ok) throw new Error(`OpenAI transcription ${r.status}`);
      cues = parseSubtitles(await r.text());
    } else {
      throw new Error('Transcription provider not configured (set TRANSCRIBE_PROVIDER + WHISPER_CMD or OPENAI_API_KEY)');
    }
    await this.db.insert('subtitles', { user_id: job.user_id, clip_id: p.clip_id ?? null, provider: this.env.TRANSCRIBE_PROVIDER, language: p.language ?? 'auto', cues });
    return { cues: cues.length };
  }
}
