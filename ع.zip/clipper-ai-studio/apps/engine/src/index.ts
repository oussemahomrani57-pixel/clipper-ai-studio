/**
 * CLIPPER AI STUDIO — Engine (always-on Node 22 process).
 * Runs on a small VM / container: 24/7 EventSub chat monitoring, auto clipping,
 * FFmpeg rendering and transcription jobs. Zero npm dependencies.
 *
 *   node --experimental-strip-types src/index.ts
 */
import { Supa } from '../../../packages/shared/src/supa.ts';
import { loadEnv } from './env.ts';
import { Monitor } from './monitor.ts';
import { JobRunner } from './jobs.ts';
import { log } from './log.ts';

const VERSION = '0.1.0';
const env = loadEnv();
const db = new Supa(env);
const monitor = new Monitor(env, db);
const jobs = new JobRunner(env, db);

function every(ms: number, fn: () => Promise<void>, name: string) {
  let running = false;
  const wrapped = async () => {
    if (running) return;
    running = true;
    try { await fn(); } catch (e) { log.error(`${name} failed`, (e as Error).message); } finally { running = false; }
  };
  void wrapped();
  return setInterval(wrapped, ms);
}

const timers = [
  every(60_000, () => monitor.reconcile(), 'reconcile'),
  every(2_000, () => monitor.tick(), 'tick'),
  every(5_000, () => jobs.tick(), 'jobs'),
  every(30_000, async () => {
    const s = monitor.stats;
    await db.insert('engine_heartbeats', {
      worker_id: env.WORKER_ID, version: VERSION, monitored_channels: s.channels,
      eventsub_connected: s.sessions > 0 && s.connected === s.sessions, last_seen: new Date().toISOString(), info: s,
    }, { upsertOn: 'worker_id' });
  }, 'heartbeat'),
];

log.info(`Engine ${VERSION} started as ${env.WORKER_ID}`);

for (const sig of ['SIGINT', 'SIGTERM'] as const) {
  process.on(sig, () => {
    log.info('shutting down');
    timers.forEach(clearInterval);
    monitor.stop();
    setTimeout(() => process.exit(0), 500);
  });
}
