# CLIPPER AI STUDIO

**YOUR STREAM. YOUR CLIPS. AUTOMATICALLY.**
One platform · multiple streamers · automatic viral clips.

A premium dark SaaS app for Twitch clippers: real-time chat monitoring, viral-moment scoring, native Twitch clip creation (manual + automatic), a vertical 9:16 video editor with subtitles, a social publishing workflow, campaign earnings tracking and analytics. Built mobile-first so it works great on an iPhone.

---

## What works right now (no setup, no money)

Open the web app and it runs in **Local mode** — data stays on your device.

| Feature | Local mode (free, instant) | Needs cloud setup |
|---|---|---|
| All 12 pages, design system, mobile navigation | ✅ | |
| Streamers list, favorites, per-channel preferences | ✅ (add by username) | Search, avatars, live status, Twitch IDs |
| **Live Monitor** — real public chat, msgs/min, live viral score | ✅ while the app is open | 24/7 needs the Engine |
| Auto Clipper settings, weights, keywords, simulator, event log | ✅ | Real auto clips need the Engine + Twitch |
| Manual “CLIP RIGHT NOW” | — | ✅ Worker + Twitch |
| Clip Library: upload, filters, search, sort, preview, metadata, CSV/JSON export | ✅ | Twitch clips appear automatically |
| **Video Editor**: trim, 9:16 crop/position, blur bg, text overlay, thumbnail, **real MP4 export on iPhone** | ✅ | Server FFmpeg render |
| Subtitles: manual editor, SRT/VTT import/export, 4 animated templates | ✅ | Auto transcription (whisper.cpp/OpenAI) |
| Social Publisher: captions, limits, **iOS share sheet to TikTok/IG/YT**, post tracking | ✅ | Direct API upload = planned |
| Campaign Manager + estimated vs confirmed earnings | ✅ | |
| Analytics | ✅ | |
| DEMO DATA (clearly labelled, removable) | ✅ | never in cloud mode |

Nothing pretends to work: every feature that needs a backend shows its real status and what's missing.

## Architecture (why it's built this way)

```
 iPhone / browser ──► Cloudflare Pages (static React app, free)
        │                    │
        │ Supabase Auth      │ HTTPS (JWT)
        ▼                    ▼
  Supabase (Postgres+RLS, ◄── Cloudflare Worker  (free: OAuth, token refresh,
  Storage, free tier)          Helix proxy, Create Clip)
        ▲
        │ service role
  Engine (Node 22 + FFmpeg, always-on VM)
   • EventSub WebSocket chat monitoring 24/7 → MomentDetector → Create Clip
   • job queue: FFmpeg render, whisper transcription
```

- A static site **cannot** monitor 24/7 and a browser stops when closed → the **Engine** is a small always-on process.
- Cloudflare Workers/Supabase free tiers **cannot** run long FFmpeg jobs → FFmpeg runs on the Engine.
- Secrets never reach the browser: Twitch secret + tokens live in the Worker/Engine; tokens are AES-256-GCM encrypted in the DB with no RLS read policy.

Details: [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) · Costs & limits: [`docs/COSTS_AND_LIMITS.md`](docs/COSTS_AND_LIMITS.md)

## Repository layout

```
apps/web        React + TypeScript + Vite + Tailwind v4 + Framer Motion (the app)
apps/worker     Cloudflare Worker API (Twitch OAuth, Helix, clips)
apps/engine     Node 22 always-on engine (EventSub, auto clipping, FFmpeg, transcription) — zero npm deps
packages/shared Shared logic: viral scoring engine, earnings maths, subtitles, crypto, Twitch client
supabase/       SQL migration: 20+ tables, indexes, RLS, job-claim function, storage bucket
docs/           Setup, deployment, testing, architecture, costs
```

## Guides

1. [`docs/SETUP_TWITCH.md`](docs/SETUP_TWITCH.md) — register the Twitch app, scopes, redirect URL
2. [`docs/DEPLOYMENT.md`](docs/DEPLOYMENT.md) — step by step, **doable from an iPhone** (GitHub + Cloudflare + Supabase dashboards) except the Engine
3. [`docs/TESTING.md`](docs/TESTING.md) — automated tests and manual checklist
4. [`.env.example`](.env.example) — every variable, where it goes, placeholders only

## Quick start (computer)

```bash
npm install            # installs workspaces
npm run test           # shared + engine unit tests (Node 22, no deps)
npm run dev            # web app on http://localhost:5173 (Local mode)
```

## Honest limits

- Twitch **Create Clip** captures the moments before the request on a *live* channel that allows clipping. Optional `title`/`duration` parameters exist since Twitch's Dec 2025 update; there is no start-time control.
- Downloading a Twitch clip's video file via the API is reserved for the **broadcaster and their editors**. For other streamers, edit footage you have rights to (campaign-provided files, your own channel).
- Chat analysis measures how chat reacts — it can't see or hear the video. Audio/video AI signals are designed as future signals.
- “100 clips/day” is an architecture target, not a promise: see the capacity section in `docs/COSTS_AND_LIMITS.md`.
