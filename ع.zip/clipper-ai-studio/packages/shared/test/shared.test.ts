import { test } from 'node:test';
import assert from 'node:assert/strict';
import { MomentDetector, normalizeWeights } from '../src/scoring.ts';
import { estimateCampaign, estimateSubmission } from '../src/earnings.ts';
import { parseSubtitles, toSRT, toVTT } from '../src/subtitles.ts';

const T0 = 1_700_000_000_000;

function feedBaseline(d: MomentDetector, seconds: number, perSec: number) {
  for (let s = 0; s < seconds; s++) {
    for (let i = 0; i < perSec; i++) d.addMessage({ ts: T0 + s * 1000 + i * 10, userId: `u${(s * 7 + i) % 40}`, text: `normal chat ${s}-${i}` });
  }
}

test('quiet steady chat does not trigger', () => {
  const d = new MomentDetector();
  feedBaseline(d, 200, 1);
  const e = d.evaluate(T0 + 200_000);
  assert.equal(e.shouldTrigger, false);
  assert.ok(e.score < 40, `score ${e.score}`);
});

test('spike of reactions from many chatters triggers once, then cooldown/rearm blocks', () => {
  const d = new MomentDetector({ minScore: 60 });
  feedBaseline(d, 200, 1);
  const start = T0 + 200_000;
  for (let i = 0; i < 80; i++) d.addMessage({ ts: start + i * 120, userId: `v${i}`, text: i % 2 ? 'KEKW' : 'no way clip it' });
  const e = d.evaluate(start + 9_600);
  assert.equal(e.shouldTrigger, true, JSON.stringify(e));
  assert.ok(e.reasons.length >= 2);
  d.markTriggered(e.ts);
  const again = d.evaluate(start + 9_700);
  assert.equal(again.shouldTrigger, false);
  assert.ok(again.blockedBy === 'not_rearmed' || again.blockedBy === 'cooldown');
});

test('hourly limit is enforced', () => {
  const d = new MomentDetector({ minScore: 0, maxPerHour: 2, cooldownSec: 0, minMessagesInWindow: 0 });
  d.loadTriggerHistory([T0 - 10_000, T0 - 5_000]);
  const e = d.evaluate(T0);
  assert.equal(e.blockedBy, 'hourly_limit');
});

test('weights normalize to 100', () => {
  const w = normalizeWeights({ chatVelocity: 1, reactions: 1, keywords: 1, streamEvents: 1, other: 0 });
  assert.equal(Math.round(w.chatVelocity + w.reactions + w.keywords + w.streamEvents + w.other), 100);
});

test('earnings are capped and never invented', () => {
  assert.equal(estimateSubmission({ cpm: null, max_payout: null }, { eligible_views: 100000, confirmed_earnings: null }), 0);
  assert.equal(estimateSubmission({ cpm: 1, max_payout: null }, { eligible_views: 25000, confirmed_earnings: null }), 25);
  const c = estimateCampaign({ cpm: 2, max_payout: 30 }, [
    { eligible_views: 10000, confirmed_earnings: 5 },
    { eligible_views: 10000, confirmed_earnings: null },
  ]);
  assert.deepEqual(c, { estimated: 30, confirmed: 5, capped: true });
});

test('subtitles round-trip SRT and VTT', () => {
  const srt = '1\n00:00:01,000 --> 00:00:02,500\nHello\n\n2\n00:00:03,000 --> 00:00:04,000\nWorld\n';
  const cues = parseSubtitles(srt);
  assert.equal(cues.length, 2);
  assert.equal(toSRT(cues), srt);
  assert.equal(parseSubtitles(toVTT(cues)).length, 2);
});

test('token encryption round-trips and rejects tampering', async () => {
  const { encryptToken, decryptToken } = await import('../src/crypto.ts');
  const key = btoa(String.fromCharCode(...crypto.getRandomValues(new Uint8Array(32))));
  const enc = await encryptToken('secret-token', key);
  assert.equal(await decryptToken(enc, key), 'secret-token');
  const bad = enc.slice(0, -4) + (enc.endsWith('AAAA') ? 'BBBB' : 'AAAA');
  await assert.rejects(decryptToken(bad, key));
});
