/**
 * Minimal, dependency-free Twitch Helix client shared by the Worker and the Engine.
 * Docs: https://dev.twitch.tv/docs/api/reference
 */

export const TWITCH_SCOPES = {
  /** Create Clip (POST /helix/clips) */
  createClips: 'clips:edit',
  /** Read chat through EventSub channel.chat.message (engine) */
  readChat: 'user:read:chat',
} as const;

export class TwitchError extends Error {
  status: number;
  retryAfterSec?: number;
  constructor(status: number, message: string, retryAfterSec?: number) {
    super(message);
    this.status = status;
    this.retryAfterSec = retryAfterSec;
  }
}

export interface HelixOpts {
  clientId: string;
  token: string; // app or user access token
}

export async function helix<T>(o: HelixOpts, path: string, init: RequestInit = {}): Promise<T> {
  const res = await fetch(`https://api.twitch.tv/helix${path}`, {
    ...init,
    headers: { 'Client-Id': o.clientId, Authorization: `Bearer ${o.token}`, 'Content-Type': 'application/json', ...(init.headers ?? {}) },
  });
  if (res.status === 429) {
    const reset = Number(res.headers.get('Ratelimit-Reset') ?? 0);
    const wait = reset ? Math.max(1, reset - Math.floor(Date.now() / 1000)) : 5;
    throw new TwitchError(429, 'Twitch rate limit reached', wait);
  }
  if (!res.ok) {
    let msg = res.statusText;
    try { const j = (await res.json()) as { message?: string }; if (j.message) msg = j.message; } catch { /* ignore */ }
    throw new TwitchError(res.status, msg);
  }
  if (res.status === 204) return undefined as T;
  return (await res.json()) as T;
}

export interface TwitchUser { id: string; login: string; display_name: string; profile_image_url: string; }
export interface TwitchStream { user_id: string; user_login: string; user_name: string; game_name: string; title: string; viewer_count: number; started_at: string; thumbnail_url: string; }
export interface TwitchChannelSearch { id: string; broadcaster_login: string; display_name: string; thumbnail_url: string; is_live: boolean; game_name: string; title: string; }
export interface TwitchClip { id: string; url: string; embed_url: string; broadcaster_id: string; broadcaster_name: string; title: string; thumbnail_url: string; created_at: string; duration: number; view_count: number; }

export async function getAppToken(clientId: string, clientSecret: string): Promise<{ access_token: string; expires_in: number }> {
  const res = await fetch('https://id.twitch.tv/oauth2/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ client_id: clientId, client_secret: clientSecret, grant_type: 'client_credentials' }),
  });
  if (!res.ok) throw new TwitchError(res.status, 'Could not obtain Twitch app token — check TWITCH_CLIENT_ID / TWITCH_CLIENT_SECRET');
  return res.json() as Promise<{ access_token: string; expires_in: number }>;
}

export interface UserTokenResponse { access_token: string; refresh_token: string; expires_in: number; scope: string[]; }

export async function exchangeCode(clientId: string, clientSecret: string, code: string, redirectUri: string): Promise<UserTokenResponse> {
  const res = await fetch('https://id.twitch.tv/oauth2/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ client_id: clientId, client_secret: clientSecret, code, grant_type: 'authorization_code', redirect_uri: redirectUri }),
  });
  if (!res.ok) throw new TwitchError(res.status, 'Twitch rejected the authorization code');
  return res.json() as Promise<UserTokenResponse>;
}

export async function refreshUserToken(clientId: string, clientSecret: string, refreshToken: string): Promise<UserTokenResponse> {
  const res = await fetch('https://id.twitch.tv/oauth2/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ client_id: clientId, client_secret: clientSecret, grant_type: 'refresh_token', refresh_token: refreshToken }),
  });
  if (!res.ok) throw new TwitchError(res.status, 'Twitch refresh token invalid — the user must reconnect');
  return res.json() as Promise<UserTokenResponse>;
}

export async function revokeToken(clientId: string, token: string): Promise<void> {
  await fetch('https://id.twitch.tv/oauth2/revoke', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ client_id: clientId, token }),
  });
}

/**
 * Create Clip. Twitch captures from the live broadcast; the clip is processed
 * asynchronously — confirm it with getClip() after ~15 s. `title` and `duration`
 * are optional parameters added by Twitch in Dec 2025; Twitch validates them.
 * The user token needs `clips:edit`, the channel must be live and allow clipping.
 */
export async function createClip(o: HelixOpts, broadcasterId: string, opts: { title?: string; duration?: number } = {}) {
  const q = new URLSearchParams({ broadcaster_id: broadcasterId });
  if (opts.title) q.set('title', opts.title.slice(0, 100));
  if (opts.duration) q.set('duration', String(opts.duration));
  const r = await helix<{ data: { id: string; edit_url: string }[] }>(o, `/clips?${q}`, { method: 'POST' });
  const c = r.data?.[0];
  if (!c) throw new TwitchError(500, 'Twitch did not return a clip id');
  return c;
}

export async function getClip(o: HelixOpts, id: string): Promise<TwitchClip | null> {
  const r = await helix<{ data: TwitchClip[] }>(o, `/clips?id=${encodeURIComponent(id)}`);
  return r.data?.[0] ?? null;
}
