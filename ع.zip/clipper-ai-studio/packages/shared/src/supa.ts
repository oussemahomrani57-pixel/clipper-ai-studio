/** Tiny server-side Supabase REST helper (service role — bypasses RLS; never ship to the browser). */

export interface SupaEnv {
  SUPABASE_URL: string;
  SUPABASE_SERVICE_ROLE_KEY: string;
}

export class Supa {
  private env: SupaEnv;
  constructor(env: SupaEnv) { this.env = env; }

  private headers(extra: Record<string, string> = {}) {
    return {
      apikey: this.env.SUPABASE_SERVICE_ROLE_KEY,
      Authorization: `Bearer ${this.env.SUPABASE_SERVICE_ROLE_KEY}`,
      'Content-Type': 'application/json',
      ...extra,
    };
  }

  async select<T>(table: string, query: string): Promise<T[]> {
    const r = await fetch(`${this.env.SUPABASE_URL}/rest/v1/${table}?${query}`, { headers: this.headers() });
    if (!r.ok) throw new Error(`select ${table}: ${r.status} ${await r.text()}`);
    return r.json() as Promise<T[]>;
  }

  async insert<T>(table: string, row: unknown, opts: { upsertOn?: string } = {}): Promise<T[]> {
    const q = opts.upsertOn ? `?on_conflict=${opts.upsertOn}` : '';
    const prefer = opts.upsertOn ? 'return=representation,resolution=merge-duplicates' : 'return=representation';
    const r = await fetch(`${this.env.SUPABASE_URL}/rest/v1/${table}${q}`, { method: 'POST', headers: this.headers({ Prefer: prefer }), body: JSON.stringify(row) });
    if (!r.ok) throw new Error(`insert ${table}: ${r.status} ${await r.text()}`);
    return r.json() as Promise<T[]>;
  }

  async update(table: string, query: string, patch: unknown): Promise<void> {
    const r = await fetch(`${this.env.SUPABASE_URL}/rest/v1/${table}?${query}`, { method: 'PATCH', headers: this.headers(), body: JSON.stringify(patch) });
    if (!r.ok) throw new Error(`update ${table}: ${r.status} ${await r.text()}`);
  }

  async remove(table: string, query: string): Promise<void> {
    const r = await fetch(`${this.env.SUPABASE_URL}/rest/v1/${table}?${query}`, { method: 'DELETE', headers: this.headers() });
    if (!r.ok) throw new Error(`delete ${table}: ${r.status} ${await r.text()}`);
  }

  async rpc<T>(fn: string, args: unknown): Promise<T> {
    const r = await fetch(`${this.env.SUPABASE_URL}/rest/v1/rpc/${fn}`, { method: 'POST', headers: this.headers(), body: JSON.stringify(args) });
    if (!r.ok) throw new Error(`rpc ${fn}: ${r.status} ${await r.text()}`);
    return r.json() as Promise<T>;
  }

  /** Download / upload private files in Supabase Storage (bucket "videos"). */
  async download(bucket: string, path: string): Promise<ArrayBuffer> {
    const r = await fetch(`${this.env.SUPABASE_URL}/storage/v1/object/${bucket}/${path}`, { headers: this.headers() });
    if (!r.ok) throw new Error(`download ${path}: ${r.status}`);
    return r.arrayBuffer();
  }

  async upload(bucket: string, path: string, data: Uint8Array<ArrayBuffer>, contentType: string): Promise<void> {
    const r = await fetch(`${this.env.SUPABASE_URL}/storage/v1/object/${bucket}/${path}`, {
      method: 'POST', headers: this.headers({ 'Content-Type': contentType, 'x-upsert': 'true' }), body: data,
    });
    if (!r.ok) throw new Error(`upload ${path}: ${r.status} ${await r.text()}`);
  }

  /** Validate a user's Supabase access token and return their user id. */
  async userFromJwt(jwt: string): Promise<{ id: string; email?: string } | null> {
    const r = await fetch(`${this.env.SUPABASE_URL}/auth/v1/user`, {
      headers: { apikey: this.env.SUPABASE_SERVICE_ROLE_KEY, Authorization: `Bearer ${jwt}` },
    });
    if (!r.ok) return null;
    return r.json() as Promise<{ id: string; email?: string }>;
  }
}
