/**
 * AES-256-GCM token encryption using WebCrypto (works in Cloudflare Workers and Node 20+).
 * Key: 32 random bytes, base64-encoded, stored ONLY as a server secret (TOKEN_ENCRYPTION_KEY).
 * Generate one with:  node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
 */

const b64 = {
  enc(buf: ArrayBuffer | Uint8Array): string {
    const bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
    let s = '';
    for (const b of bytes) s += String.fromCharCode(b);
    return btoa(s);
  },
  dec(s: string): Uint8Array<ArrayBuffer> {
    const bin = atob(s);
    const out = new Uint8Array(new ArrayBuffer(bin.length));
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  },
};

async function importKey(secretB64: string): Promise<CryptoKey> {
  const raw = b64.dec(secretB64);
  if (raw.length !== 32) throw new Error('TOKEN_ENCRYPTION_KEY must be 32 bytes (base64)');
  return crypto.subtle.importKey('raw', raw, 'AES-GCM', false, ['encrypt', 'decrypt']);
}

export async function encryptToken(plain: string, secretB64: string): Promise<string> {
  const key = await importKey(secretB64);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, new TextEncoder().encode(plain));
  return `v1.${b64.enc(iv)}.${b64.enc(ct)}`;
}

export async function decryptToken(blob: string, secretB64: string): Promise<string> {
  const [v, ivS, ctS] = blob.split('.');
  if (v !== 'v1' || !ivS || !ctS) throw new Error('Unsupported token format');
  const key = await importKey(secretB64);
  const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: b64.dec(ivS) }, key, b64.dec(ctS));
  return new TextDecoder().decode(pt);
}

/** HMAC-SHA256 signing for OAuth `state` (prevents CSRF / account mix-ups). */
export async function hmac(data: string, secret: string): Promise<string> {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(data));
  return b64.enc(sig).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

export function timingSafeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}
