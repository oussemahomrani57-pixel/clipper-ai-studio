/** Subtitle cue helpers: SRT / WebVTT parse + serialize. */

export interface Cue {
  id: string;
  start: number; // seconds
  end: number;
  text: string;
}

const pad = (n: number, l = 2) => String(Math.floor(n)).padStart(l, '0');

export function formatTimestamp(sec: number, sep: ',' | '.' = ','): string {
  const s = Math.max(0, sec);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const ss = Math.floor(s % 60);
  const ms = Math.round((s - Math.floor(s)) * 1000) % 1000;
  return `${pad(h)}:${pad(m)}:${pad(ss)}${sep}${pad(ms, 3)}`;
}

export function parseTimestamp(t: string): number {
  const m = t.trim().match(/^(?:(\d+):)?(\d{1,2}):(\d{1,2})[,.](\d{1,3})$/);
  if (!m) return NaN;
  const [, h = '0', mi, s, ms] = m;
  return Number(h) * 3600 + Number(mi) * 60 + Number(s) + Number(ms.padEnd(3, '0')) / 1000;
}

export function parseSubtitles(input: string): Cue[] {
  const text = input.replace(/\r/g, '').replace(/^WEBVTT[^\n]*\n/, '');
  const blocks = text.split(/\n{2,}/);
  const cues: Cue[] = [];
  for (const b of blocks) {
    const lines = b.split('\n').filter((l) => l.trim() !== '');
    const idx = lines.findIndex((l) => l.includes('-->'));
    if (idx === -1) continue;
    const [a, z] = lines[idx].split('-->');
    const start = parseTimestamp(a);
    const end = parseTimestamp(z.trim().split(/\s+/)[0]);
    if (Number.isNaN(start) || Number.isNaN(end) || end <= start) continue;
    cues.push({ id: `c${cues.length + 1}`, start, end, text: lines.slice(idx + 1).join('\n') });
  }
  return cues.sort((x, y) => x.start - y.start);
}

export function toSRT(cues: Cue[]): string {
  return cues
    .map((c, i) => `${i + 1}\n${formatTimestamp(c.start)} --> ${formatTimestamp(c.end)}\n${c.text}`)
    .join('\n\n') + '\n';
}

export function toVTT(cues: Cue[]): string {
  return 'WEBVTT\n\n' + cues.map((c) => `${formatTimestamp(c.start, '.')} --> ${formatTimestamp(c.end, '.')}\n${c.text}`).join('\n\n') + '\n';
}

export function activeCue(cues: Cue[], t: number): Cue | undefined {
  return cues.find((c) => t >= c.start && t < c.end);
}
