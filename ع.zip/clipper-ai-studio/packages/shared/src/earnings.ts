/**
 * Campaign earnings maths. Deliberately conservative:
 *  - Each submission (one post on one platform) is valued on its own eligible views.
 *  - Views are NEVER summed across platforms into one figure unless the
 *    campaign explicitly says it pays per platform (each submission is separate anyway).
 *  - Per-submission and per-campaign maximum payouts are applied.
 *  - Estimated ≠ confirmed. Confirmed earnings are only what the user enters
 *    after the campaign/platform actually approved them.
 */

export interface CampaignTerms {
  cpm: number | null; // currency per 1000 eligible views, entered by the user
  max_payout: number | null; // cap for the whole campaign (per user)
  max_payout_per_submission?: number | null;
  min_views?: number | null; // views below this earn nothing
}

export interface SubmissionStats {
  eligible_views: number | null;
  confirmed_earnings: number | null;
}

export function estimateSubmission(t: CampaignTerms, s: SubmissionStats): number {
  if (t.cpm == null || t.cpm < 0 || !s.eligible_views || s.eligible_views < 0) return 0;
  if (t.min_views && s.eligible_views < t.min_views) return 0;
  let v = (s.eligible_views / 1000) * t.cpm;
  if (t.max_payout_per_submission != null) v = Math.min(v, t.max_payout_per_submission);
  return round2(v);
}

export function estimateCampaign(t: CampaignTerms, subs: SubmissionStats[]) {
  const raw = subs.reduce((a, s) => a + estimateSubmission(t, s), 0);
  const estimated = t.max_payout != null ? Math.min(raw, t.max_payout) : raw;
  const confirmed = subs.reduce((a, s) => a + (s.confirmed_earnings ?? 0), 0);
  return { estimated: round2(estimated), confirmed: round2(confirmed), capped: t.max_payout != null && raw > t.max_payout };
}

export const round2 = (n: number) => Math.round(n * 100) / 100;
