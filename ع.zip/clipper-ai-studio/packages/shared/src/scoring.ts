/**
 * Viral Moment Detector — pure, dependency-free logic shared by the
 * web app (browser monitor + settings preview) and the engine (24/7 monitor).
 *
 * IMPORTANT: this only analyses CHAT and STREAM EVENTS. It cannot see or hear
 * the video. A high score means "chat reacted strongly", nothing more.
 */

export type Sensitivity = 'low' | 'medium' | 'high';

export interface ScoreWeights {
  chatVelocity: number; // sudden increase in messages/sec vs. baseline
  reactions: number; // repeated messages, reaction emotes, laughter
  keywords: number; // excitement keywords
  streamEvents: number; // raids, game changes, go-live, etc.
  other: number; // chatter breadth (many distinct people reacting)
}

export interface DetectorConfig {
  weights: ScoreWeights;
  minScore: number; // 0-100
  cooldownSec: number;
  maxPerHour: number;
  maxPerDay: number;
  sensitivity: Sensitivity;
  keywords: string[];
  reactionTokens: string[];
  windowSec: number; // analysis window for "now"
  baselineSec: number; // window used to learn the normal chat rate
  minMessagesInWindow: number; // ignore tiny chats
}

export const DEFAULT_WEIGHTS: ScoreWeights = {
  chatVelocity: 40,
  reactions: 20,
  keywords: 15,
  streamEvents: 15,
  other: 10,
};

export const DEFAULT_KEYWORDS = [
  'clip', 'clip it', 'clipit', 'omg', 'no way', 'wtf', 'insane', 'crazy', 'what',
  'holy', 'lets go', "let's go", 'gg', 'wow', 'oh my god', 'bro', 'nooo', 'yooo',
  'incroyable', 'dingue', 'quoi', 'mdr', 'ptdr',
];

export const DEFAULT_REACTIONS = [
  'LUL', 'LOL', 'KEKW', 'OMEGALUL', 'Pog', 'PogChamp', 'PogU', 'POGGERS', 'monkaS',
  'WutFace', 'Kreygasm', 'PepeLaugh', 'LMAO', 'xD', 'W', 'L', 'HUH', 'Clap',
  '😂', '🤣', '😱', '🔥', '💀',
];

export const DEFAULT_CONFIG: DetectorConfig = {
  weights: DEFAULT_WEIGHTS,
  minScore: 60,
  cooldownSec: 120,
  maxPerHour: 6,
  maxPerDay: 40,
  sensitivity: 'medium',
  keywords: DEFAULT_KEYWORDS,
  reactionTokens: DEFAULT_REACTIONS,
  windowSec: 10,
  baselineSec: 300,
  minMessagesInWindow: 5,
};

/** How many times above baseline counts as a "full" spike. */
const SPIKE_FULL: Record<Sensitivity, number> = { low: 3, medium: 2, high: 1.5 };

export interface ChatMessage {
  ts: number; // ms epoch
  userId: string;
  text: string;
}

export interface StreamEvent {
  ts: number;
  type: 'online' | 'offline' | 'game_change' | 'raid' | 'title_change' | 'other';
  label?: string;
}

export interface ScoreComponents {
  chatVelocity: number; // 0..1
  reactions: number;
  keywords: number;
  streamEvents: number;
  other: number;
}

export interface Evaluation {
  ts: number;
  score: number; // 0..100
  components: ScoreComponents;
  messagesInWindow: number;
  msgPerSec: number;
  baselineMsgPerSec: number;
  reasons: string[];
  shouldTrigger: boolean;
  blockedBy: null | 'below_threshold' | 'cooldown' | 'hourly_limit' | 'daily_limit' | 'not_rearmed' | 'quiet_chat';
}

const clamp01 = (n: number) => (Number.isFinite(n) ? Math.min(1, Math.max(0, n)) : 0);

export function normalizeWeights(w: ScoreWeights): ScoreWeights {
  const total = w.chatVelocity + w.reactions + w.keywords + w.streamEvents + w.other;
  if (total <= 0) return { ...DEFAULT_WEIGHTS };
  const f = 100 / total;
  return {
    chatVelocity: w.chatVelocity * f,
    reactions: w.reactions * f,
    keywords: w.keywords * f,
    streamEvents: w.streamEvents * f,
    other: w.other * f,
  };
}

export function normalizeText(t: string): string {
  return t.toLowerCase().replace(/\s+/g, ' ').replace(/(.)\1{2,}/g, '$1$1').trim();
}

export class MomentDetector {
  private messages: ChatMessage[] = [];
  private events: StreamEvent[] = [];
  private triggers: number[] = [];
  private armed = true;
  readonly config: DetectorConfig;

  constructor(config: Partial<DetectorConfig> = {}) {
    this.config = { ...DEFAULT_CONFIG, ...config, weights: { ...DEFAULT_WEIGHTS, ...(config.weights ?? {}) } };
  }

  addMessage(m: ChatMessage) {
    this.messages.push(m);
    this.prune(m.ts);
  }

  addEvent(e: StreamEvent) {
    this.events.push(e);
  }

  /** Call after a clip was actually requested so cooldown/limits apply. */
  markTriggered(ts: number) {
    this.triggers.push(ts);
    this.armed = false;
  }

  /** Restore trigger history (e.g. after an engine restart) so limits survive. */
  loadTriggerHistory(ts: number[]) {
    this.triggers = [...ts].sort((a, b) => a - b);
  }

  private prune(now: number) {
    const keepFrom = now - this.config.baselineSec * 1000;
    if (this.messages.length && this.messages[0].ts < keepFrom) {
      let i = 0;
      while (i < this.messages.length && this.messages[i].ts < keepFrom) i++;
      this.messages.splice(0, i);
    }
    const dayAgo = now - 86_400_000;
    this.triggers = this.triggers.filter((t) => t >= dayAgo);
    this.events = this.events.filter((e) => e.ts >= now - 120_000);
  }

  evaluate(now: number = Date.now()): Evaluation {
    this.prune(now);
    const c = this.config;
    const winStart = now - c.windowSec * 1000;
    const win = this.messages.filter((m) => m.ts >= winStart && m.ts <= now);
    const older = this.messages.filter((m) => m.ts < winStart);

    const msgPerSec = win.length / c.windowSec;
    const baselineSpan = Math.max(c.windowSec, Math.min(c.baselineSec, older.length ? (winStart - older[0].ts) / 1000 : 0));
    // Floor the baseline so a quiet chat doesn't produce absurd ratios.
    const baselineMsgPerSec = Math.max(older.length / Math.max(baselineSpan, 1), 0.2);

    // A. chat velocity spike
    const ratio = msgPerSec / baselineMsgPerSec;
    const chatVelocity = clamp01((ratio - 1) / (SPIKE_FULL[c.sensitivity] - 1));

    // B. reactions: reaction tokens + repeated identical messages
    const tokenSet = new Set(c.reactionTokens.map((t) => t.toLowerCase()));
    let reactionMsgs = 0;
    const counts = new Map<string, number>();
    for (const m of win) {
      const norm = normalizeText(m.text);
      counts.set(norm, (counts.get(norm) ?? 0) + 1);
      const words = m.text.split(/\s+/);
      if (words.some((w) => tokenSet.has(w.toLowerCase())) || /(ha){3,}|(ja){3,}|(xd)+|😂|🤣/i.test(m.text)) reactionMsgs++;
    }
    let repeated = 0;
    for (const n of counts.values()) if (n >= 3) repeated += n;
    const reactionShare = win.length ? Math.max(reactionMsgs, repeated) / win.length : 0;
    const reactions = clamp01(reactionShare / 0.5);

    // C. keywords
    const kws = c.keywords.map((k) => k.toLowerCase()).filter(Boolean);
    let kwHits = 0;
    const kwSeen = new Map<string, number>();
    for (const m of win) {
      const t = ` ${normalizeText(m.text)} `;
      for (const k of kws) {
        if (t.includes(` ${k} `) || t.includes(` ${k}!`) || t.includes(` ${k}?`)) {
          kwHits++;
          kwSeen.set(k, (kwSeen.get(k) ?? 0) + 1);
          break;
        }
      }
    }
    const keywords = clamp01((win.length ? kwHits / win.length : 0) / 0.3);

    // D. stream events in the last 60s (decaying)
    let streamEvents = 0;
    let lastEvent: StreamEvent | null = null;
    for (const e of this.events) {
      const age = (now - e.ts) / 1000;
      if (age >= 0 && age <= 60) {
        const v = 1 - age / 60;
        if (v > streamEvents) { streamEvents = v; lastEvent = e; }
      }
    }

    // E. chatter breadth: how many distinct people are reacting
    const uniq = new Set(win.map((m) => m.userId)).size;
    const other = clamp01(win.length ? (uniq / win.length) * Math.min(1, uniq / 15) : 0);

    const w = normalizeWeights(c.weights);
    const components: ScoreComponents = { chatVelocity, reactions, keywords, streamEvents, other };
    const score = Math.round(
      w.chatVelocity * chatVelocity + w.reactions * reactions + w.keywords * keywords + w.streamEvents * streamEvents + w.other * other,
    );

    const reasons: string[] = [];
    if (chatVelocity > 0.3) reasons.push(`Chat ${ratio.toFixed(1)}× faster than baseline (${msgPerSec.toFixed(1)} msg/s vs ${baselineMsgPerSec.toFixed(1)})`);
    if (reactions > 0.3) reasons.push(`${Math.round(reactionShare * 100)}% of messages are reactions or repeats`);
    if (keywords > 0.3) {
      const top = [...kwSeen.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3).map(([k, n]) => `"${k}"×${n}`);
      reasons.push(`Excitement keywords: ${top.join(', ')}`);
    }
    if (lastEvent) reasons.push(`Stream event: ${lastEvent.label ?? lastEvent.type}`);
    if (other > 0.4) reasons.push(`${uniq} different chatters reacting`);

    // Re-arm hysteresis: after a trigger, score must fall below 60% of threshold
    if (!this.armed && score < c.minScore * 0.6) this.armed = true;

    let blockedBy: Evaluation['blockedBy'] = null;
    const last = this.triggers[this.triggers.length - 1];
    const hourCount = this.triggers.filter((t) => t >= now - 3_600_000).length;
    if (win.length < c.minMessagesInWindow) blockedBy = 'quiet_chat';
    else if (score < c.minScore) blockedBy = 'below_threshold';
    else if (!this.armed) blockedBy = 'not_rearmed';
    else if (last !== undefined && now - last < c.cooldownSec * 1000) blockedBy = 'cooldown';
    else if (hourCount >= c.maxPerHour) blockedBy = 'hourly_limit';
    else if (this.triggers.length >= c.maxPerDay) blockedBy = 'daily_limit';

    return {
      ts: now,
      score,
      components,
      messagesInWindow: win.length,
      msgPerSec,
      baselineMsgPerSec,
      reasons,
      shouldTrigger: blockedBy === null,
      blockedBy,
    };
  }
}

export const BLOCK_LABEL: Record<NonNullable<Evaluation['blockedBy']>, string> = {
  below_threshold: 'Below minimum score',
  cooldown: 'Cooldown active',
  hourly_limit: 'Hourly limit reached',
  daily_limit: 'Daily limit reached',
  not_rearmed: 'Same moment already clipped',
  quiet_chat: 'Not enough chat activity',
};
