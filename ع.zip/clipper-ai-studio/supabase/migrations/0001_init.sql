-- CLIPPER AI STUDIO — initial schema
-- Every user-owned table has user_id + Row Level Security: a user only ever sees their own rows.
-- Secrets (Twitch/social tokens) live in *_tokens tables that the browser can NEVER read:
-- no RLS policy is granted to authenticated users, only the service role (Worker/Engine) bypasses RLS.

create extension if not exists pgcrypto;

-- ───────────────────────── helpers
create or replace function public.touch_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

-- ───────────────────────── profiles (users)
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text check (char_length(display_name) <= 80),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, display_name) values (new.id, split_part(new.email, '@', 1));
  insert into public.user_settings (user_id) values (new.id);
  return new;
end $$;

-- ───────────────────────── settings
create table public.user_settings (
  user_id uuid primary key references auth.users(id) on delete cascade,
  auto_clipping_enabled boolean not null default false,
  auto_paused boolean not null default false,
  detector jsonb not null default '{}'::jsonb,         -- weights, minScore, cooldown, limits, sensitivity, keywords
  video jsonb not null default '{}'::jsonb,            -- export preset, fonts…
  subtitles jsonb not null default '{}'::jsonb,        -- provider, style
  notifications jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

-- ───────────────────────── twitch
create table public.twitch_accounts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  twitch_user_id text not null,
  login text not null,
  display_name text,
  profile_image_url text,
  scopes text[] not null default '{}',
  status text not null default 'active' check (status in ('active','expired','revoked','error')),
  last_error text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, twitch_user_id)
);

-- server-only: encrypted tokens (AES-GCM, key in Worker/Engine secret TOKEN_ENCRYPTION_KEY)
create table public.twitch_tokens (
  twitch_account_id uuid primary key references public.twitch_accounts(id) on delete cascade,
  access_token_enc text not null,
  refresh_token_enc text not null,
  expires_at timestamptz not null,
  updated_at timestamptz not null default now()
);

create table public.streamers (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  twitch_user_id text,
  login text not null check (login ~ '^[a-zA-Z0-9_]{2,25}$'),
  display_name text,
  profile_image_url text,
  is_favorite boolean not null default false,
  monitor_enabled boolean not null default false,
  auto_clip_enabled boolean not null default false,
  preferences jsonb not null default '{}'::jsonb,   -- per-streamer overrides of detector config
  last_live_at timestamptz,
  is_demo boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, login)
);

create table public.monitoring_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  streamer_id uuid not null references public.streamers(id) on delete cascade,
  source text not null check (source in ('engine','browser')),
  started_at timestamptz not null default now(),
  ended_at timestamptz,
  status text not null default 'running' check (status in ('running','stopped','error')),
  last_error text
);

-- aggregated per-minute chat stats (raw messages are NOT stored)
create table public.chat_activity (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  streamer_id uuid not null references public.streamers(id) on delete cascade,
  minute timestamptz not null,
  messages int not null default 0,
  unique_chatters int not null default 0,
  peak_score int not null default 0,
  unique (streamer_id, minute)
);

create table public.detection_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  streamer_id uuid references public.streamers(id) on delete set null,
  streamer_login text,
  score int not null check (score between 0 and 100),
  components jsonb not null default '{}'::jsonb,
  reasons text[] not null default '{}',
  action text not null check (action in ('clip_requested','skipped','dry_run')),
  blocked_by text,
  clip_id uuid,
  source text not null default 'engine',
  created_at timestamptz not null default now()
);

create table public.clips (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  streamer_id uuid references public.streamers(id) on delete set null,
  streamer_login text,
  twitch_clip_id text,
  title text check (char_length(title) <= 140),
  url text,
  edit_url text,
  thumbnail_url text,
  type text not null check (type in ('manual','auto','upload')),
  detection_score int,
  detection_event_id uuid references public.detection_events(id) on delete set null,
  status text not null default 'processing' check (status in ('requested','processing','ready','failed')),
  publish_status text not null default 'unpublished' check (publish_status in ('unpublished','scheduled','published','failed')),
  error text,
  storage_path text,                 -- for uploaded/rendered files
  duration_sec numeric,
  is_demo boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
-- prevents duplicate records for the same Twitch clip
create unique index clips_unique_twitch on public.clips(user_id, twitch_clip_id) where twitch_clip_id is not null;

alter table public.detection_events add constraint detection_clip_fk foreign key (clip_id) references public.clips(id) on delete set null;

-- ───────────────────────── jobs (monitoring, clip creation, render, transcribe, publish)
create table public.jobs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  kind text not null check (kind in ('clip_create','render','transcribe','publish','monitor')),
  status text not null default 'queued' check (status in ('queued','running','succeeded','failed','cancelled')),
  payload jsonb not null default '{}'::jsonb,
  result jsonb,
  dedupe_key text,
  attempts int not null default 0,
  max_attempts int not null default 3,
  error text,
  run_after timestamptz not null default now(),
  locked_by text,
  locked_at timestamptz,
  created_at timestamptz not null default now(),
  started_at timestamptz,
  completed_at timestamptz
);
create unique index jobs_dedupe on public.jobs(user_id, dedupe_key) where dedupe_key is not null and status in ('queued','running');
create index jobs_pick on public.jobs(status, run_after) where status = 'queued';

-- atomic job claim for the engine (FOR UPDATE SKIP LOCKED)
create or replace function public.claim_job(worker text, kinds text[]) returns setof public.jobs
language sql security definer set search_path = public as $$
  update public.jobs set status = 'running', locked_by = worker, locked_at = now(), started_at = now(), attempts = attempts + 1
  where id = (
    select id from public.jobs where status = 'queued' and run_after <= now() and kind = any(kinds)
    order by created_at limit 1 for update skip locked
  ) returning *;
$$;
revoke execute on function public.claim_job(text, text[]) from public, anon, authenticated;

create table public.subtitles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  clip_id uuid references public.clips(id) on delete cascade,
  language text default 'auto',
  provider text not null default 'manual',
  cues jsonb not null default '[]'::jsonb,
  style jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ───────────────────────── social
create table public.social_accounts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  platform text not null check (platform in ('tiktok','instagram','youtube')),
  external_id text,
  handle text,
  status text not null default 'active' check (status in ('active','expired','revoked','error')),
  created_at timestamptz not null default now(),
  unique (user_id, platform, external_id)
);
create table public.social_tokens (  -- server-only
  social_account_id uuid primary key references public.social_accounts(id) on delete cascade,
  access_token_enc text not null,
  refresh_token_enc text,
  expires_at timestamptz
);

create table public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  clip_id uuid references public.clips(id) on delete set null,
  platform text not null check (platform in ('tiktok','instagram','youtube')),
  caption text check (char_length(caption) <= 5000),
  hashtags text[] not null default '{}',
  status text not null default 'draft' check (status in ('draft','ready','scheduled','uploading','published','failed')),
  method text not null default 'manual' check (method in ('manual','api')),
  scheduled_at timestamptz,
  post_url text,
  platform_post_id text,
  error text,
  views bigint,
  is_demo boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ───────────────────────── campaigns
create table public.campaigns (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 120),
  url text check (url is null or url ~* '^https?://'),
  platforms text[] not null default '{}',
  cpm numeric check (cpm is null or cpm >= 0),
  currency text not null default 'USD',
  max_payout numeric check (max_payout is null or max_payout >= 0),
  max_payout_per_submission numeric,
  min_views int,
  requirements text,
  status text not null default 'active' check (status in ('active','paused','ended')),
  notes text,
  is_demo boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.campaign_submissions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  campaign_id uuid not null references public.campaigns(id) on delete cascade,
  post_id uuid references public.posts(id) on delete set null,
  platform text not null check (platform in ('tiktok','instagram','youtube','other')),
  post_url text not null check (post_url ~* '^https?://'),
  eligible_views bigint check (eligible_views is null or eligible_views >= 0),
  status text not null default 'submitted' check (status in ('submitted','approved','rejected','paid')),
  confirmed_earnings numeric check (confirmed_earnings is null or confirmed_earnings >= 0),
  is_demo boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (campaign_id, post_url)
);

-- ───────────────────────── analytics snapshots + notifications + engine status
create table public.analytics_daily (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  day date not null,
  platform text not null default 'all',
  clips_manual int not null default 0,
  clips_auto int not null default 0,
  published int not null default 0,
  views bigint not null default 0,
  unique (user_id, day, platform)
);

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  kind text not null,
  title text not null,
  body text,
  link text,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.engine_heartbeats (
  worker_id text primary key,
  version text,
  monitored_channels int not null default 0,
  eventsub_connected boolean not null default false,
  last_seen timestamptz not null default now(),
  info jsonb not null default '{}'::jsonb
);

-- ───────────────────────── indexes
create index on public.streamers(user_id);
create index on public.clips(user_id, created_at desc);
create index on public.clips(user_id, status);
create index on public.detection_events(user_id, created_at desc);
create index on public.jobs(user_id, created_at desc);
create index on public.posts(user_id, created_at desc);
create index on public.campaign_submissions(campaign_id);
create index on public.notifications(user_id, created_at desc) where read_at is null;
create index on public.chat_activity(streamer_id, minute desc);

-- ───────────────────────── updated_at triggers
do $$ declare t text; begin
  foreach t in array array['profiles','user_settings','twitch_accounts','streamers','clips','subtitles','posts','campaigns','campaign_submissions'] loop
    execute format('create trigger touch_%1$s before update on public.%1$s for each row execute function public.touch_updated_at()', t);
  end loop;
end $$;

-- ───────────────────────── Row Level Security
alter table public.profiles enable row level security;
create policy "own profile" on public.profiles for all using (id = auth.uid()) with check (id = auth.uid());

do $$ declare t text; begin
  foreach t in array array['user_settings','twitch_accounts','streamers','monitoring_sessions','chat_activity','detection_events',
    'clips','jobs','subtitles','social_accounts','posts','campaigns','campaign_submissions','analytics_daily','notifications'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('create policy "own rows" on public.%I for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid())', t);
  end loop;
end $$;

-- twitch_accounts / social_accounts: browser may read and delete, but only the Worker may insert/update
drop policy "own rows" on public.twitch_accounts;
create policy "read own" on public.twitch_accounts for select to authenticated using (user_id = auth.uid());
drop policy "own rows" on public.social_accounts;
create policy "read own" on public.social_accounts for select to authenticated using (user_id = auth.uid());

-- jobs: browser can create and read its jobs and cancel them, but not mark them succeeded
drop policy "own rows" on public.jobs;
create policy "read own jobs" on public.jobs for select to authenticated using (user_id = auth.uid());
create policy "queue own jobs" on public.jobs for insert to authenticated with check (user_id = auth.uid() and status = 'queued' and attempts = 0);
create policy "cancel own jobs" on public.jobs for update to authenticated using (user_id = auth.uid() and status = 'queued') with check (status = 'cancelled');

-- token tables and heartbeats: RLS on, NO policies => invisible to anon/authenticated
alter table public.twitch_tokens enable row level security;
alter table public.social_tokens enable row level security;
alter table public.engine_heartbeats enable row level security;
create policy "heartbeat readable" on public.engine_heartbeats for select to authenticated using (true);

-- ───────────────────────── storage bucket for uploaded / rendered video (private)
insert into storage.buckets (id, name, public) values ('videos', 'videos', false) on conflict do nothing;
create policy "own video files" on storage.objects for all to authenticated
  using (bucket_id = 'videos' and (storage.foldername(name))[1] = auth.uid()::text)
  with check (bucket_id = 'videos' and (storage.foldername(name))[1] = auth.uid()::text);
